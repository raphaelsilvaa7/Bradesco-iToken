<?php
include "visitas.class.php";
$visitas = new visitas();
//echo $visitas->num_visitas;
?>