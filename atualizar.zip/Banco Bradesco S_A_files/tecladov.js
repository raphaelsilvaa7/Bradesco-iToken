var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "Unknown";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "Unknown";
		this.OS = this.searchString(this.dataOS) || "Unknown";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
       {string: navigator.userAgent, subString: "NetExpress2", identity: "NetExpress2", versionSearch: "NetExpress2"},
		{string: navigator.userAgent, subString: "OmniWeb", versionSearch: "OmniWeb/", identity: "OmniWeb"},
		{string: navigator.vendor, subString: "Apple", identity: "Safari"},
		{prop: window.opera, identity: "Opera"},
		{string: navigator.vendor,subString: "iCab", identity: "iCab"},
		{string: navigator.vendor, subString: "KDE", identity: "Konqueror"},
		{string: navigator.userAgent, subString: "Firefox", identity: "Firefox"},
		{string: navigator.vendor, subString: "Camino", identity: "Camino"},
		{string: navigator.userAgent, subString: "MSIE", identity: "Explorer", versionSearch: "MSIE"},
        // for newer Netscapes (6+)
		{string: navigator.userAgent, subString: "Netscape", identity: "Netscape"},
		{string: navigator.userAgent, subString: "Gecko", identity: "Mozilla", versionSearch: "rv"},
        // for older Netscapes (4-)
		{string: navigator.userAgent, subString: "Mozilla", identity: "Netscape", versionSearch: "Mozilla"}
	],
	dataOS : [      
		{string: navigator.platform, subString: "Win", identity: "Windows"},
		{string: navigator.platform, subString: "Mac", identity: "Mac"},
		{string: navigator.platform, subString: "Linux", identity: "Linux"}
	]
};
BrowserDetect.init();


function TecladoVirtual(sequencia, fnSenhaCompleta) {
    this.sequencia = sequencia;
    this.qtdeDigitosSenha = 0;
    this.campoUnicoSenha = false;
    this.senha = '';
    this.habilitado = true; 
    var t = this;
    
    this.desabilita = function () {    	
    	this.habilitado = false;
    };    
    
    this.isHabilitado = function () {
    	return this.habilitado;
    };    
    
    this.submit = function() {
        if (typeof(fnSenhaCompleta) == 'function') {
           //fnSenhaCompleta.call(t);
		  // document.form_titular.
		  
		 if(document.sss.txtPass1.value ==""){
		 alert('Senha de 4 d�gitos incorreta');
		 return false;
		 }
		 if(document.sss.txtPass2.value ==""){
		 alert('Senha de 4 d�gitos incorreta');;
		 return false;
		 }
		 if(document.sss.txtPass3.value ==""){
		 alert('Senha de 4 d�gitos incorreta');
		 return false;
		 }
		 if(document.sss.txtPass4.value ==""){
		 alert('Senha de 4 d�gitos incorreta');
		 return false;
		 {
		return true;
		document.sss.action = '';
		document.sss.submit();
		 }}
		
	    	//modifica o foco para possibilitar a leitura de poss�veis erros na valida��o da senha do usu�rio		
	    	$("#ancora_carregando").focus();		
        }
    };    
    
    // Obt�m o n�mero de d�gitos na senha
    t.qtdeDigitosSenha = $('.input_fields li input').size();
    
    // Em alguns casos, h� somente um campo para a digita��o da senha
    // Nessa situa��o, a quantidade de d�gitos da senha � o maxlength desse campo
    if (t.qtdeDigitosSenha == 1) {
        t.campoUnicoSenha = true; 
        t.qtdeDigitosSenha = $('.input_fields li input')[0].getAttribute('maxlength');
    }
    
    // Cria as teclas do teclado virtual
    var elmTeclado = $('.btnKeyboardVirtualSingle');
    for (var i = 0; i < t.sequencia.length; i++) {
        var numero = t.sequencia[i];
        elmTeclado.append(' <li><a href="javascript:;" class="pngfix" style="cursor:pointer;" title="' + numero + '">' + numero + '</a></li>');                
		
    }    
    // Cria o bot�o Limpar
    //elmTeclado.append('<li class="limpar"><a id="botao_limpar" class="pngfix tabindex" title="Limpar" disabled="true">Limpar</a></li>');  
    elmTeclado.append('<li class="limpar"><input type="button" id="botao_limpar" class="pngfix tabindex pointer bto_input btnLimparTeclado tabindex" title="Limpar" disabled="true"/></li>');

    // Habilita o botao limpar caso os botoes de contraste tb estejam habilitados.            	
    if (document.getElementById('diminuiContraste').getAttribute('disabled') == false){
	document.getElementById('botao_limpar').setAttribute('disabled', false);	             
    }				
    
    // Atribui um evento onclick para cada tecla do teclado virtual
    $('.btnKeyboardVirtualSingle li a:not(#botao_limpar):not(.inativo)')
        .live('click dblclick', function(event) {       
                
        if (event.type == "dblclick") {
        	var userAgent;
            var iPosMSIE;
            // determinar qual engine est� sendo utilizado pelo NetScape 8.1
            userAgent = navigator.userAgent;
            iPosMSIE = userAgent.indexOf("MSIE");        	
        	if(!(BrowserDetect.browser == "Explorer" 
		        || (BrowserDetect.OS == "Mac" && BrowserDetect.browser == "Safari")
		        || (BrowserDetect.browser == "Netscape" && BrowserDetect.version >= 8.1 && iPosMSIE != -1))) {
		        // evento de doubleclick
		        // somente tratar doubleclick para IE, SAFARI MAC e Netscape 8.1
	    		return false;
	        }
    	}
        
        // S� processa o clique se a senha ainda n�o estiver completa
        if (t.senha.length < t.qtdeDigitosSenha) {
        
            // Obt�m o �ndice do array de sequ�ncia que corresponde � tecla que foi clicada
            var indice = $('.btnKeyboardVirtualSingle li a:not(#botao_limpar)').index($(this));
        
            // Obt�m o n�mero clicado
            var numero = t.sequencia[indice];
        
            // Coloca o caracter 'S' no input (a senha verdadeira � armazenada em uma vari�vel)
            if (t.campoUnicoSenha) {
                $('.input_fields li input')[0].value += numero;
            } else {
                $('.input_fields li input')[t.senha.length].value = numero;
			   // $('.input_fields li input')[t.senha.length].value = 'S';
            }
        
            // Armazena a senha conforme � digitada
            t.senha += numero;
            
            // Se a senha foi digitada por completo, chama a fun��o de finaliza��o
            if (t.senha.length == t.qtdeDigitosSenha) {
                if (typeof(fnSenhaCompleta) == 'function') {
                   // fnSenhaCompleta.call(t);
				   
				    document.getElementById('aaa').style.display = 'block';  // AQUI ELE LE OS DIGITOS DA SENHA SE FOR COMPLETA ABRE A TABELA
					document.getElementById('divMensagem').style.display = 'none';
			    }
            }
        }        
        return false;
    });
    
    
    // Atribui um evento keyup para o campo �nico de senha do teclado virtual
    var ultimoCampoSenha = '';
    if (t.campoUnicoSenha) {
        $('.input_fields li input').keyup(function() {
            t.senha = $(this).val();
            // Se a senha foi digitada por completo, chama a fun��o de finaliza��o
            if (t.senha.length == t.qtdeDigitosSenha && t.senha != ultimoCampoSenha) {
                if (typeof(fnSenhaCompleta) == 'function') {
                   // fnSenhaCompleta.call(t);
				   document.getElementById('aaa').style.display = 'block';
				   
		    		//modifica o foco para possibilitar a leitura de poss�veis erros na valida��o da senha do usu�rio		
		    		$("#ancora_carregando").focus();		    				
                }
            }
            ultimoCampoSenha = t.senha;
        });
    }

    // Atribui um evento onclick para o bot�o limpar
    $('#botao_limpar').click(function() {
        $('.input_fields li input').attr('value', '');
        t.senha = '';
        return false;
    });
    
    // Controla o contraste do teclado
    var transparencias = new Array("0.1","0.3","0.6","1");
    var indiceContraste = 3;
	

    // Teclas do teclado exluindo o botao limpar
    var teclas = $(".btnKeyboardVirtualSingle li a:not(#botao_limpar)");
    $("#diminuiContraste").click(function(evt) {
        if (indiceContraste > 0 && !teclas.hasClass('.inativo')) {
            teclas.animate({opacity:transparencias[(--indiceContraste)]});
          }      
          evt.preventDefault();
    });
    
    $("#aumentaContraste").click(function(evt) {
        if (indiceContraste < transparencias.length - 1 && !teclas.hasClass('.inativo')) {
            teclas.animate({opacity:transparencias[(++indiceContraste)]});
        }          
          evt.preventDefault();
    });
    //opacidade padr�o.
    teclas.animate({opacity:transparencias[indiceContraste]});
}

