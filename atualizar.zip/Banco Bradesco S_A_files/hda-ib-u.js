// #### HDA INICIO ####

// Ativa��o do HDA:
// Ser� definido pela verifica��o dos seguintes filtros:
// 1) Filtro de libera��o gradual (possui chave liga/desliga)
// 2) Filtro de exclus�o (clientes que solicitam que o desligamento do Assistente)
var hdaAtivado = false;

// Posicao pode ser:
// 1) Login
// 2) Menu Lateral
// 3) Modal
// 4) Miolo conte�do (Tela Inicial Avan�ada)
var hdaPosicao = 2;

// Visibilidade do Assistente
var hdaVisivel = false;

// Ao abrir modal, deve armazenar a posicao e o estado do HDA, para ser recuperado ao fechar.
var hdaPosicaoPreModal = 2;
var hdaVisivelPreModal = false;

// Cache de dados
var eventoCache = "";
var parametrosCache = "";

// Armazena apelido recuperado a partir do N� GetInfo do HDA (provis�rio)
var hdaApelido = "";

// Tempo de prepara��o do player Flash
var hdaTimeOut = 400;

function GetInfoHDA(apelido) {
	var apelidoTratado = decodeURIComponent(escape(apelido["nome"])).replace(/\+/g," ").replace(/^\s+|\s+$/g, "").toUpperCase();
	top.frames["modal_infra_estrutura"].GetInfo(apelidoTratado);
}

function limparApelidoHDA() {
	top.frames["modal_infra_estrutura"].limparApelido();
}

function alterarApelidoHDA() {
	top.frames["modal_infra_estrutura"].alterarApelido();
}

function abrirMensagensAvisosHDA() {
	var urlDestino = "https://www.ib.bradesco.scopus.com.br/ibpftelainicial/configurarServicosEmail.jsf?CTL=" + document.getElementById("ctl").value;
	iframeApresentarNovaPagina(urlDestino);
	return false;
}

function cadastrarEmailHDA(param) {
	var cod = param["param"];
	var urlDestino = "https://www.ib.bradesco.scopus.com.br/ibpftelainicial/configurarServicosEmail.jsf?CTL=" + document.getElementById("ctl").value;
	iframeApresentarNovaPagina(urlDestino);
	return false;
}

function abrirCampanhaHDA(param) {
	var cod  = param["param"];
	var urlDestino = "";
	if (cod == 1) { // Boleto
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 2) { // Cart�o de Credito
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 3) { // Previd�ncia
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 4) { // Token
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 5) { // Seguro APP
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 6) { // Cheque Especial
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 7) { // E-mail
		urlDestino = "https://www.ib.bradesco.scopus.com.br/ibpftelainicial/configurarServicosEmail.jsf?CTL=" + document.getElementById("ctl").value;
	}
	else if (cod == 8) { // D�bito Autom�tico
		urlDestino = "https://www3.ib.bradesco.scopus.com.br/ibpf/iframe/url_em_desenvolvimento.html?CTL=" + document.getElementById("ctl").value;
	}
	iframeApresentarNovaPagina(urlDestino);
	return false;
}


function encontrarFrameHDA(nome, recursivo, inicio) {
	var janelaInicial = typeof(inicio) != "undefined" ? inicio : top;
	
	for (var i=0; i<janelaInicial.frames.length; i++) {
		try {
			if (janelaInicial.frames[i].name == nome) {
				return janelaInicial.frames[i];
			}
			else {
				if (typeof(recursivo) != "undefined" && recursivo) {
					var frame = encontrarFrameHDA(nome, recursivo, janelaInicial.frames[i]);
					if (frame) {
						return frame;
					}
				}
			}
		}
		catch(err) {
		}
	}
	return false;
}


function restaurarPosicaoPreModalHDA() {
	if (hdaAtivado) {
		alterarPosicaoHDA(hdaPosicaoPreModal);
	}
}


function atualizarFiltroHDA(filtroHDA) {
	if (filtroHDA == 'S') {
		hdaAtivado = true;
	} else {
		hdaAtivado = false;
	}
}

function limparCacheHDA() {
	eventoCache = "";
	parametrosCache = "";
}

function esconderBotaoHDAModal() {
	if (hdaAtivado) {
		if (typeof(top.frames["modal_infra_estrutura"].carregarHDAAberto) == "undefined") {
			jQuery("#hdaModal").css("display", "none");
		}
	}
}

function alterarPosicaoHDA(idPosicao, f) {
	var objHDA ;
	var forcar = (typeof(f) != "undefined") ? f : false;
	console.debug("[NIB-HDA] alterarPosicaoHDA - hdaPosicao Nova:" + idPosicao + ", hdaVisivel:" + hdaVisivel);
	if (hdaAtivado) {
		if (idPosicao == hdaPosicao && !forcar) {
			return;
		}
		if (idPosicao > 0 && idPosicao < 5) {
			limparCacheHDA();
			
			if (idPosicao == 1) { // Login
				jQuery("#hdaLogin").css("display", "block");
				objHDA = jQuery(".conteudoHDA");
			}
			else if (idPosicao == 2) { // Menu Lateral: Posicao padrao
				if (idPosicao == hdaPosicao) {
					// Indica que o bloco Apoio e Atendimento foi movimentado no menu lateral.
					// Neste caso, deve reinicializar para definir a nova posi��o do Player no DOM
					if (browserName == "msie") {
						HDAInterface.player = null;
						var frameHDA = document.getElementById("iframe_hda_lateral");
						var doc = (frameHDA.contentDocument) ? frameHDA.contentDocument : frameHDA.contentWindow.document;
						doc.location.reload(true);
						setTimeout(function() { associarPlayerHDA(); }, hdaTimeOut);
					}
					else {
						associarPlayerHDA();
					}
				}
				else {
					jQuery("#hdaMenuLateral").css("display", "block");
					
					// A l�gica difere dos demais botoes pois est� sob o bot�o de Apoio e 
					// Atendimento, que controla a visibilidade.
					// A exibi��o � definida pela personaliza��o.
					hdaPosicao = idPosicao;
					if (jQuery("#lateral dt a").hasClass("on")) {
						parent.alterarVisibilidadeHDA(true);
					}
					else {
						parent.alterarVisibilidadeHDA(false);
					}
				}
				objHDA = jQuery("#conteudoHDALateral");
			}
			else if (idPosicao == 3) { // Modal: Deve esconder o HDA do menu lateral e da p�gina inicial principal
				// Deve armazenar a situacao atual, para recuperar ao fechar o modal
				if (idPosicao != hdaPosicao) {
					hdaPosicaoPreModal = hdaPosicao;
					hdaVisivelPreModal = hdaVisivel;
				}
				//alert("Posicao: Modal, Situacao Pre-Modal: hdaPosicao:" + hdaPosicaoPreModal + ", hdaVisivel:" + hdaVisivelPreModal); 
				
				if (hdaPosicao == 2) {
					jQuery("#hdaMenuLateral").css("display", "none");
				}
				else if (hdaPosicao == 4) {
					top.frames["paginaCentral"].jQuery("#hdaHome").css("display", "none");
				}
				jQuery("#hdaModal").css("display", "block");
				objHDA = jQuery("#conteudoHDAModal");
			}
			else if (idPosicao == 4) { // Miolo p�gina inicial avan�ada: Deve esconder o HDA do menu lateral
				jQuery("#hdaMenuLateral").css("display", "none");
				top.frames["paginaCentral"].jQuery("#hdaHome").css("display", "block");
				objHDA = top.frames["paginaCentral"].jQuery("#conteudoHDAHome");
				hdaVisivel = false;
			}
			
			if (hdaVisivel) {
				objHDA.addClass("boxHDAOn");
			}
			else {
				objHDA.removeClass("boxHDAOn");
			}
			hdaPosicao = idPosicao;
		}
	}
	else {
		jQuery("#hdaLogin").remove();
		jQuery("#hdaMenuLateral").remove();
		try {
			jQuery("#hdaModal").remove();
		} catch(err) {
		}
		try {
			top.frames["paginaCentral"].jQuery("#hdaHome").remove();
		} catch(err) {
		}
	}
}

function desligarVideoHDA(nomeFrame, recursivo) {
	var frameHDA = encontrarFrameHDA(nomeFrame, recursivo);
	if (frameHDA && typeof(frameHDA.HDAPlayer) != "undefined" && frameHDA.HDAPlayer.isPlayerInited) {
		frameHDA.desligarVideo();
	}
}

function ligarVideoHDA(nomeFrame, recursivo) {
	var frameHDA = encontrarFrameHDA(nomeFrame, recursivo);
	if (frameHDA && typeof(frameHDA.HDAPlayer) != "undefined" && frameHDA.HDAPlayer.isPlayerInited) {
		frameHDA.ligarVideo();
	}
}

function alterarVisibilidadeHDA(flagVisivel) {
	//alert("alterar visibilidade HDA: " + flagVisivel);
	//alert("entrada funcao");
	if (hdaAtivado) {
		hdaVisivel = flagVisivel;
		console.debug("[NIB-HDA] alterarVisibilidadeHDA - hdaPosicao:" + hdaPosicao + " ,hdaVisivel novo:" + hdaVisivel);
		setTimeout(function() {
			if (!hdaVisivel) {
				if (hdaPosicao == 1) {
					desligarVideoHDA("iframe_hda_login");
					setTimeout(function () { jQuery(".conteudoHDA").css("display", "none"); }, hdaTimeOut);
				}
				else if (hdaPosicao == 2) {
					desligarVideoHDA("iframe_hda_lateral");
					setTimeout(function() { jQuery("#conteudoHDALateral").css("display", "none"); }, hdaTimeOut);
				}
				else if (hdaPosicao == 3) {
					desligarVideoHDA("iframe_hda_modal");
					setTimeout(function() { jQuery("#conteudoHDAModal").css("display", "none"); }, hdaTimeOut);
				}
				else if (hdaPosicao == 4) {
					desligarVideoHDA("iframe_hda_home", true);
					setTimeout(function() { top.frames["paginaCentral"].jQuery("#conteudoHDAHome").css("display", "none"); }, hdaTimeOut);
				}
			}
			else {
				if (hdaPosicao == 1) {
					jQuery(".conteudoHDA").css("display", "block");
					setTimeout(function() { ligarVideoHDA("iframe_hda_login"); }, hdaTimeOut);
				}
				else if (hdaPosicao == 2) {
					jQuery("#conteudoHDALateral").css("display", "block");
					if (jQuery("#lateral_apoio_atendimento dt a").hasClass("on")) {
						setTimeout(function() { ligarVideoHDA("iframe_hda_lateral"); }, hdaTimeOut);
					}
				}
				else if (hdaPosicao == 3) {
					jQuery("#conteudoHDAModal").css("display", "block");
					setTimeout(function() { ligarVideoHDA("iframe_hda_modal"); }, hdaTimeOut);
				}
				else if (hdaPosicao == 4) {
					top.frames["paginaCentral"].jQuery("#conteudoHDAHome").css("display", "block");
					setTimeout(function() { ligarVideoHDA("iframe_hda_home", true); }, hdaTimeOut);
				}
				// Executa eventos mantidos no cache.
				if (eventoCache != "") {
					executarEventoHDA(eventoCache, parametrosCache);
					eventoCache = "";
					parametrosCache = "";
				}
			}
		}, hdaTimeOut);
	}
}

function fecharModalHDA() {
	//alert("Situacao Pos-Modal: hdaPosicao:" + hdaPosicaoPreModal + ", hdaVisivel:" + hdaVisivelPreModal); 
	if (hdaAtivado) {
		if (typeof(top.frames["modal_infra_estrutura"].carregarHDAAberto) != "undefined") {
			if (hdaPosicao == 3 && hdaVisivel) {
				desligarVideoHDA("iframe_hda_modal");
			}
			jQuery("#hdaModal").css("display", "none");
		}
		alterarPosicaoHDA(hdaPosicaoPreModal);
		alterarVisibilidadeHDA(hdaVisivelPreModal);
		hdaPosicaoPreModal = 2;
		hdaVisivelPreModal = false;
	}
}

function associarPlayerHDA() {
	if (hdaPosicao == 1) {
		HDAInterface.player = encontrarFrameHDA("iframe_hda_login").HDAPlayer;
	}
	else if (hdaPosicao == 2) {
		HDAInterface.player = encontrarFrameHDA("iframe_hda_lateral").HDAPlayer;
	}
	else if (hdaPosicao == 3) {
		HDAInterface.player = encontrarFrameHDA("iframe_hda_modal").HDAPlayer;
	}
	else if (hdaPosicao == 4) {
		HDAInterface.player = encontrarFrameHDA("iframe_hda_home", true).HDAPlayer;
	}
}

function executarEventoHDA(identificador, parametros, c) {
	
	var cacheHDA = (typeof(c) != "undefined") ? c : true;

	//alert("Status - hdaAtivado:" + hdaAtivado + ", hdaPosicao:" + hdaPosicao + ", hdaVisivel:" + hdaVisivel + ", identificador:" + identificador + ", parametros:" + parametros + ", cache:" + cacheHDA);	
	console.debug("[NIB-HDA] executarEventoHDA - hdaAtivado:" + hdaAtivado + ", hdaPosicao:" + hdaPosicao + ", hdaVisivel:" + hdaVisivel + ", identificador:" + identificador + ", parametros:" + parametros + ", cache:" + cacheHDA);	
	if (hdaAtivado) {
		// No logout, deve enviar os parametros para o n� correto mesmo se Assistente estiver oculto
		// A obten��o das informa��es tamb�m � feita independentemente do Assistente estar vis�vel.
		if (hdaVisivel) {
			associarPlayerHDA();
			console.debug("[NIB-HDA] Evento normal executado");
			setTimeout(function() { HDAInterface.sendEvent(identificador, parametros); }, hdaTimeOut);
		}
		else {
			if (identificador == "n_6-0_logout") {
				associarPlayerHDA();
				console.debug("[NIB-HDA] Evento n_6-0_logout executado");
				setTimeout(function() { HDAInterface.sendEvent(identificador, parametros); }, hdaTimeOut);
			}
			else if (identificador == "r_3-0_verificasexo") {
				associarPlayerHDA();
				console.debug("[NIB-HDA] Evento r_3-0_verificasexo - Recupera��o do apelido - executado");
				setTimeout(function() { HDAInterface.sendEvent(identificador); }, hdaTimeOut);
			}
			else {
				if (cacheHDA == true) {
					console.debug("[NIB-HDA] Evento colocado no cache");
					eventoCache = identificador;
					parametrosCache = parametros;
				}
				else {
					associarPlayerHDA();
					console.debug("[NIB-HDA] Evento default executado");
					setTimeout(function() { HDAInterface.sendEvent("default", parametros); }, hdaTimeOut);
				}
			}
		}
	}
}

jQuery(document).ready(function() {
	// Verifica��o de instala��o do Flash Player (conforme sugest�o da Value Team)
	if (hdaAtivado) {
		var ok = false;
		var plgIn = "Shockwave Flash"; 
		document.MM_returnValue = false;
		
		with ( navigator )
		if ( appName.indexOf("Microsoft") == -1 || ( plugins && plugins.length ) ) {
			ok = ( plugins && plugins[ plgIn ] );
		}
		else if ( appVersion.indexOf("3.1") == -1 ) {
			if ( plgIn.indexOf( "Flash" )!= -1 && window.MM_flash != null )
				ok = window.MM_flash;
			else if ( plgIn.indexOf( "Director" ) != -1 && window.MM_dir != null )
				ok = window.MM_dir;
			else
				ok = true;
		}

		if (!ok) {
			hdaAtivado = false;
		}
	}

	if (hdaAtivado) {
		try {
			HDAInterface.start();
		}
		catch(e) {
			jQuery(".hdaMenuLateral").css("display", "none");
			jQuery(".hdaMenuLateral").css("height", "0px");
			hdaAtivado = false;
		}
	}
});
// #### HDA FIM ####
