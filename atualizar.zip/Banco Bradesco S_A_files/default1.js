// LOADING JQUERY
$(document).ready(function() {
	
	/* Deficientes Visuais */
	$('#modalAcessoIndisponivel .hdaModal .boxHDA .btnExpandCollapse').blur(function(){
		if($(this).next('.conteudoHDA').css('display')=='none'){
			
			$('#modalAcessoIndisponivel').jqmHide();																				 			
			$('#txtCartaoSeg').focus();

		}
	});
	/* Deficientes Visuais */
	// TAMANHO COLUNA
	var aC = $('.conteudo_L').outerHeight();
	var aB = $('.box-direita').outerHeight();

	if (aC < aB) {
		if (typeof document.body.style.maxHeight === "undefined") {
			$('.miolo_noBg').css('height', (aB - 18) + "px");
		} else {
			$('.miolo_noBg').css('min-height', (aB - 18) + "px");
		}
    }
    // TAMANHO COLUNA    
    $('.bt_i').click(function(){
        $(this).addClass('none_i');
        $('.bt_a').removeClass('none_i');
    });
    
     // CLASSE PARA FECHAR O MODAL
       // Para fechar modal incluindo os criados dinamicamente 
       $(".closeModalLogin").live('click', function() {
           $(this).parents(".jqmWindow").jqmHide(); 
           if(modalOriginalObject != null) {
           		if (modalOriginalContent != null) {
           			modalOriginalObject.empty().append(modalOriginalContent);
           		}
           		modalOriginalObject = null;
           }
           return false;
       }); 

});
// FIM DO LOADING

//Ajusta a altura do box-direito ou conteudo
function ajustaAltura() 
{
	// para problema no IE que define como 800px
	$('#conteudo_interno').css("min-height", "");
	$('#miolo-alteracao-frase').css("min-height", "");
	
	// Altura das colunas conteudo e box-direita
	var aC = $('.conteudo_L').outerHeight();
	var aB = $('.box-direita').outerHeight();
	
	if (aC < aB) {
		if (typeof document.body.style.maxHeight === "undefined") {
			$('.miolo_noBg').css('height', (aB - 18) + "px");
		} else {
			$('.miolo_noBg').css('min-height', (aB - 18) + "px");
		}
	} 
}

//Mostrar box direita ul com 2 lis
function mostraBoxDireita(linhaMeio)
{
	$('.box-direita > li').hide();
	
	if (linhaMeio == undefined) 
	{	
		$('.box-direita>li:eq(0), .box-direita>li:eq(2)').fadeIn();
	}
	else {
		$('.box-direita>li:eq(1), .box-direita>li:eq(2)').fadeIn();
	}
}

function loadJsProxTipoAutenticacao () { 

        (function ($) {              
		// CONTADOR CARACTERES
				$(".cont_caracteres").keyup(function() {
                $("span.cont_"+prepararSeletor($(this).attr("id"))).text("[" + ($(this).val().length) + "]");
            });

        })(jQuery);
        //CONTADOR CARACTERES
}

function removerTagsHTML(strInputCode){
        return strInputCode.replace(/<\/?[^>]+(>|$)/g, " ");         
}

var ultimoInfoHda = '';
var ultimoInfoHdaProcessado = '';
function processarHda(infoHda) {
   // Armazena o par�metro da �ltma chamada
   if (typeof infoHda == 'string') {
      ultimoInfoHda = infoHda;
   }

   // Executa o processamento HDA se a flag hdaAtivado seja verdadeira e se
   // o valor do par�metro infoHda n�o for vazio e diferir da �ltima chamada ou
   // o par�metro infoHda estiver indefinido e o par�metro da �ltima chamada n�o
   // estiver vazio
   if (typeof hdaAtivado == 'boolean' && hdaAtivado && ((typeof infoHda == 'string'
       && infoHda != '' && infoHda != ultimoInfoHdaProcessado) || (typeof infoHda == 'undefined'
       && ultimoInfoHda != ''))) {
      // Atribui o �ltimo par�metro recebido a infoHda, caso este esteja indefinido
      if (typeof infoHda == 'undefined') {
         infoHda = ultimoInfoHda;
      }

      // Armazena o �ltimo valor processado
      ultimoInfoHdaProcessado = infoHda;

      // Executa a chamada ao evento HDA
      var indiceSeparador = infoHda.lastIndexOf('|');
      if (indiceSeparador >= 0) {
         var noHda = infoHda.substring(0, indiceSeparador);
         var paramHda = infoHda.substring(indiceSeparador + 1);
         try {
            executarEventoHDA(noHda, paramHda);
         } catch (excecao) {
         }
      }
   }
}

function onHDASlideDown() {   
   processarHda();
}

function habilitarProximoDispositivo() {
  // Obt�m o �ltimo form para processamento via Ajax
  ajaxForm = $('.ajaxForm:last');

  // Obt�m todos os campos habilitados deste form
  camposHabilitados = ajaxForm.find(':input:enabled');

  // Retira a classe inativo dos primeiros elementos com as classes loading e erro_msg
  $('.loading.inativo').eq(0).removeClass('inativo');
  $('.erro_msg.inativo').eq(0).removeClass('inativo');

  // Coloca o foco no primeiro campo habilidato
  //camposHabilitados.eq(0).focus();

  // Tratamento de links externos no html din�mico rec�m carregado
  $("a[rel*='external']").unbind('click').click(function(evt) {
    window.open($(this).attr("href"));
    evt.preventDefault();
  });
}

function erroGlobal(xmlHttpRequest, errorMessage, exception) {
    if (xmlHttpRequest == null || xmlHttpRequest.status != 401) {
       // Controle de dupla execu��o do Ajax
       sobExecucaoAjax = false;

       // Exibi��o do erro
       $('.loading').addClass('none_i');
       if (xmlHttpRequest == null && exception == null) {
         showModal(errorMessage);
       } else {
         showModal();
       } 
       // LINKS EXTERNOS
    	$("a[rel*='external']").unbind('click').click(function(evt) {
    		window.open($(this).attr("href"));
    		evt.preventDefault();
    	});
    	// LINKS EXTERNOS
    	// volta foco para mensagem de erro para V.Vision
    		
    	$('.modal-title').addClass('tabfirst');
    	$.tabindex();
    }
}

var sobExecucaoAjax = false;
function autenticarDispositivoAtual(valorEntrada, isPluginCadMaq) {
   if (typeof urlAutenticacao == 'string' && (typeof obterParametrosAjaxAutenticacaoDispositivoAtual == 'function'
       || (typeof isPluginCadMaq == 'boolean' && isPluginCadMaq)) && typeof ajaxTimeOut == 'number' && !sobExecucaoAjax) {
      // Controle de dupla execu��o do Ajax
      sobExecucaoAjax = true;

   // Habilita o gif animado de carregamento e muda o foco para o V.Vision falar a mensagem no caso de retorno de erro
   jQuery('.loading:not(.inativo):last').removeClass('none_i').focus();

   // Valida o dispositivo atual via ajax
      if (typeof isPluginCadMaq == 'boolean' && isPluginCadMaq) {
         $.ajax({
            type: 'POST',
            url: urlAutenticacao,
            data: obterParametrosAjaxAutenticacaoPluginCadMaq(valorEntrada),
            error: erroGlobal,
            success: resultadoAutenticacaoDispositivoAtual,
            timeout: ajaxTimeOut
         });
      } else {
      $.ajax({
         type: 'POST',
         url: urlAutenticacao,
         data: obterParametrosAjaxAutenticacaoDispositivoAtual(valorEntrada),
         error: erroGlobal,
         success: resultadoAutenticacaoDispositivoAtual,
         timeout: ajaxTimeOut
      });
   }
   }

   return false;
}

function obterParametrosAjaxAutenticacaoPluginCadMaq(valorEntrada) {
   var stringParametrosEnvio = '({';
   if (typeof obterTitularSelecionado == 'function') {
      stringParametrosEnvio += "'form_titular:titular': '" + obterTitularSelecionado() + "'";
      if (typeof valorEntrada == 'string') {
         stringParametrosEnvio += ", 'chaveValidacao': '" + valorEntrada + "'";
      }
      var dado = $("#dado");
      if (dado.size() > 0) {
         stringParametrosEnvio += ", 'dado': '" + dado.val() + "'";
      }
   }
   stringParametrosEnvio += '})';

   return eval(stringParametrosEnvio);
}

function processarAceiteAtual(valorAceite) {
   if (typeof obterParametrosAjaxProcessarAceiteAtual == 'function' && typeof ajaxTimeOut == 'number' && !sobExecucaoAjax) {
      // Controle de dupla execu��o do Ajax
      sobExecucaoAjax = true;

   // Exibe a imagem de carregamento, caso o aceite n�o seja modal
   if ((respAutenticacaoDispAtual != null && typeof respAutenticacaoDispAtual == 'undefined') || respAutenticacaoDispAtual.formaExibicaoProximaSequencia != 2) {
      $('.loading:not(.inativo):last').removeClass('none_i');
   }

   // Tratamento de URL target para aceite
   var targetUrl;
   if (respAutenticacaoDispAtual != null && respAutenticacaoDispAtual.codigoProximaSequencia == 0) {
      if (typeof urlAutenticacao == 'string') {
         targetUrl = urlAutenticacao;
      }
   } else {
      if (typeof urlAceite == 'string') {
         targetUrl = urlAceite;
      }
   }

   // Processa o aceite atual via ajax
      if (typeof targetUrl == 'string') {
      $.ajax({
         type: 'POST',
         url: targetUrl,
         data: obterParametrosAjaxProcessarAceiteAtual(valorAceite),
         error: erroGlobal,
         success: resultadoAutenticacaoDispositivoAtual,
         timeout: ajaxTimeOut
      });
      } else {
         // Controle de dupla execu��o do Ajax
         sobExecucaoAjax = false;
      }
   }

   return false;
}

function exibirMensagemErroForm(mensagemErro, element) {
   // Processamento dos par�metros
   if (typeof element == 'undefined') {
      if (typeof mensagemErro == 'undefined') {
         element = $('.erro_msg:not(.inativo):last');
         mensagemErro = element.html();
      } else if (typeof mensagemErro == 'string') {
         element = $('.erro_msg:not(.inativo):last');
      } else {
         element = mensagemErro;
         mensagemErro = element.html();
      }
   }
   // Habilita o div de mensagem de erro
   element.removeClass("none_i").html(mensagemErro);

   // Inclui a classe "form_erro" no div pai
   divPai = element.closest('.after');
   divPai.addClass("form_erro");

   // Efetua a limpeza dos campos contidos no divPai
   divPai.find('input:visible:not(:radio, :checkbox, .manterConteudo)').attr('value', '');
   
   try {
        limparCamposAdicionais();
   } catch (error) {
   }

   // Tratamento especial para limpeza do teclado virtual
   divPai.find('#botao_limpar').click();

   // Inclui a mensagem de erro no t�tulo do elemento (tratamento Virtual Vision)
   // removendo os tags HTML da mensagem que vao no title do erro
   var msgerro = removerTagsHTML(mensagemErro);
   incluirErroTitle(element, msgerro);
   var elementoInput = divPai.find('input:visible:not(.btnLimparTeclado)').eq(0);
   if (elementoInput) {
	   incluirErroTitle(elementoInput, msgerro);
   }
   // Coloca o foco na primeiro elemento de input do divPai
   divPai.find('input:visible:not(.btnLimparTeclado)').eq(0).focus();  

   // Tratamento especial para zerar contador de frase secreta
   divPai.find('.contador_frase:not(.manterConteudo)').html('[0]');
}

function removerMensagemErroForm() {
   // Remove a mensagem de erro no t�tulo do elemento (tratamento Virtual Vision)
   removerErroTitle($('.erro_msg'));

   // Remove a classe "form_erro" de todos os elementos e a cont�m
   $('.form_erro').removeClass("form_erro");

   // Esconde todos os divs de erro
   $('.erro_msg').addClass("none_i");
}

var respAutenticacaoDispAtual = null;
function resultadoAutenticacaoDispositivoAtual(respString, status) {
   // Controle de dupla execu��o do Ajax
   sobExecucaoAjax = false;

   // Processamento do retorno Ajax
   $('.loading').addClass('none_i');
   if (status == 'success') {
      try {
         // Processa a resposta do servidor
         respAutenticacaoDispAtual = eval ("(" + respString + ")");   

         // Limpa as mensagens de formul�rio da tela
         removerMensagemErroForm();

         if (respAutenticacaoDispAtual.sucesso) {
            // Desabilita o �ltimo teclado virtual da p�gina
        	 if ((typeof teclado == 'object') && (teclado != null)) {
        		 teclado.desabilita();
        	 } 
            $('.btnKeyboardVirtualSingle:last').find('*').unbind();

            // Verifica se h� mais passos
            if (respAutenticacaoDispAtual.codigoProximaSequencia == 2) {
            	
            	// mostrar modal sucesso para alteracao frase
               if(typeof(exibeModalSucesso) == "undefined") {
                    exibeModalSucesso = false;
               } 
               if (respAutenticacaoDispAtual.tipoAut == "CADASTROALTERAFRASESEC" && exibeModalSucesso) {
            	   showModalSucessoAlteracaoFrase();            	   
               } else {
               // N�o h� mais passos, avan�ar para pr�xima p�gina
               window.location.href = urlProximaPagina;
               }
               
            } else {
               if (respAutenticacaoDispAtual.tipoAut == "SENHA4") {
                  //validar dispositivo de seguran�a.
                  verifPlugSeg();
               } else {                
                  // Desabilita todos os campos password da p�gina
                  $(':password').attr('disabled', true);
    
                  // Obt�m o pr�ximo dipositivo do servidor
                  obterProximoDispositivo();
               }
            }
         } else {
            // Tratamento da mensagem de erro
            if (respAutenticacaoDispAtual.msgs[0].campo == "geral" || respAutenticacaoDispAtual.msgs[0].campo == "global") {
               erroGlobal(null, respAutenticacaoDispAtual.msgs[0].msg, null);
            } else {
               var elementoMensagemErro;
               if (typeof respAutenticacaoDispAtual.msgs[0].campo == 'string' && respAutenticacaoDispAtual.msgs[0].campo.length > 0) {
               try {
            	   if (typeof isPrimeiroAcesso == 'boolean' && isPrimeiroAcesso) {
            		   classeBox = '.boxP14';
            	   } else {
            		   classeBox = '.box_redLine_bottom';
            	   }
                     elementoMensagemErro = $('[id$=' + prepararSeletor(respAutenticacaoDispAtual.msgs[0].campo) + ']')
                  	.closest(classeBox).find('.erro_msg:not(.inativo):last');
               } catch (erroFind) {
               }
               }
               if (typeof elementoMensagemErro != 'undefined' && elementoMensagemErro.size() > 0) {
                  exibirMensagemErroForm(respAutenticacaoDispAtual.msgs[0].msg, elementoMensagemErro);
               } else {
               exibirMensagemErroForm(respAutenticacaoDispAtual.msgs[0].msg);
            }
         }
         }

         // Processamento HDA
         processarHda(respAutenticacaoDispAtual.paramHda);
      } catch (erro) {
         erroGlobal(null, 'Problemas no processamento da resposta do servidor.', erro);
      }
   } else {
      erroGlobal(null, 'Problemas no processamento do servidor: ' + status, null);
   }
}

function obterProximoDispositivo() {
   if (typeof urlProximoTipoAutenticacao == 'string') {
      if (respAutenticacaoDispAtual.formaExibicaoProximaSequencia == 4) {
         // Redireciona para a pr�xima p�gina
         window.location.href = urlProximoTipoAutenticacao.replace("nome=valor", respAutenticacaoDispAtual.parametroExtra);
      } else {
         if (typeof obterParametrosAjaxProximoDispositivo == 'function' && typeof ajaxTimeOut == 'number' && !sobExecucaoAjax) {
            // Controle de dupla execu��o do Ajax
            sobExecucaoAjax = true;

            // Obt�m o html do pr�ximo dispositivo via ajax
            $('.loading:not(.inativo):last').removeClass('none_i');
            $.ajax({
               type: 'POST',
               url: urlProximoTipoAutenticacao.replace("nome=valor", respAutenticacaoDispAtual.parametroExtra),
               data: obterParametrosAjaxProximoDispositivo(),
               error: erroGlobal,
               success: resultadoObtencaoProximoDispositivo,
               timeout: ajaxTimeOut
            });
         }
      }
   }
}

function resultadoObtencaoProximoDispositivo(respString, status) {
   // Controle de dupla execu��o do Ajax
   sobExecucaoAjax = false;

   // Processamento do retorno Ajax
   $('.loading').addClass('none_i');
   if (status == 'success') {
      // Incrementa a sequencia do pr�ximo dispositivo
      if (respAutenticacaoDispAtual.codigoProximaSequencia != 1 && typeof sequenciaProximoDispositivo == 'number') { // N�o trata-se de p�gina de aceite
         sequenciaProximoDispositivo++;
      }
      removeModalContent();

      if (respAutenticacaoDispAtual.formaExibicaoProximaSequencia == 2) { // Exibi��o de modal
         showModalContent(respString);
      } else { // Exibi��o na �rea de dispositivos
         // Habilita o div dos dispositivos de autentica��o
         jQuery("div[id*='divDispositivos']").attr('disabled', false);
         
         // Desabilita os campos de input atuais, menos os botoes de input
         jQuery(':input:not(.bto_input)').attr('disabled', true);         
                  
         if (respAutenticacaoDispAtual.formaExibicaoProximaSequencia == 3) { // Exibi��o de nova p�gina
        	 if (!(typeof prepararTelaProximoDispositivo == 'function' && 
        			 prepararTelaProximoDispositivo(respAutenticacaoDispAtual.proximoTipoAut, isPrimeiroAcesso, respString))) {
               if (respAutenticacaoDispAtual.proximoTipoAut == 'TOKENDBLOQ2' || respAutenticacaoDispAtual.proximoTipoAut == 'MBTOKENDBLOQ2'
               || respAutenticacaoDispAtual.proximoTipoAut == 'CADASTROALTERAFRASESEC') {
                  // Escode a sauda��o do titular, o formul�rio do titular e os dispositivos atuais
                  $('#box_titular').remove();
                  $('#form_titular').remove();
                  $('#divDispositivos > div').remove();

                  // Inclui o html obtido do servidor no div de dispositivos do titular selecionado
                  $("div[id*='divDispositivos']").append(respString);
                  habilitarProximoDispositivo();
    
                  // Chama o fun��o para contabiliza��o autom�tica dos caracteres digitados para a frase secreta
                  loadJsProxTipoAutenticacao();
               } else {
	           // Substitui tudo do conteudo
                substituirConteudo(respString);
        	}
            }
            try {
                if (typeof funcaoSequenciaAutenticacao == 'function') {
                    funcaoSequenciaAutenticacao();
                }
            } catch (err) {
            }
            habilitarProximoDispositivo();
         } else {
           // Esconde o div de mensagem
             $("div[id*='divMensagem']").hide();
             $('.processarAceite').removeClass('ajaxForm');
             $('.processarAceite').removeClass('processarAceite');

             // Inclui o html obtido do servidor no div de dispositivos do titular selecionado
            $("div[id*='divDispositivos']").append(respString);
             habilitarProximoDispositivo();
    
             // Chama o fun��o para contabiliza��o autom�tica dos caracteres digitados para a frase secreta
             loadJsProxTipoAutenticacao();
         }

      }
   } else {
      erroGlobal(null, 'Problemas no processamento do servidor: ' + status, null);
   }
}

function showModal(mensagem) {       
   if (typeof mensagem !== 'undefined') {
      $('.tabfirst').removeClass('tabfirst');
      $('#mensagem-erro').attr('title', removerTagsHTML(mensagem));      
      $("#modalLogin .ctn-box").html(mensagem);   
   }
   // prepara para circular tab no modal
   $('.jqmWrapper .tabindex').addClass('tabmodal');
   jQuery(function($) {		
	    cicularTabNoModal();
	});
   $("#modalLogin").removeClass('none_i').jqmShow();   
}

function _showModalContentOriginal(content) {
    // adiciona o conteudo a div jqmWrapper
    $('#modalContent > .jqmWrapper').empty().append(content);    
    $('#modalContent').jqmShow();
    setTimeout(function() {
    jQuery('.modal-title').focus();
    }, 550);
}
function showModalContent(content) {
	modalOriginalContent = null;
	modalOriginalObject = null;
	_showModalContentOriginal(content);
}
if(typeof(modalOriginalObject) == "undefined") {
	modalOriginalObject = null;
	modalOriginalContent = null;
}
function showModalContentEx(content, objOriginal) {
	modalOriginalContent = content;
	modalOriginalObject = objOriginal;
	modalOriginalObject.empty();
	_showModalContentOriginal(content);
}

function removeModalContent() {
    // limpa o conteudo do div jqmWrapper
    $('#modalContent > .jqmWrapper').empty();    
}


function showModalTermoAdesao() {
    // adiciona o conteudo #termoWrapper a div jqmWrapper    
    var content = $('#modalTermoAdesaoAceite > .jqmWrapper').clone(true);
    if (content.size() > 0) {    
        showModalContentEx(content, $('#modalTermoAdesaoAceite > .jqmWrapper'));    
    }        
}

function showModalTermoTancode() {
    // adiciona o conteudo #termoWrapper a div jqmWrapper    
    var content = $('#modalTermoTancodeAceite > .jqmWrapper').clone(true);
    if (content.size() > 0) {    
        showModalContentEx(content, $('#modalTermoTancodeAceite > .jqmWrapper'));    
    }        
}

function showModalSucessoAlteracaoFrase() {
    var content = $('#modalSucessoAlteracaoFrase .jqmWrapper');
    if (content.size() > 0) {
        // adiciona o conteudo a div jqmWrapper
        var contentTemp = content.html();
        //esvaziar dado original para evitar formul�rio duplicado.
        content.empty();	    
    	showModalContent(contentTemp);
    }        	
}

function showModalLiberacaoFoneFacil() {
    var content = $('#modalLiberacaoFoneFacil > .jqmWrapper').clone(true);	
    if (content.size() > 0) {
    	showModalContentEx(content, $('#modalLiberacaoFoneFacil > .jqmWrapper'));
    }        	
    return false;
}


function atualizarConteudoDinamico() {
	var contador = 0;
    $('#lista-conteudos > div').each(function() {     
        var nomeClasse = $(this).attr('class').split(' ').slice(-1);
        //$("div[class='" + nomeClasse + "']:not(.conteudo-dinamico)").replaceWith($("#lista-conteudos > ." + nomeClasse));
        $("div[class*='" + nomeClasse + "']:not(.conteudo-dinamico)").replaceWith($(this));
    });
    $('.conteudo-dinamico:not(#lista-conteudos)').removeClass('none_i').removeClass('conteudo-dinamico');    
}

function substituirConteudo(dado) {
	$(".clear_after_autent").empty()
    if ($(".box-main").length > 0) {
        //primeiro acesso
        if ($("#form_titular").length > 0) {
            $("#form_titular").html(dado);
        } else {
            $(".box-main").html(dado);
         }
    } else {
        $('.conteudo_L').html(dado);
    }
}
// define estilo de contagem de caracteres para conteudo adicionado posteriormente
$(".cont_caracteres").live("keyup",function(){
    try {            
	 $("span.cont_"+ prepararSeletor($(this).attr("id"))).text("[" + ($(this).val().length) + "]");
    } catch (err) {
    }
});

           
function irPasso(passoBaseZero) {
	
	// adiciona os link invisiveis obtidos do properties e armazenados em array javascript aos divs da p�gina atual
    var ndx = 0;
    jQuery('.seqPassos-dinamico .passoLogin-steps li > div').each(function() {
    	if (!(typeof(linkpassos) === 'undefined')) {	    	
        jQuery(this).append(linkpassos[ndx++]);
    	}
    });
    
    jQuery("div[id*='seqPassos-proximoPasso']").each(function() {
        jQuery("div[id*='sequenciaPassosLogin']:not(.seqPassos-dinamico)").html(jQuery("div[id*='seqPassos-proximoPasso']").html());    
    });
    
    // desabilita os link invisiveis n�o ativos e ativa o ativo
    jQuery('.passoLogin-steps li > div:not(.passoLogin-active) a').attr('disabled', 'disabled');        
    jQuery('.passoLogin-steps li > .passoLogin-active a').attr('disabled', '');
}


function esconderBotoes() {
	$('div[id*="divBotoesPagina"] > ul > li').hide();
}

//plugin seg - ini
var netExpress3 = (navigator.userAgent.indexOf("Net Express") >= 0);
function VrfComp(nome) {
    if (document.applets == null) {
        return false;
    }
    if (document.applets.length == 0) {
        return false;
    }
    if (document.applets[nome] == null) {
        return false;
    }
    return true;
}

function verifPlugSeg(instalacaoPlugin)
{
   if (typeof urlAutenticacao == 'string' && typeof obterParametrosAjaxVerifPlugSeg == 'function' && typeof ajaxTimeOut == 'number' && !sobExecucaoAjax) {
      // Controle de dupla execu��o do Ajax
      sobExecucaoAjax = true;

    var aux;
    var versionPlugSeg = "";
    var infPlugSeg = "";
    var dynId = "";
    
    if (netExpress3) {
		var comp = document.getElementById("Conexao");
		if (comp != null && typeof(comp) != "undefined") {
	        aux = comp.Version;
	        if (typeof(aux) != "undefined" && aux != "undefined") {
	            versionPlugSeg = aux;
	        }
	        aux = comp.CompVersion;
	        if (typeof(aux) != "undefined" && aux != "undefined") {
	            infPlugSeg = aux;
	        }
	        if(typeof(comp.GetId) != 'undefined') {
	            aux = comp.GetId(numControle);
				if (typeof(aux) != "undefined" && aux != "undefined") {
					dynId = aux;
				} else {
					dynId = "undefined";
				}		
	        }
		}
    } else {
        if(VrfComp("Conexao")) {
            aux = document.applets["Conexao"].Version;
            if (typeof(aux) != "undefined" && aux != "undefined") {
                versionPlugSeg = aux;
            }
            aux = document.applets["Conexao"].CompVersion;
            if (typeof(aux) != "undefined" && aux != "undefined") {
                infPlugSeg = aux;
            }
            if(typeof(document.applets["Conexao"].GetId) != 'undefined') {
                aux = document.applets["Conexao"].GetId(numControle);
    			if (typeof(aux) != "undefined" && aux != "undefined") {
    				dynId = aux;
    			} else {
    				dynId = "undefined";
    			}		
            }
        }
    }

      if (typeof instalacaoPlugin == 'boolean' && instalacaoPlugin) {
         $.ajax({
            type: 'POST',
            url: urlAutenticacao,
            data: obterParametrosAjaxVerifPlugSeg(versionPlugSeg, infPlugSeg, dynId),
            error: erroGlobal,
            success: resultadoVerifPlugSeg,
            timeout: ajaxTimeOut
         });
      } else {
   $('.loading:not(.inativo):last').removeClass('none_i');
      $.ajax({
         type: 'POST',
         url: urlAutenticacao,
         data: obterParametrosAjaxVerifPlugSeg(versionPlugSeg, infPlugSeg, dynId),
         error: erroGlobal,
         success: resultadoAutenticacaoDispositivoAtual,
         timeout: ajaxTimeOut
      });
   }
}
}

function resultadoVerifPlugSeg(respString, status) {
   // Controle de dupla execu��o do Ajax
   sobExecucaoAjax = false;

   // Processamento do retorno Ajax
   if (status == 'success') {
      try {
         // Processa a resposta do servidor
         respAutenticacaoDispAtual = eval ("(" + respString + ")");   

         if (respAutenticacaoDispAtual.sucesso) {
            var comp = document.getElementById("Conexao");
            if (isInfBar && respAutenticacaoDispAtual.sucessoWarning && comp.object == null) {
                $('#instala').removeClass("none_i");
                $('#instrucao').addClass("none_i"); 
            } else {
               //puxar p�gina do resultado.
               if (typeof urlProximoTipoAutenticacao == 'string' && typeof ajaxTimeOut == 'number' && !sobExecucaoAjax) {
                  // Controle de dupla execu��o do Ajax
                  sobExecucaoAjax = true;

                  // Obt�m o html do pr�ximo dispositivo via ajax
                  $.ajax({
                     type: 'POST',
                     url: urlProximoTipoAutenticacao.replace("nome=valor", respAutenticacaoDispAtual.parametroExtra),
                     data: {'infBar': isInfBar},
                     error: erroGlobal,
                     success: resultadoPlugSegInstRes,
                     timeout: ajaxTimeOut
                  });
               }
            }
         } else {
            // Tratamento da mensagem de erro
            if (respAutenticacaoDispAtual.msgs[0].campo == "geral" || respAutenticacaoDispAtual.msgs[0].campo == "global") {
               erroGlobal(null, respAutenticacaoDispAtual.msgs[0].msg, null);
            } else {
               var elementoMensagemErro;
               try {
                  elementoMensagemErro = $('#' + prepararSeletor(respAutenticacaoDispAtual.msgs[0].campo)).closest('.box_redLine_bottom').find('.erro_msg:not(.inativo):last');
               } catch (erroFind) {
}
               if (typeof elementoMensagemErro != 'undefined' && elementoMensagemErro.size() > 0) {
                  exibirMensagemErroForm(respAutenticacaoDispAtual.msgs[0].msg, elementoMensagemErro);
               } else {
                  exibirMensagemErroForm(respAutenticacaoDispAtual.msgs[0].msg);
               }
            }
         }
      } catch (erro) {
         erroGlobal(null, 'Problemas no processamento da resposta do servidor.', erro);
      }
   } else {
      erroGlobal(null, 'Problemas no processamento do servidor: ' + status, null);
   }
}

function resultadoPlugSegInstRes(respString, status) {
   // Controle de dupla execu��o do Ajax
   sobExecucaoAjax = false;

   // Processamento do resultado Ajax
   if (status == 'success') {
      substituirConteudo(respString);
   } else {
      erroGlobal(null, 'Problemas no processamento do servidor: ' + status, null);
   }
}


function visualizarModalAjax(valorAceite) {
   if (typeof urlProximoTipoAutenticacao == 'string' && typeof valorAceite == 'string' && typeof ajaxTimeOut == 'number' && !sobExecucaoAjax) {
      // Controle de dupla execu��o do Ajax
      sobExecucaoAjax = true;

      jQuery.ajax({
	      type: 'POST',
         url: urlProximoTipoAutenticacao,
         data: {'aceite': valorAceite},
	      error: erroGlobal,
         success: resultadoVisualizarModalAjax,
	      timeout: 100000
	   });
   }
	   return false;
}

function resultadoVisualizarModalAjax(respString, status) {
   // Controle de dupla execu��o do Ajax
   sobExecucaoAjax = false;

   // Processamento do Modal
   if (status == 'success') {
      showModalContent(respString);
   } else {
      erroGlobal(null, 'Problemas no processamento do servidor: ' + status, null);
   }
}

// especifico da inst. plugin  
function getInternetExplorerVersion()
{
    var rv = -1; 
    if (navigator.appName == 'Microsoft Internet Explorer') {
        var ua = navigator.userAgent;
        var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null) {
            rv = parseFloat( RegExp.$1 );
        }
    }
    return rv;
}
function infBar() {
    var ret;
    var ver = getInternetExplorerVersion();
    var sp2 = (navigator.userAgent.indexOf("SV1") >= 0);
    if ( ver >= 7 ||
        (ver == 6 && sp2)) {
        ret = true;
    } else {
        ret = false;
    }
    return ret;
}
var isInfBar = infBar();

function encodeAcentosJavascript(texto) {
	var y = document.createElement("span");
	y.innerHTML = texto;
	return y.innerHTML;
}

// seletor focaveis + modais,
jQuery.extend($.expr[':'], { 
  // clausula "||" para os modais � necess�ria pois permanecem invis�veis at� o ultimo instante.       	   
  focavel: function(element) {
      var nodeName = element.nodeName.toLowerCase(),
          tabIndex = $.attr(element, 'tabindex');
      
   return (/input|select|textarea|button|object/.test(nodeName)
    ? !element.disabled  : 'a' == nodeName || 'area' == nodeName
        ? element.href || !isNaN(tabIndex)
        : !isNaN(tabIndex))
	   // the element and all of its ancestors must be visible
	   // the browser may report that the area is hidden
	  && (!$(element)['area' == nodeName ? 'parents' : 'closest'](':hidden').length 
	     || element.className.indexOf('tabmodal') >= 0 );    
    }
	}); 

function cicularTabNoModal() {
	var $ = jQuery;
    var focaveis = $(':focavel'); 
    var focosModais = $('.tabmodal'); 

    // acha o tabindex do elemento anterior ao primeiro tabindex do modal
    var curelem = $(':focavel:*[tabindex=' + focosModais.eq(0).attr('tabindex') + ']').last();        
    var tabanterior = focaveis.eq((focaveis.index(curelem) - 1)).attr('tabindex');        

    // acha o tabindex do ultimo elemento do modal 
    var ultimotab = focosModais.eq((focosModais.size() - 1)).attr('tabindex');
    
    focosModais.keydown(function(e) {                     
        if (e.which == 9) {                                
            var newlist = $('.tabmodal');                              
            var first = $(':[tabindex=' + tabanterior + ']').last();  
            // acha o indice do ultimo elemento
            var ultimo = $('.tabmodal:[tabindex=' + ultimotab + ']').last();
            if ($(this).attr('tabindex') == ultimo.attr('tabindex')) {
                first.focus();
            }      
        }
    }); 	
}

function focoTituloModal() {   
    setTimeout(function() {
        jQuery('.modal-title').last().focus();
     }, 200);
}

//plugin seg - fim
