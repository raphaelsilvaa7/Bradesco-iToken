var arrayCodigosPai = new Array('S','P','T','C','L','E','I','B','Q','V','O');
var arrayCodigosNulo = new Array('H','N','X','G','D','M','U','Y','A','W');
var hiddenTabFirst = null;
var hiddenTabLast = null;
var btnImpressao = null; // null - imprime pagina completa
var printChecked = false; // true - imprime somente itens com checkbox marcado
var modalFadeIn = 400;
var modalWindowName = "modal_infra_estrutura";
var	mioloWindowName = "paginaCentral";
var inicializando = false;
var flagTabFirst = true;
var codigoTelaComPasso = null;
var codigoTela = null;
var numeroPasso = null;
var hndJanelaHomeBroker = null;
var linkAcessoRapidoDV = false;

(function ($) {

	// $(function(){ ... }) 
	//		� o mesmo que 
	// $(document).ready(function() { ... })
    $(function() {
		var re = /^([a-zA-Z]+)([\d]+)$/;
		codigoTelaComPasso = $(".txt-codigoTela").html();
		
		// IN�CIO - TRATAMENTO DO MENU SUPERIOR (PINTAR O ITEM ATIVO DE VERMELHO)
    	try {
    		var codigoTelaAtual = $.trim(codigoTelaComPasso);
    		var itemAtivado = false;
    		if (codigoTelaAtual != null && codigoTelaAtual != '') {
    			var siglaPaiAtual = codigoTelaAtual.substr(0, 1);
    			for (var i = 0; i < arrayCodigosPai.length; i++) {
    				if (siglaPaiAtual == arrayCodigosPai[i]) {
    					var itemAcionado = window.top.document.getElementById('topmenu_' + siglaPaiAtual);
    					$(".menuPrincipal li a.on", window.top.document).removeClass("on");
    					$(itemAcionado).addClass("on");
    					itemAtivado = true;
    					break;
    				}
    			}
    			if (itemAtivado == false) {
    				for (var i = 0; i < arrayCodigosNulo.length; i++) {
        				if (siglaPaiAtual == arrayCodigosNulo[i]) {
        					$(".menuPrincipal li a.on", window.top.document).removeClass("on");
        					break;
        				}
        			}
    			}
    		}
    	} catch (e) {
		}
    	// FIM - TRATAMENTO DO MENU SUPERIOR (PINTAR O ITEM ATIVO DE VERMELHO)

    	// IN�CIO - TRATAMENTO DE REFRESH DA MINI POSI��O FINANCEIRA E DA CALCULADORA
		try {
			var arrayCodigosRefresh = window.top.codigosRefreshMiniPosicaoCalculadora.split(",");
			var codigoTelaAtual = $.trim(codigoTelaComPasso);
			if (codigoTelaAtual != null && codigoTelaAtual != "") {
				for (var i = 0; i < arrayCodigosRefresh.length; i++) {
					if (codigoTelaAtual == arrayCodigosRefresh[i]) {
						try {
							window.top.atualizarMiniPosicaoFinanceira();
						} catch (e) {
						}
						try {
							window.top.atualizarInvestimentos();
						} catch (e) {
						}
						try {
							window.top.atualizarCartoes();
						} catch (e) {
						}
						break;
					}
				}
			}
		} catch (e) {
		}
		// FIM - TRATAMENTO DE REFRESH DA MINI POSI��O FINANCEIRA E DA CALCULADORA
    	
		// OBTEN��O DO C�DIGO DO SERVI�O E DO N�MERO DO PASSO...
		if (codigoTelaComPasso && codigoTelaComPasso.length && re.test(codigoTelaComPasso)) {
			codigoTela = RegExp.$1;
			numeroPasso = RegExp.$2;
		}
		else {
			codigoTelaComPasso = '';
		}
		
    	// FUN��ES P/ MODAL
    	// INICIA O PLUG-IN DO MODAL
    	$(".jqmWindow").jqm({
            modal: true,
    		onShow: initModal,
    		onHide: exitModal
    	});
    	
    	// Modal que impede fechamento da janela qdo clicar fora ou escape       
	  	$(".modalNaoFecha").jqm({
			modal: true,
	    	onShow: initModal,
	    	onHide: exitModal
	  	});
    
    	// COMBO
    	if (typeof($.combo) != "undefined")
    		$(".combo").combo();
    
        // CLASSE PARA ABRIR O MODAL AUTOMATICAMENTE
    	$(".openModal:not(.inativo .openModal)").live('click' , function(evt) {
    		$(".jqmWindow").jqmHide();
    		$(this).is("input") ? $($(this).attr("alt")).jqmShow() : $($(this).attr("href")).jqmShow();
    		evt.preventDefault();
    	});
    
        // CLASSE PARA FECHAR O MODAL
        $(".closeModal").click(function() {
						parent.fecharModalInfraEstrutura();
						//$(this).closest(".jqmWindow").jqmHide();
            return false;
        });
    
    	// FECHAR MODAL NO ESC
    	$(document).keypress(function(e){
    		if (e.keyCode == 27) {
    			if (parent && parent.fecharModalInfraEstrutura) {
					parent.fecharModalInfraEstrutura();
				}
				//$(".jqmWindow:visible").jqmHide();
				// incluido para funcionamento do modal da tela inicial/mensagem e avisos
        	// alterado para impedir o fechamento quando for modal que nao deve fechar
	    	$(".jqmWindow:visible:not(.modalNaoFecha)").jqmHide(); 	
    		}
    	});
        // FUN��ES P/ MODAL
    
    	// SENHA 4 DIGITOS
    	// EVENTO AO PRESSIONAR ESPACO
    	$('.btnKeyboardVirtual li * , .btnKeyboardVirtualSingle li *').live("keypress",function(e){
    		if (e.which == 32) {
    			$(this).click();
    		}
    	});
    
    	$('.limpar').click(function() {
    		$('.input_fields li input').attr('value', '');
    		$("#inativo").addClass("inativo");
    		$("#inativo").find('input').attr('disabled', 'disabled');
    		count = 0;
    	});
    
    	// CONSTRASTE
    	(function() {
    		var transparencias = new Array("0.25","0.35","0.6","1");
    		var index = 3;
    
    		var teclado = $(".btnKeyboardVirtualSingle li:not(.limpar) > div");
    		if (teclado.length == 0) teclado = $(".btnKeyboardVirtualSingle li:not(.limpar)");
    		$("#diminuiContraste").click(function(evt) {
    			if (index > 0)
    				teclado.animate({opacity:transparencias[(--index)]});
    			evt.preventDefault();
    		});
    		$("#aumentaContraste").click(function(evt) {
    			if (index < transparencias.length-1)
    				teclado.animate({opacity:transparencias[(++index)]});
    			evt.preventDefault();
    		});
    	})();
    
        // CONTADOR CARACTERES
    	$(".cont_caracteres").keyup(function() {
    		var idCampo = $(this).attr("id");
    		if (idCampo.indexOf(":") >= 0) {
    			idCampo = idCampo.split(":")[1];
    		}
    		try {
    			$("span.cont_" + idCampo).text("[" + ($(this).val().length) + "]");
    		}
    		catch(err) {
    		}
    	});
    
    	// Contagem regressiva
    	$(".cont_regr_caracteres").keyup(function() {
    		var idCampo = $(this).attr("id");
    		if (idCampo.indexOf(":") >= 0) {
    			idCampo = idCampo.split(":")[1];
    		}
    		try {
	    		$("span.cont_" + idCampo).text("[" + ($(this).attr("maxlength") - $(this).val().length) + "]");
    		}
    		catch(err) {
    		}
    	});
		// CONTADOR CARACTERES

		// TAMANHO DE FONTE

		// Verifica se a p�gina n�o est� utilizando o tamanho de fonte da AWB
		if ($("#UIFontSize").length == 0) {
			
			// Adi��o dos eventos .click nos bot�es de tamanho de fonte.
			var tamanhoFonte = [];
			var $aux = $(".listaPersonalizacao .tp2");
			
			if ($aux.length > 0) {

				tamanhoFonte[0] = $aux;
				tamanhoFonte[1] = $(".listaPersonalizacao .tp3");
				tamanhoFonte[2] = $(".listaPersonalizacao .tp4");

				for (var i = 0; i < tamanhoFonte.length; i++) {
					$(tamanhoFonte[i]).bind("click", {tamanho: i + 1}, function(event) {
						$(this).closest("ul").find("li").removeClass("On");
						$(this).addClass("On");
						// Altera o tamanho da fonte do conte�do da p�gina e das p�ginas dentro dos frames
						aplicaTamanhoFonte(event.data.tamanho);
						if (!inicializando) {
							salvaTamanhoFonte(event.data.tamanho, codigoTela, numeroPasso);
						}
					});
				}
			}
			
			// Recupera��o de tamanho de fonte de forma ass�ncrona.
			obtemTamanhoFonteConfiguradoAssincrono(codigoTela, numeroPasso);
		}

		// TAMANHO DE FONTE

        // EXPANS�VEIS LATERAL // #### HDA - Tratamento do expansivel de Apoio e Atendimento do menu lateral esquerdo para exibi��o/inibi��o do Assistente ####
    	$("#lateral dt a").not(".editar").click(function(evt) {
    		$(this).toggleClass("on");
			
			var objHDA =  $(this).parent().next().find(".hdaMenuLateral > .boxHDA");
			
    		if ($(this).hasClass("on")) {
    		// Expand
				$(this).parent().next().slideDown();
				if (hdaAtivado && hdaPosicao == 2 && $(this).parent().next(":has(.hdaMenuLateral)").length > 0) {
					objHDA.addClass("boxHDAOn");
					parent.alterarVisibilidadeHDA(true);
				}
				atualizarPersonalizacaoSideMenu($(this).parent().parent().attr("id"),"1");
    		} else {
    		// Collapse
				if (hdaAtivado && hdaPosicao == 2 && $(this).parent().next(":has(.hdaMenuLateral)").length > 0) {
					objHDA.removeClass("boxHDAOn");
					parent.alterarVisibilidadeHDA(false);
				}
				$(this).parent().next().slideUp();
				atualizarPersonalizacaoSideMenu($(this).parent().parent().attr("id"),"0");
    		}
    
    		evt.preventDefault();
    	});
    
    	// EXPANSIVEL AJUDA
    	$("#btn_ajuda").click(function() {
    		var btnAjuda = $(this);
    		var ajudaLeitura = $(".box-ajuda .ajuda-leitura");
    		if (btnAjuda.hasClass("active")) {
    			$(".box-ajuda").slideUp(300, function() {
    				btnAjuda.removeClass("active");
    				if (ajudaLeitura.length > 0) {
        			    btnAjuda.attr("tabindex", ajudaLeitura.attr("tabindex"));
        			    ajudaLeitura.removeAttr("tabindex");
	       			    btnAjuda.focus();
        			}
    			});
    		}
    		else {
    			btnAjuda.addClass("active");
    			$(".box-ajuda").slideDown(300, function() {
        			if (ajudaLeitura.length > 0) {
            			ajudaLeitura.attr("tabindex", btnAjuda.attr("tabindex"));
            			btnAjuda.removeAttr("tabindex");
            			ajudaLeitura.focus();
                    }
    			});
    		}
    	});
    
    	$(".box-ajuda .btn-fechar").click(function(){
    		$("#btn_ajuda").click();
    	});
    	
    	$(".box-ajuda .ajuda-leitura").keyup(function(e) {
    		if (e.which == 13) {
    			$("#btn_ajuda").click();
    		}
    	});
    	// EXPANSIVEL AJUDA
    
    	// FUN��ES PARA MENU LATERAL
        // SORTABLE
        $("#lateral").sortable({
            items: 'dl',
            handle: '.drag',
            placeholder: 'drop',
            revert: true,
            tolerance: 'intersect',
            start: function(event, ui) {
                ui.item.addClass("hover");
            },
            stop: function(event, ui) {
                ui.item.removeClass("hover");
				// #### HDA - Tem que referenciar o frame do HDA apos a movimentacao do bloco de apoio e atendimento ####
				if (hdaAtivado && hdaPosicao==2 && ui.item.attr("id") == "lateral_apoio_atendimento") {
					alterarPosicaoHDA(2, true);
				}
            }
        });
    
        // HOVER
        $("#lateral dt").hover(function() {
            $(this).find("a.editar, span.drag").addClass("visible");
        }, function() {
            $(this).find("a.editar, span.drag").removeClass("visible");
        });
        // FUN��ES PARA MENU LATERAL
    
        // LINKS INATIVOS
        $(".inativo a").live('click', function() {
            return false;
        });
        // LINKS INATIVOS
    
        // CAMPOS NUMERICOS
        $("input.numeric").live("keyup", function(e) {
    		if ($.checkKey(e)) {
    		   	// Obt�m a posi��o atual do cursor
    		   	var caretPos = $(this).caret();
   				var len = $(this).val().length;
    		   	// Substitui caracteres inv�lidos (no IE isso coloca o cursor no final do campo)
    			$(this).val($(this).val().replace(/\D/g, ""));
    		   	// Posiciona o cursor
    			$(this).caret(caretPos - (len - $(this).val().length));
    		}
        });
        // CAMPOS NUMERICOS

    	// CAMPOS DE MOEDA
    	$.inputCurrency = $(".inputCurrency");
    	$.inputCurrency.each(function(){
    		if($(this).val() == "") {
    			$(this).val("0,00");
    		}
    	});
    	$.inputCurrency.live("click focus", function(e) {
    		if($(this).val() == "0,00") {
    			$(this).val("");
    		}
    	});
    	$.inputCurrency.live("blur", function(e) {
			$(this).val(currencyFormatted($(this).val()));
			if ($(this).val().length == 0) {
    			$(this).val("0,00");
			}
			else if($(this).val().length <= 2) {
				if (parseInt($(this).val(), 10) == 0)
					$(this).val("0,00");
				else
					$(this).val($(this).val() + ",00");
			}
    	});
    	$.inputCurrency.live("keyup", function(e) {
    		if ($.checkKey(e)) {
    		   	// Obt�m a posi��o atual do cursor
    		   	var caretPos = $(this).caret();
   				var len = $(this).val().length;
    			$(this).val(currencyFormatted($(this).val().replace(/\D/g, "")));
    		   	// Posiciona o cursor
    		   	var caretNewPos = caretPos - (len - $(this).val().length);
    		   	if (caretNewPos < 0) caretNewPos = 0;
    			$(this).caret(caretNewPos);
    		}
    	});
    	// CAMPOS DE MOEDA
    
    	$.checkKey = function(e) {
    		var ret = false;
    		if (
                e.which !=  9 &&    /* tab */
                e.which != 13 &&    /* enter */ 
    		    e.which != 16 &&    /* shift */
    		    e.which != 17 &&    /* ctrl */
    		    e.which != 27 &&    /* esc */
    		    e.which != 35 &&    /* end */
    		    e.which != 36 &&    /* home */
    		    e.which != 37 &&    /* seta direcional esquerda */
    		    e.which != 38 &&    /* seta direcional cima */
    		    e.which != 39 &&    /* seta direcional direita */
    		    e.which != 40       /* seta direcional baixo */
    		   ) {
    		   	ret = true;
    		}
			return ret;
    	};
    	
        // AUTO TABINDEX
        var retry = false;
    	$.tabindex = function(v) {
    		var j, classes, re, bAjuste, ajuste, ti;
    		v = $.extend({index: 1, search: "body .tabindex", filter: ":not(font,table)"}, v);
    		var $itensTabindex = $(v.search + v.filter);
			var isFrameExterno = $("#" + mioloWindowName).length > 0 ? true : false;

    		if ($itensTabindex.length > 0) {
	            if (window.name == modalWindowName && !retry) {
	                //� janela modal, postergar processamento.
	                retry = true;
	                setTimeout("$.tabindex()", modalFadeIn + 100);
	            }
	
	            // Insere elementos para controle de navega��o entre �reas/frames
	            if (isFrameExterno) {
					var $aux1;
					var $aux2;
					var HTML_A = '<a href="javascript:;" title="" class="tabindex" style="font-size:1px;">&nbsp;</a>';
					var HTML_DIV = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />';

					var $topo = $("#topo");
					var $lateral = $("#miolo #lateral");
					var $rodape = $("#rodape");
					var $iframe = $("#miolo #paginaCentral");
					
					if ($topo.find("#topo_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "topo_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "topo_hiddentablast");
						$topo.prepend($aux1);
						$topo.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);
					} 

					if ($iframe.parent("div").find("#miolo_hiddentabbeforeout").length == 0) {
						$aux1 = $(HTML_A).attr("id", "miolo_hiddentabbeforeout");
						$aux2 = $(HTML_A).attr("id", "miolo_hiddentabbeforein");
						$iframe.before($aux1);
						$iframe.before($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);
						
						$aux1 = $(HTML_A).attr("id", "miolo_hiddentabafterout");
						$aux2 = $(HTML_A).attr("id", "miolo_hiddentabafterin");
						$iframe.after($aux1);
						$iframe.after($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);						
					} 

					if ($lateral.find("#lateral_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "lateral_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "lateral_hiddentablast");
						$lateral.prepend($aux1);
						$lateral.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);
					} 
					
					if ($rodape.find("#rodape_hiddentabfirst").length == 0) {
						$aux1 = $(HTML_A).attr("id", "rodape_hiddentabfirst");
						$aux2 = $(HTML_A).attr("id", "rodape_hiddentablast");
						$rodape.prepend($aux1);
						$rodape.append($aux2);
						$aux1.wrap(HTML_DIV);
						$aux2.wrap(HTML_DIV);
					} 
	        	}
	            else if (window.name != modalWindowName) {
					if (!document.getElementById('hiddentablast')) {
						hiddenTabFirst = $('<a href="javascript:;" title="" id="hiddentabfirst" class="tabindex" style="font-size:1px">&nbsp;</a>');
						hiddenTabLast = $('<a href="javascript:;" title="" id="hiddentablast" class="tabindex" style="font-size:1px">&nbsp;</a>');
						$("body").prepend(hiddenTabFirst);
						$("body").append(hiddenTabLast);
						hiddenTabFirst.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />');
						hiddenTabLast.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" />');
					}
	            }

				// Remove eventuais elementos criados para navega��o entre frames
	    		$(".tabindexBeforeFrame, .tabindexAfterFrame").remove();

	    		// Refaz a pesquisa para considerar as eventuais inclus�es e remo��es
	    		$itensTabindex = $(v.search + v.filter);
	    		$itensTabindex.each(function(i) {
	                // Verifica se � um iframe
	                if ($(this).is("iframe") && !(isFrameExterno && ($(this).attr("name") == mioloWindowName))) {
			            // Insere um link antes e outro depois do iframe para controle de navega��o entre os frames
						var $linkAntes = $('<a href="javascript:;" title="" style="font-size:1px">&nbsp;</a>').attr("tabindex", v.index++);
						var $linkDepois = $('<a href="javascript:;" title="" style="font-size:1px">&nbsp;</a>').attr("tabindex", v.index++);
						$(this).before($linkAntes).after($linkDepois);
						$linkAntes.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" class="tabindexBeforeFrame" />');
						$linkDepois.wrap('<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;" class="tabindexAfterFrame" />');
						$linkAntes.unbind("focus", colocaFocoFrame).bind("focus", {sentido: 0, seletor: v.search + v.filter}, colocaFocoFrame);
						$linkDepois.unbind("focus", colocaFocoFrame).bind("focus", {sentido: 2, seletor: v.search + v.filter}, colocaFocoFrame);
	                }
	                else {
		                bAjuste = false;
		                // Procura nas classes do elemento se existe uma no formato tab-N
		                classes = $(this).get(0).className.split(" ");
		                re = /^\u0074\u0061\u0062\u002d([\d]+)$/
		                for (j = 0; j < classes.length; j++) {
		                    if (re.test(classes[j])) {
		                        bAjuste = true;
		                        ajuste = parseInt(RegExp.$1, 10);
		                        break;
		                    }
		                }
		                if (bAjuste) {
		                    // Se o elemento possui a classe de ajuste tab-N, reposiciona os N elementos anteriores ...
		    	            for (var i = 1; i <= ajuste; i++) {
		    	                var $aux = $("[tabindex=" + (v.index - i) + "]");
		    	                var oldTabindex = parseInt($aux.attr("tabindex"), 10);
		    	                $aux.attr("tabindex", oldTabindex + 1);
		    	            }
		                    // ... e coloca o elemento na posi��o -N
		                    $(this).attr("tabindex", v.index++ - ajuste);
		                }
		                else {
		                    $(this).attr("tabindex", v.index++);
		                }
		            }
	    		});
	
	            // Ajusta a navega��o entre �reas
	            if (window.name != modalWindowName) {
	
	            	if (window.name == mioloWindowName) { 
						var $iframe = $("iframe[name=" + window.name + "]", window.parent.document);
						if ($iframe.length > 0) {
		                    hiddenTabFirst.unbind("focus", colocaFocoFrame).bind("focus", {sentido: 3, delta: 1, seletor: v.search + v.filter}, colocaFocoFrame);
		                    hiddenTabLast.unbind("focus", colocaFocoFrame).bind("focus", {sentido: 1, delta: 1, seletor: v.search + v.filter}, colocaFocoFrame);
						}
						else {
			        		var $tabfirst = $(".tabindex[tabindex=2]");
			        		var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
			        		if ($tablast.length > 0) {
			                    hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {destino: $tablast.get(0)}, colocaFoco);
			                }
			        		if ($tabfirst.length > 0) {
			                    hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {destino: $tabfirst.get(0)}, colocaFoco);
			                }
			            }
	            	}
					else if (window.parent != window) {
						var $iframe = $("iframe[name=" + window.name + "]", window.parent.document);
		        		if ($iframe.hasClass("tabindex")) {
		                    hiddenTabFirst.unbind("focus", colocaFocoFrame).bind("focus", {sentido: 3, seletor: v.search + v.filter}, colocaFocoFrame);
		                    hiddenTabLast.unbind("focus", colocaFocoFrame).bind("focus", {sentido: 1, seletor: v.search + v.filter}, colocaFocoFrame);
		        		}
		        		else {
			        		var $tabfirst = $(".tabindex[tabindex=2]");
			        		var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
			        		if ($tablast.length > 0) {
			                    hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {destino: $tablast.get(0)}, colocaFoco);
			                }
			        		if ($tabfirst.length > 0) {
			                    hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {destino: $tabfirst.get(0)}, colocaFoco);
			                }
						}
					}
					else if (isFrameExterno) {
						var $topo = $("#topo");
						var $topoItens = $topo.find(".tabindex");
						var $topoTabFirst = $topoItens.eq(1);
						var $topoTabLast = $topoItens.eq($topoItens.length - 2);

						var $lateral = $("#miolo #lateral");
						var $lateralItens = $lateral.find(".tabindex");
						var $lateralTabFirst = $lateralItens.eq(1);
						var $lateralTabLast = $lateralItens.eq($lateralItens.length - 2);
						
						var $rodape = $("#rodape");
						var $rodapeItens = $rodape.find(".tabindex");
						var $rodapeTabFirst = $rodapeItens.eq(1);
						var $rodapeTabLast = $rodapeItens.eq($rodapeItens.length - 2);

						// Topo --> Miolo
						$("#topo_hiddentablast").unbind("focus", colocaFoco).bind("focus", {destino: $("#miolo_hiddentabbeforein").get(0)}, colocaFoco);
						$("#miolo_hiddentabbeforein").unbind("focus", colocaFocoFrame).bind("focus", {sentido: 0, seletor: v.search + v.filter}, colocaFocoFrame);
						// Miolo --> Lateral
						$("#miolo_hiddentabafterout").unbind("focus", colocaFoco).bind("focus", {destino: $lateralTabFirst.get(0)}, colocaFoco);
						// Lateral --> Rodap�
						$("#lateral_hiddentablast").unbind("focus", colocaFoco).bind("focus", {destino: $rodapeTabFirst.get(0)}, colocaFoco);
						// Rodap� --> Topo
						$("#rodape_hiddentablast").unbind("focus", colocaFoco).bind("focus", {destino: $topoTabFirst.get(0)}, colocaFoco);

						// Topo <-- Miolo
						$("#miolo_hiddentabbeforeout").unbind("focus", colocaFoco).bind("focus", {destino: $topoTabLast.get(0)}, colocaFoco);
						// Miolo <-- Lateral
						$("#lateral_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {destino: $("#miolo_hiddentabafterin").get(0)}, colocaFoco);
						$("#miolo_hiddentabafterin").unbind("focus", colocaFocoFrame).bind("focus", {sentido: 2, seletor: v.search + v.filter}, colocaFocoFrame);
						// Lateral <-- Rodap�
						$("#rodape_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {destino: $lateralTabLast.get(0)}, colocaFoco);
						// Rodap� <-- Topo
						$("#topo_hiddentabfirst").unbind("focus", colocaFoco).bind("focus", {destino: $rodapeTabLast.get(0)}, colocaFoco);
					}
	            	else { 
		        		var $tabfirst = $(".tabindex[tabindex=2]");
		        		var $tablast = $(".tabindex[tabindex=" + (v.index - 2) + "]");
		        		if ($tablast.length > 0) {
		                    hiddenTabFirst.unbind("focus", colocaFoco).bind("focus", {destino: $tablast.get(0)}, colocaFoco);
		                }
		        		if ($tabfirst.length > 0) {
		                    hiddenTabLast.unbind("focus", colocaFoco).bind("focus", {destino: $tabfirst.get(0)}, colocaFoco);
		                }
	            	}
	        	}
	
	            // Descobre o elemento que deve receber o foco inicial
	    		var $tabfocus = $itensTabindex.filter(".tabfirst:visible").last();
	    		if ($tabfocus.length == 0) {
	    		    $tabfocus = $itensTabindex.filter("[tabindex=2]").last();
	    		}
	    		if ($tabfocus.length > 0) {
	                try {
                        if (flagTabFirst && !($("#txtPesquisar", top.document).hasClass("focoPesquisar"))) {
                            setTimeout(function() {
                                // Refaz verifica��o do pesquisar caso o campo receba o foco durante a espera do timeout
                                if (!($("#txtPesquisar", top.document).hasClass("focoPesquisar"))) {
                                    $tabfocus.focus();
                                }
                            }, 800);
                        }
	                }
	                catch (err) {
					}
	    		} 
	    	}
    	};
    	
    	// Fun��o auxiliar utilizada para o repasse de foco
    	// A propriedade data do objeto de evento cont�m as seguintes informa��es
    	//	- destino: elemento DOM que deve receber o foco
    	function colocaFoco(evt) {
    		try {
    			evt.data.destino.focus();
    		}
    		catch (err) {
    		}
    	}
    	
    	// Fun��o auxiliar utilizada para o repasse de foco entre frames
    	// A propriedade data do objeto de evento cont�m as seguintes informa��es
    	//	- sentido: 0 = do frame externo para o frame interno no sentido normal (tab)
    	//			   1 = do frame interno para o frame externo no sentido normal (tab)
    	//			   2 = do frame externo para o frame interno no sentido reverso (shift+tab)
    	//			   3 = do frame interno para o frame externo no sentido reverso (shift+tab)
    	//	- seletor: seletor a ser utilizado para encontrar os elementos dentro do frame
    	//	- delta: delta a ser considerado na identifica��o do elemento a partir do frame
    	colocaFocoFrame = function(evt) {
    		var destino = null
    		var pos;
    		var $iframe, $itens, $itensAux, $aux;
    		var delta = (evt.data.delta != undefined) ? evt.data.delta : 0;
    		
    		switch (evt.data.sentido) {
    			case 0:
    				try {
		    			$iframe = $(this).parent().next();
		    			$itens = $(evt.data.seletor, $iframe.get(0).contentWindow.document);
		    			if ($itens.length > 0) {
		    				destino = $itens.filter("[tabindex=2]").get(0);
		    			}
		    		}
		    		catch (err) {
		    		}
	    			if (destino == null) {
	    				$itens = $(evt.data.seletor);
	    				pos = $itens.index($iframe);
	    				for (var i = pos + 1; i < $itens.length; i++) {
	    					$aux = $itens.eq(i);
			    			if ($aux.is(":visible") && !($aux.attr("disabled") == true))
			    				break;
		    			}
		    			destino = $aux.get(0);
	    			}
	    			break;
				case 1:
					$itens = $(evt.data.seletor, window.parent.document);
	    			if ($itens.length == 0)
	    				return;
	    			$iframe = $("iframe[name=" + window.name + "]", window.parent.document);
	    			pos = $itens.index($iframe);
    				for (var i = pos + delta + 1; i < $itens.length; i++) {
    					$aux = $itens.eq(i);
		    			if ($aux.is(":visible") && !($aux.attr("disabled") == true))
		    				break;
	    			}
					destino = $aux.get(0);
					break;
    			case 2:
					try {
		    			$iframe = $(this).parent().prev();
		    			$itens = $iframe.get(0).contentWindow.jQuery.itensTabIndex();
		    			if ($itens.length > 0) {
			    			var itens = ordenaPorTabindex($itens.toArray());
			    			$aux = $(itens[itens.length - 2]);
							if ($aux.is("iframe")) {
								$itensAux = $aux.get(0).contentWindow.jQuery.itensTabIndex();
				    			var itensAux = ordenaPorTabindex($itensAux.toArray());
				    			$aux = $(itensAux[itensAux.length - 2]);
							}
							destino = $aux.get(0);
		    			}
					}
		    		catch (err) {
		    		}
	    			if (destino == null) {
	    				$itens = $(evt.data.seletor);
	    				pos = $itens.index($iframe);
	    				for (var i = pos - 1; i >= 0; i--) {
	    					$aux = $itens.eq(i);
			    			if ($aux.is(":visible") && !($aux.attr("disabled") == true))
			    				break;
		    			}
		    			destino = $aux.get(0);
	    			}
	    			break;
				case 3:
					$itens = $(evt.data.seletor, window.parent.document);
	    			if ($itens.length == 0)
	    				return;
	    			$iframe = $("iframe[name=" + window.name + "]", window.parent.document);
	    			pos = $itens.index($iframe);
    				for (var i = pos - delta - 1; i >= 0; i--) {
    					$aux = $itens.eq(i);
		    			if ($aux.is(":visible") && !($aux.attr("disabled") == true))
		    				break;
	    			}
					destino = $aux.get(0);
	    			break;
	    		default:
	    			return;
    		}
    		
    		evt.data.destino = destino;
    		colocaFoco(evt);
    	}
    	
		var p_itensTabIndex = null;
		$.itensTabIndex = function() {
			if (p_itensTabIndex == null) {
				// O IE cria por default o atributo tabindex com valor igual a 0 para todos os n�s do DOM,
				// enquanto o FF cria os elementos sem o atributo. Por isso, n�o existe um seletor comum.
				// Assim, testa-se primeiro qual filtro deve ser usado. Um retorna os elementos corretos e
				// o outro retorna todos os n�s. Logo, utiliza-se o que retorna menos itens.
				var $itens1 = $("[tabindex]");
				var $itens2 = $("[tabindex!=0]");
				p_itensTabIndex = ($itens1.length < $itens2.length) ? $itens1 : $itens2;
			}
			return p_itensTabIndex;
		}
		
		function ordenaPorTabindex(vetorDom) {
			var retorno = vetorDom;
			retorno.sort(function(a, b) {
			   var compA = parseInt($(a).attr("tabindex"), 10);
			   var compB = parseInt($(b).attr("tabindex"), 10);
			   return (compA < compB) ? -1 : (compA > compB) ? 1 : 0;
			});
			return retorno;
		}

    	// AUTO TABINDEX
    	
	    // TOOLTIP
	    $.criaTooltips = function() {
		    if ($.fn.tooltip) {
		    
		    	$(".loging_Tip,.senha_Tip,.nome_Tip,.lstUtil li a:not([id='btn_ajuda'])," +
		    	  ".ico_1line_Tip,.ico_2lines_Tip,.ico_3lines_Tip,.ico_4lines_Tip,.ico_5lines_Tip," +
				  ".auto_Tip")
				  .tooltip({ 
		    		extraClass: "tooltip_auto"
		    	});
		    
		    	$("#btn_ajuda").tooltip({ 
		    		extraClass: "tooltip_auto",
		    		top: 8
		    	});
		    	
		    	// Acesso rapido
		    	var $tipAcesso = $("sup.tooltip");
		    	if ($tipAcesso.length > 0) {
			    	var titleAcesso = $tipAcesso.attr("title");
			    	if (titleAcesso == "") {
	    		   		titleAcesso = 'Para acessar as opera��es mais r�pido, selecione a tecla "A"';
	    		   		$tipAcesso.attr("title", titleAcesso);
	    		   	}
	    		   	
					// Inclui um link invis�vel para leitura pelo Virtual Vision, uma vez que o title
					//	do elemento � removido pelo plug-in de tooltip
		    		if (!linkAcessoRapidoDV) {
			    		titleAcesso = titleAcesso.replace(/\"/gi, "");
	    		   		var $linkAcesso = $("<a>").attr("href", "javascript:;").attr("title", titleAcesso).attr("class", "tabindex");
	    		   		$tipAcesso.before($linkAcesso);
	    		   		linkAcessoRapidoDV = true;
					}
					
			    	$tipAcesso.tooltip({
			    		extraClass: "tooltip_acesso_rapido"
			    	});
			    }
			}
	    }
	    // TOOLTIP

		// TROCA FOCO
        $("input:not(.naotrocafoco)").live("keyup", function(e) {
            if ($(this).attr("maxlength") > 0 &&
            	$(this).caret() >= $(this).attr("maxlength") &&
                $.checkKey(e)) {

                var thisTabIndex = parseInt($(this).attr("tabindex"), 10);
				var $itens = $.itensTabIndex();
				var nextTabIndex = thisTabIndex + 1;
                var proximoCampo = null;
                while (true) {
                    if (nextTabIndex > $itens.length) {
                        nextTabIndex = 1;
                    }
                	else if (nextTabIndex == thisTabIndex) {
                		proximoCampo = null;
                		break;
                	}
    				
    				proximoCampo = $itens.filter("[tabindex=" + nextTabIndex + "]");
    				
    				if (proximoCampo.length == 0) {
    					proximoCampo = null;
    					break
    				}
    				else if ((!proximoCampo.is(":visible") || proximoCampo.attr("disabled") == true) && !proximoCampo.hasClass("ajaxFocus")) {
                        nextTabIndex = nextTabIndex + 1;
                    }
                    else {
                        break;
                    }
				}
                if (proximoCampo != null) {
	                this.blur();
	                if (proximoCampo.is(":button") || proximoCampo.is(":submit") || proximoCampo.is(":image")) {
	                    proximoCampo.focus();
	                }
	                else {
	                    proximoCampo.focus();
	                    proximoCampo.select();
	                }
	            }
            }
        });
        // TROCA FOCO
    
    	// LIMPA CAMPO NO FOCO
    	$("input.clearField,textarea.clearField").each(function() {
    		// Foco
    		$(this).focus(function() {
    			if ($(this).val() == $(this).attr("title"))
    				$(this).val("");
    
    		// Blur
    		}).blur(function() {
    			if ($(this).val() == "")
    				$(this).val($(this).attr("title"));
    		});
    	});
    	// LIMPA CAMPO NO FOCO
        
        //VERIFICA SE CAMPO PESQUISAR RECEBEU OU NAO O FOCO
        $("#txtPesquisar", top.document).unbind("focus");
        $("#txtPesquisar", top.document).unbind("blur");
        $("#txtPesquisar", top.document).bind({
            focus: function() {
                $(this).addClass("focoPesquisar");
            },
            blur: function() {
                $(this).removeClass("focoPesquisar");
            }
        });
        
        //VERIFICA SE CAMPO PESQUISAR RECEBEU OU NAO O FOCO
        
    	// TAMANHO COLUNA
		var l;
		if (window.parent.$ && window.parent.$('#lateral')) {
			l = window.parent.$('#lateral').outerHeight();
		} else {
			l = 800;
		}
		//var l = window.parent.$('#lateral').outerHeight();
    	var c = $('#conteudo').outerHeight();   
   		var i = $('#conteudo .topo').height() + $('#conteudo .base').height();
   		l = l - (i + 10);
   		if (l > 0) {
	   		if (typeof document.body.style.maxHeight === "undefined") {
	   			if (c < l) {   			
	   				$('#conteudo .miolo:first').css('height', (l) + "px");
	   			}
	   		} else {
	   			$('#conteudo .miolo:first').css('min-height', (l) + "px");
	   		}
	   	}
    	// TAMANHO COLUNA
    	
    	// LINKS EXTERNOS
    	$("a[rel*='external']").click(function(evt) {
    		window.open($(this).attr("href"));
    		evt.preventDefault();
    	});
    	// LINKS EXTERNOS
    
    	// ORDENACAO DE TABELAS
    	$("tr.ordenacao_tabela a").click(function(evt) {
    		$(this).parents("tr").find("a").not(this).removeClass("sortAsc").removeClass("sortDesc");
    		if ($(this).hasClass("sortAsc")) {
    			$(this).removeClass("sortAsc");
    			$(this).addClass("sortDesc");
    		} else {
    			$(this).addClass("sortAsc");
    			$(this).removeClass("sortDesc");
    		}
    		var u = $(this).attr('href');
    		if( u == "#"){			
    			evt.preventDefault();
    		}
    	});
    	// ORDENACAO DE TABELAS
    
    	// IMPRESSAO
    	$("a[rel*='btn_imprimir']").click(function(evt) {
    		$(".printBlock").removeClass("printImportant");
    		if ($(this).hasClass("imprimeIndividual")) {
    			btnImpressao = $(this);
    			btnImpressao.parents(".printBlock").addClass("printImportant");
    		} else if ($(this).hasClass("bt_print")) {
    			printChecked = true;
    		} else {
    			printChecked = false;
    			btnImpressao = null;
    		}
    		evt.preventDefault();
    	});
    
    	$(".ico-imprimir").click(function(e) {
    		$(this).parents("tr").next().find("a[rel*='btn_imprimir']").click();
    
    		e.stopPropagation();
    		e.preventDefault();
    	});
    
    	// SCROLL TO
    	$(".scrollTo").live("click",function(evt){
    		var posTop = $($(this).attr("href")).offset().top;
    		$("html, body").animate({"scrollTop":posTop},500);
    		evt.preventDefault();
    	});
    	
    	// TABELAS COM HOVER 
    	$('.tabCollapse tbody .linhaConta').hover(
    		function(){
    			$(this).addClass('over');
    		},
    		function(){
    			$(this).removeClass('over');
    		}
    	);
    
    	// SETA O CHECK BOX DA LINHA DA TABELA
    	$('.tabCollapse tbody .linhacheck input:checkbox , .tabCollapse tbody .tdCheck input:checkbox').click(function(evt){
    		evt.stopPropagation();
    	});
    	
    	$('.tabCollapse tbody .linhacheck').click(function(){
    		if ($(this).find('input').is(':checked')){
    			$(this).find('input').not(':disabled').attr('checked','');
    		}else{
    			$(this).find('input').not(':disabled').attr('checked','checked');
    		}
    	});
    	
    	$('thead input:checkbox').click(function(){
    		if($(this).is(":checked")){
    			$('tbody').find('input').not(':disabled').attr('checked','checked');
    		}else{
    			$('tbody').find('input').not(':disabled').attr('checked','');
    		}
    	});
    
        // ATIVA FORMULARIO
        $(".ativa_formulario, .ativa_formulario_txt").blur(function() {
    		var loading = $(this).parents(".formulario").find('.loading');
    		loading.removeClass('none_i');
    		setTimeout(function(){
    			$(".inativo").removeClass("inativo").find('input:not(.disabled)').attr('disabled', '');
    			loading.addClass('none_i');
    		} , 2000);
        });
    
    	$("input.limpaCampo,textarea.limpaCampo").each(function() {
    		// Foco
    		$(this).focus(function() {
                if (($(this).attr("title_ori") != undefined && $(this).val() == $(this).attr("title_ori"))
					|| ($(this).attr("limpa_campo") != undefined && $(this).val() == $(this).attr("limpa_campo"))) {
    				$(this).val("");
    			} else if ($(this).val() == $(this).attr("title")) {
    				$(this).val("");
                }
    
    		// Blur
    		}).blur(function() {
    			if ($(this).val() == "") {
					if ($(this).attr("limpa_campo") != undefined) {
						 $(this).val($(this).attr("limpa_campo"));
                    } else if ($(this).attr("title_ori") != undefined) {
                        $(this).val($(this).attr("title_ori"));
                    } else {
						$(this).val($(this).attr("title"));
                    }
                }
    		});
    	});
    	
    	// EXPAND COLLAPSE
    
    	$(".btn_collapse").click(function(evt) {
    		var conteudo = $(this).next();
    		var btnCollapse = $(this);
    		
    		if (conteudo.is(":visible")) {
    			conteudo.slideUp(500,function() {
    				btnCollapse.removeClass("btn_collapse_on");
    			});
    		} else {
    			btnCollapse.addClass("btn_collapse_on");
    			conteudo.slideDown(500);
    		}
    
    		evt.preventDefault();
    	});
    
    	// Tabelas expans�veis
    	$(".tabela-expansivel .expansor td:not(.check, .icone, .noClick)").click(function(){
    		var $tbody = $(this).closest("tbody");
    		var $box = $tbody.find(".box-expansivel");
    		var $callback = $tbody.find(".box-expansivel-callback");
    		var $callbackTable = $tbody.closest("table").prev(".tabela-expansivel-callback");
    		
    		if ($box.is(":hidden")) {
    			$(".tabela-expansivel .box-expansivel").hide();
    			$(".tabela-expansivel tbody")
    				.removeClass("ativo hover")
    				.find(".expansivel").hide();
    			$tbody.addClass("ativo").find(".expansivel").show();
    			$box.slideDown(400, function() { // 400 is default
					if (window.parent.autoIframe) {
						window.parent.autoIframe();
					}
					$callback.click();
					$callbackTable.click();
				});
    		}
    		else {
    			$box.slideUp(function (){
    				$tbody.removeClass("ativo").find(".expansivel").hide();
					if (window.parent.autoIframe) {
						window.parent.autoIframe();
					}
					$callback.click();
					$callbackTable.click();
    			});
    		}
    	});
    
    	$(".tabela-expansivel .expansor td").hover(function(){
    		var $tbody = $(this).parents("tbody");
    		
    		if (!$tbody.hasClass("ativo")) $tbody.addClass("hover");
    	}, function(){
    		$(this).parents("tbody").removeClass("hover");
    	});
    	
    	$(".tabela-expansivel th:contains(a)").click(function(){
    		$(this).siblings().removeClass("desc asc");
    		if ($(this).hasClass("desc")) {
    			$(this)
    				.removeClass("desc")
    				.addClass("asc");
    		} else {
    			$(this)
    				.removeClass("asc")
    				.addClass("desc");
    		}
    	});
    	//Tabelas expans�veis
    
    	// #### HDA - Expansivel no login, pagina inicial avancada e modal - para lateral, ver expansivel do Apoio e Atendimento ####
		$(".boxHDA").each(function(i) {

			var objHDA = $(this);

			// Expande / Minimiza
			objHDA.find(".btnExpandCollapse").click(function(evt) {
				var obj = $(this).next(); // Conteudo que abre

				if (obj.is(":visible")) {
					// Minimiza
					objHDA.removeClass("boxHDAOn");
					parent.alterarVisibilidadeHDA(false);
					setTimeout(function() { $(this).next().slideUp(); }, 500);
				} else {
					// Expande
					$(this).next().slideDown();
					parent.alterarVisibilidadeHDA(true);
					objHDA.addClass("boxHDAOn");
					
					// #### HDA - Evento incluido para tratar o primeiro n� executado ao carregar a p�gina de login (ou clique no bot�o para exibir HDA) ####
					if (typeof onHDASlideDown == "function") {
						setTimeout("onHDASlideDown()", 700);
					}
				}
				evt.preventDefault();
			});
		});

        //memorizar foco anterior
        $('a,:input').focus(function(evt){
            top.currentFocus = this;
        });
        
        //inserir elemento inicial e final para controle de tab autom�tico para janela modal
        if(window.name == modalWindowName) {
            var divPre = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;"><a href="javascript:;" title="" class="tabindex focoUltimo" style="font-size:1px">&nbsp;</a></div>';
            var divPos = '<div style="height:1px;width:1px;position:absolute;top:0px;left:0px;"><a href="javascript:;" title="" class="tabindex focoPrimeiro" style="font-size:1px">&nbsp;</a><a href="javascript:;" title="" class="focoPrimeiro" style="font-size:1px">&nbsp;</a></div>';
            $("body").prepend(divPre);
            $("body").append(divPos);
            $(".focoUltimo").focus(function(evt) {
                setTimeout("focoUltimo();", 10);
            });
            $(".focoPrimeiro").focus(function(evt) {
                setTimeout("focoPrimeiro();", 10);
            });
        }
	    
	    // DATE PICKER
	    if ($.fn.datePicker) {
		    var visivel = new Array();
		    var $ico_calendario = $(".ico_calendario");
		    if ($ico_calendario.size() > 0) {
		    	Date.format = 'dd/mm/yyyy';
		    	$ico_calendario.each(function() {
		            visivel[$(this).closest(".dataCalendario").attr("id")] = false;
		        });
		    	$ico_calendario.datePicker({
					createButton: false,
					startDate: '01/01/1900'
				})
				.click(function(evt) {
		    		if ((!$(this).parent().parent().hasClass("inativo")) && (!$(this).parent().parent().parent().hasClass("inativo"))) {
		    			var $dataCalendario = $(this).closest(".dataCalendario");
		    			//-----------------------------------------------------------------------
		    			// Configura o per�odo se estiver definido no mesmo DIV do calend�rio
		    			var dataInicial = $dataCalendario.find(".dataInicial").val();
		    			var dataFinal = $dataCalendario.find(".dataFinal").val();
		    			if (dataInicial != 'undefined')
		    				$(this).dpSetStartDate(dataInicial);
		    			if (dataFinal != 'undefined')
		    				$(this).dpSetEndDate(dataFinal);
		    			//-----------------------------------------------------------------------
		    			// Atribui uma data ao calend�rio caso os campos de dia, m�s e ano j� estejam preenchidos
		        		var dia = $.trim($dataCalendario.find(".dia").val());
		        		var mes = $dataCalendario.find(".mes").val();
		        		var ano = $dataCalendario.find(".ano").val();
			            if (dia != "" && dia.length == 2 && mes != "" && mes.length == 2 && ano != "" && ano.length == 4) {
							$(this).dpSetSelected(dia + "/" + mes + "/" + ano);
		    			}
		    			//-----------------------------------------------------------------------
		    			$(this).dpDisplay();
		    			evt.preventDefault();
		    		}
		    	
		    	})
		    	.bind("dateSelected", function(e, selectedDate, $td, state) {
		    		// Quando uma data � selecionada, atualiza os campos de input
		    		var $dataCalendario = $(this).closest(".dataCalendario");
	    			var arrDataSel = arrDate(selectedDate);
	        		var elDia = $dataCalendario.find(".dia");
	        		var elMes = $dataCalendario.find(".mes");
	        		var elAno = $dataCalendario.find(".ano");
	    
	    			$(elDia).val(arrDataSel[0]);
	    			$(elMes).val(arrDataSel[1]);
	    			$(elAno).val(arrDataSel[2]);
	    			
	    			removerErroCampoCal(elDia);
	    			removerErroCampoCal(elMes);
	    			removerErroCampoCal(elAno);
	    			
	    	        $(elDia).closest(".campos_form").removeClass("form_erro")
	    	                .find(".erro_msg").html("<strong></strong>");
	
					var $onDS = $dataCalendario.find("#OnDateSelected");
					if ($onDS.length > 0) {
						eval($onDS.val());
					}
				})
				.bind("dpDisplayed", function(event, datePickerDiv) {
					visivel[$(this).closest(".dataCalendario").attr("id")] = true;
				})
				.bind("dpClosed", function(event, selected) {
					visivel[$(this).closest(".dataCalendario").attr("id")] = false;
				});
		        
		    	$("input.dia, input.mes, input.ano").each(function() {

		        	$(this).click(function(evt) {
	                    var $dataCalendario = $(this).closest(".dataCalendario");
	                    var $icoCalendario = $dataCalendario.find(".ico_calendario");
		        		if (!visivel[$dataCalendario.attr("id")])
		        			$icoCalendario.click();
					});
		            
		        	$(this).focus(function(evt) {
	                    var $dataCalendario = $(this).closest(".dataCalendario");
	                    var $icoCalendario = $dataCalendario.find(".ico_calendario");

					    var dia = $.trim($dataCalendario.find("input.dia").val());
			            var mes = $.trim($dataCalendario.find("input.mes").val());
			            var ano = $.trim($dataCalendario.find("input.ano").val());
			            
			            if (dia == "" || mes == "" || ano == "") {
							var d = new Date();
							$icoCalendario
								.dpSetSelected("00/00/0000")
								.dpSetDisplayedMonth(d.getMonth(), d.getFullYear());
			            }

		            	// Utiliza timer, pois na valida��o de algumas aplica��es primeiro � colocado
		            	// o foco no campo de dia e s� depois � colocada a formata��o de erro
		            	setTimeout(function() {$icoCalendario.dpClose().click()}, 10);
					});

			        $(this).blur(function(evt){
	                    var $dataCalendario = $(this).closest(".dataCalendario");
	                    var $icoCalendario = $dataCalendario.find(".ico_calendario");
	
					    var dia = $.trim($dataCalendario.find("input.dia").val());
			            var mes = $.trim($dataCalendario.find("input.mes").val());
			            var ano = $.trim($dataCalendario.find("input.ano").val());
	
			            if (validaDataDigitada(this, evt)) {
				            if (dia != "" && dia.length == 2 && mes != "" && mes.length == 2 && ano != "" && ano.length == 4) {
				                $icoCalendario.dpSetSelected(dia + "/" + mes + "/" + ano);
								var $onDS = $dataCalendario.find("#OnDateSelected");
								if ($onDS.length > 0) {
									var selectedDate = new Date(parseInt($icoCalendario.dpGetSelected(), 10));
									eval($onDS.val());
								}
				            }
			            }
			            else {
							var d = new Date();
							$icoCalendario
								.dpSetSelected("00/00/0000")
								.dpSetDisplayedMonth(d.getMonth(), d.getFullYear());
			            }
					});

		    	    $(this).keyup(function(evt) {
		           		if ($.checkKey(evt)) {
							validaDataDigitada(this, evt);
		                }
		        	});
		        	
		    	});
		    
		        function validaDataDigitada(el, evt) {
					var $camposForm = $(el).closest(".campos_form");
                    var $dataCalendario = $(el).closest(".dataCalendario");
                    var $icoCalendario = $dataCalendario.find(".ico_calendario");

                    var bErroAnterior = false;
                    var erro = "";
                    var erroDia = false;
                    var erroMes = false;
                    var erroAno = false;
                    var erroLimite = false;
                    var contErro = 0;
                    var prefixoErro = "";

                    if ($camposForm.hasClass("form_erro")) {
                        bErroAnterior = true;
                    }
                    
                    var elDia = $dataCalendario.find(".dia");
                    var elMes = $dataCalendario.find(".mes");
                    var elAno = $dataCalendario.find(".ano");
                    
                    var dia = $(elDia).val();
                    var mes = $(elMes).val();
                    var ano = $(elAno).val();
        
                    if ($(el).hasClass("dia") && ((dia == "0") || (dia == "1") || (dia == "2") || (dia == "3")) && (evt.type == "keyup")) {
                    	dia = "";
                    }
                    else if ((dia != "") && (dia.length < 2)) {
                    	dia = "0";
                    }
                    
                    if ($(el).hasClass("mes") && ((mes == "0") || (mes == "1")) && (evt.type == "keyup")) {
                    	mes = "";
                    }
                    else if ((mes != "") && (mes.length < 2)) {
                    	mes = "0";
                    }
                    
                    if ($(el).hasClass("ano") && (ano.length < 4) && (evt.type == "keyup")) {
                    	ano = "";
                    }
                    else if ((ano != "") && (ano.length < 4)) {
                    	ano = "0";
                    }
                    
                    if (dia != "") dia = parseInt(dia, 10); else dia = -1;
                    if (mes != "") mes = parseInt(mes, 10); else mes = -1;
                    if (ano != "") ano = parseInt(ano, 10); else ano = -1;
        
                    // Identifica os campos com erro
                    if ((dia == 0) || (dia > 31)) {
                        erroDia = true;
                        contErro++;
                    }
                    else if ((dia > 30) && ((mes == 4) || (mes == 6) || (mes == 9) || (mes == 11))) {
                        erroDia = true;
                        erroMes = true;
                        contErro = contErro + 2;
                    }
                    else if (mes == 2) {
                        if (dia > 29) {
                            erroDia = true;
                            erroMes = true;
                            contErro = contErro + 2;
                        }
                        else if ((dia == 29) && !((ano < 0) || (ano % 4 == 0) && ((ano % 100 != 0) || (ano % 400 == 0)))) {
                            erroDia = true;
                            erroMes = true;
                            erroAno = true;
                            contErro = contErro + 3;
                        }
                    }
                    
                    if ((!erroMes) && ((mes == 0) || (mes > 12))) {
                        erroMes = true;
                        contErro++;
                    }
                    
                    if ((!erroAno) && (ano == 0)) {
                        erroAno = true;
                        contErro++;
                    }
            
                    // Formata a mensagem de erro
                    if (erroDia) {
                        erro = "O dia";
                    }
                    if (erroMes) {
                        if (erroDia && !erroAno) erro = erro + " e o m�s";
                        else if (!erroDia) erro = "O m�s";
                        else erro = erro + ", o m�s";
                    }
                    if (erroAno) {
                        if (erro != "") erro = erro + " e o ano";
                        else erro = "O ano";
                    }
                    
                    if (contErro == 1)
                    	erro = erro + " informado � inv�lido.";
                    else if (contErro > 1)
                    	erro = erro + " informados s�o inv�lidos.";
                	else if ((dia > 0) && (mes > 0) && (ano > 0)) {
						var $onDS = $dataCalendario.find("#OnDateSelected");
		    			if ($onDS.length > 0) {
							var dataSelecionada = new Date(ano, mes - 1, dia);
			    			var dataInicial = $dataCalendario.find(".dataInicial").val();
			    			var dataFinal = $dataCalendario.find(".dataFinal").val();
							var dataAux = new Date();
							if (dataInicial != undefined) {
								dataAux = new Date(parseInt(dataInicial.substring(6, 10), 10),
												   parseInt(dataInicial.substring(3, 5), 10) - 1,
												   parseInt(dataInicial.substring(0, 2), 10));
								if (dataSelecionada < dataAux) {
									erro = "A data deve ser maior ou igual a " + dataInicial + ".";
									contErro = 1;
									erroLimite = true;
								}
							}
							else if (dataFinal != undefined) {
								dataAux = new Date(parseInt(dataFinal.substring(6, 10), 10),
												   parseInt(dataFinal.substring(3, 5), 10) - 1,
												   parseInt(dataFinal.substring(0, 2), 10));
								if (dataSelecionada > dataAux) {
									erro = "A data deve ser menor ou igual a " + dataFinal + ".";
									contErro = 1;
									erroLimite = true;
								}
							}
		    			}
	                }

                    // Aplica a formata��o e a mensagem de erro nos campos individuais
                    if (erroDia) {
                        incluirErroCampoCal(elDia, erro, prefixoErro);
                        if ($(el).hasClass("dia")) evt.stopImmediatePropagation();
                    }
                    else {
                        removerErroCampoCal(elDia);
                    }
                    
                    if (erroMes) {
                        incluirErroCampoCal(elMes, erro, prefixoErro);
                        if ($(el).hasClass("mes")) evt.stopImmediatePropagation();
                    }
                    else {
                        removerErroCampoCal(elMes);
                    }
            
                    if (erroAno) {
                        incluirErroCampoCal(elAno, erro, prefixoErro);
                        if ($(el).hasClass("ano")) evt.stopImmediatePropagation();
                    }
                    else {
                        removerErroCampoCal(elAno);
                    }

					if (erroLimite) {
                        incluirErroCampoCal(elDia, erro, prefixoErro);
                        incluirErroCampoCal(elMes, erro, prefixoErro);
                        incluirErroCampoCal(elAno, erro, prefixoErro);
						evt.stopImmediatePropagation();
					}

                    if (contErro > 0) {
	                    // Aplica a formata��o e a mensagem de erro no grupo de campos
                        incluirErroGrupoCampos($camposForm.get(0), erro);
                        if (!bErroAnterior && (evt.type == "keyup")) {
                            // Renderiza novamente o calend�rio para ajustar a posi��o
                            $icoCalendario.dpClose().click();
                        }
                        return false;
                    }
                    else {
	                    // Remove a formata��o e a mensagem de erro do grupo de campos
                        removerErroGrupoCampos($camposForm.get(0));
                        if (bErroAnterior && (evt.type == "keyup")) {
                            // Renderiza novamente o calend�rio para ajustar a posi��o
                            $icoCalendario.dpClose().click();
                        }
                        return true;
                    }
		        }
		        
		        $(".tabindex:not(input.dia, input.mes, input.ano, .ico_calendario)").focus(function(evt) {
				    $ico_calendario.dpClose();
				});
				
		    	function arrDate(dataSelect){
		    		date = new Date(dataSelect);
		    		var d = date.getDate();
		    		var m = date.getMonth() + 1;
		    		var y = date.getFullYear();
		    
		    		if(d < 10)
		    			d = "0" + d;
		    		if(m < 10)
		    			m = "0" + m;
		    
		    		var arr = new Array(d , m , y);
		    		return arr;
		    	}
		    }
		}
	    
	    $('#servico_concessonaria').change(function(){
	    	$('#loading_concessonaria').removeClass('none_i');
	    
	    	setTimeout(function(){
	    		$('#loading_concessonaria').addClass('none_i');
	    	
	    	},1000)
	    	
	    });
	    
	    
	    $('#estConc').change(function(){
	    	$('#loading_concessonaria').removeClass('none_i');
	    
	    	var vl = $(this).val();
	    	
	    	setTimeout(function(){
	    		$('#loading_concessonaria').addClass('none_i');
	    		if (vl == 'sp'){
	    			$('#ConcSaoPaulo').show();
	    			$('#ConcRio').hide();
	    		}
	    		if (vl == 'rj'){
	    			$('#ConcSaoPaulo').hide();
	    			$('#ConcRio').show();
	    		}
	    	
	    	
	    	},1000)
	    
	    });
	    
	    /* 
	     * Substitui os "label for" por "span" para contornar o problema 
	     * do Virtual Vision ler o label e o title na navega��o por setas
	     */
	    $("label:not([class*=naoSubstituirLabel])").each(function() {
	        var caracteresEspeciaisSeletores = "#;&,.+*~\':\"!^$[]()=>|";
	        var vFor = $(this).attr("for");
	        var vHtml = $(this).html();
	        var vClass = $(this).attr("class");
	        var vStyle = $(this).attr("style");
	        var vId = $(this).attr("id");
	        
	        // Cria o elemento "span"
	        var $span = $("<span>");
	        // Atribui ao elemento "span" os atributos necess�rios
	        $span.addClass("label");
	        if ((vClass != undefined) && (vClass != "")) $span.addClass(vClass);
	        if ((vStyle != undefined) && (vStyle != "")) $span.attr("style", vStyle);
	        if ((vId != undefined) && (vId != "")) $span.attr("id", vId);
	        $span.html(vHtml);
	
	        if ((vFor != undefined) && (vFor != "")) {
	            // "Escapa" o valor do atributo "for" para poder utilizar no seletor do jQuery
	            var i, c, p;
	            for (i = 0; i < caracteresEspeciaisSeletores.length; i++) {
	                c = caracteresEspeciaisSeletores.substring(i, i + 1);
	                p = vFor.indexOf(c);
	                while (p > -1) {
	                    vFor = vFor.substring(0, p) + "\\" + vFor.substring(p);
	                    p = p + 2;
	                    p = vFor.indexOf(c, p);		
	                }
	            }       
	            
	            try {
	                // Localiza o elemento referenciado pelo atributo "for"
	                var $alvo = $("#" + vFor);
	        
	                // Atribui ao "span" um evento onClick que simula o comportamento do "label"
	                $span.click(function() {
	                    try {
	                        if (!$alvo.is(":disabled")) {
	                            $alvo.focus().select();
	                            if ($alvo.is(":checkbox")) {
	                                if($alvo.is(":checked")) {
	                                    $alvo.removeAttr("checked");
	                                } else {
	                                    $alvo.attr("checked", "checked");
	                                }
	                                $alvo.change();
	                                $alvo.triggerHandler("click");
	                            }
	                            else if ($alvo.is(":radio")) {
	                                var change = false;
	                                if($alvo.is(":checked")) {
	                                } else {
	                                    change = true;
	                                }
	                                $alvo.attr("checked", "checked");
	                                if (change) {
	                                    $alvo.change();
	                                }
	                                $alvo.triggerHandler("click");
	                            }
	                        }
	                    }
	                    catch(err) {
	                    }	
	                });
	            }
	            catch(err) {
	            }	
	        }
	
	        // Substitui o "label" pelo "span"
	        $(this).replaceWith($span);
	
		});
		
	    // TABELA ABRE/FECHA
	    $(function(){
	    	$(".tabAbreFecha tr.click").click(function(){
	    		$(this).parent("tbody").find("div.expansible").slideToggle();
	    		$(this).parent("tbody").toggleClass("clicked");
	    	});
	    
	    	$(".tabAbreFecha tr.click").hover(function(){
	    		$(this).addClass("over");
	    	},function(){
	    		$(this).removeClass("over");
	    	});
	    
	        // TABELA CEDENTES
	    	
	         //ORDENA��O TH TABLE
	    	 $(".tabOrdena thead tr th a.sortDesc").live("click",function(evt) { 	
	    		$(this).removeClass("sortDesc");
	    		$(this).addClass("sortAsc");
	    		evt.preventDefault();
	    	});
	    	
	    	$(".tabOrdena thead tr th a.sortAsc").live("click",function(evt) { 	
	    		$(this).removeClass("sortAsc");
	    		$(this).addClass("sortDesc");
	    		evt.preventDefault();
	    	});
	    	
	    	$(".tabOrdena thead tr th a.sortOff").live("click",function(evt) { 			
	    		$(".tabOrdena thead tr th a").each(function() {
	    			$(this).addClass("sortOff");
	    			$(this).removeClass("sortDesc");
	    			$(this).removeClass("sortAsc");
	    		});
	    		$(this).removeClass("sortOff");
	    		$(this).addClass("sortDesc");
	    		evt.preventDefault();
	    	});
	         //ORDENA��O TH TABLE
	    
	    });

		// HOR�RIOS E LIMITES
		
		// CODIGO DO SERVI�O E N�MERO DE TELA J� OBTIDOS NESTE PONTO...
		
		var $btnHorariosLimites = $(".btn_horarios_limites");
		$btnHorariosLimites.click(function(evt) {
		
    		var status = $(this).hasClass("active");
    		var box = $(this).parent().next();

    		$(this).toggleClass("active");

    		if (status) {
    			box.slideUp(200);
    		}
    		else {
    			box.slideDown(200);
    		}

			salvaStatusHorarioLimite(!status, codigoTela, numeroPasso);
    	});
		
		// Inicializa��o
		
		if ($btnHorariosLimites.length > 0 && codigoTela && numeroPasso) {
			obtemStatusHorarioLimiteConfigurado(codigoTela, numeroPasso, callbackObtencaoHorariosLimites);
		}
		
		// HOR�RIOS E LIMITES
		
	    // ACESSO R�PIDO
		$(document).keypress(function(e) {
			if ($(e.target).is(":input") || $('.jqmWindow').is(":visible") || $("#txtPesquisar", top.document).hasClass("focoPesquisar")) return;
			if (e.which == 97 || e.which == 65) {
				top.abrirAcessoRapido();
				return false;
			};
        });
	    // ACESSO R�PIDO
    
    });

    $(window).load(function(){
	   	$.criaTooltips();
    	if(!$('.semAutoTab').length){
    		$.tabindex();
    	}
    	$('#lateral_apoio_atendimento a').removeAttr('tabindex');
    });
    
    function initModal(hash){
        //guardar o foco atual
        top.focusStack.push(top.currentFocus);
    	var ww = $(window).width();
    	var wh = $(window).height();
    	var mw = hash.w.width();
    	var mh = hash.w.height();
    	var ws = $(window).scrollTop();
    	var x = mw > ww ? 0 : (ww - mw) /2;
    	var y = mh > wh ? (ws) : ws + ((wh - mh) / 2);
    
    	hash.w.css({
    		top : y,
    		left : x
    	})
    	.fadeIn(modalFadeIn);

    };
    
    // FUN��ES P/ FINALIZAR MODAL
    function exitModal(hash){
    	hash.o.hide();
    	hash.w.hide();
		
		//retornar foco anterior
        try {
            var focusAux = top.focusStack.pop();
            if (focusAux != null) {
                focusAux.focus();
            }
         } catch (err) {
         }
    };
    
    /** $.highLight();
     * Fun��o que retorna uma string com o termo procurado fazendo colocando em volta <strong>
     *
     * Op��es de edi��o
     * value : (string) String a ser procurada o term.
     * term : (string) Termo procurado. Caso encontrado ser� colocado em volta <strong>.
     */
     
    $.highLight = function(value, term) {
    	return value.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + term.replace(/([\^\$\(\)\[\]\{\}\*\.\+\?\|\\])/gi, "\\$1") + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<strong>$1</strong>");
    };
    
    $.extend($.expr[':'], {
    	containsI : function(elem, i, match, array) {
    		return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    	}
    });

	$.fn.caret = function(pos) {
		var el = $(this).get(0);
	    var caretPos;
	    if (pos >= 0) {
	        caretPos = pos;
		    if (document.selection) { // IE 
		        var range;
		        range = document.selection.createRange();
		        if (el.type == 'text' || el.type == 'password') { // textbox
		            range.moveStart ('character', -el.value.length);
		            range.moveEnd ('character', -el.value.length) ;
		            range.moveStart ('character', caretPos);
		            range.select();
		        }
		        else { // textarea
		            range.collapse(false);
		            range.move ('character', caretPos - el.value.length + el.value.substring(caretPos).split('\n').length - 1);
		            range.select();
		        }
		    }
		    else if (el.selectionStart || el.selectionStart == '0') { // Firefox
		        el.setSelectionRange(caretPos, caretPos);
		    }
	    }
	    else {
	    	caretPos = 0;
		    if (document.selection) { // IE hack
		        if (el.type == 'text' || el.type == 'password') { // textbox
		            var selectionRange = document.selection.createRange();
		            selectionRange.moveStart ('word', -el.value.length);
		            caretPos = selectionRange.text.length;
		        }
		        else { // textarea
		            caretPos = Math.abs(document.selection.createRange().moveStart("character", -1000000)) - 193;
		        }
		    }
		    else if (el.selectionStart || el.selectionStart == '0') { // Firefox
		        caretPos = el.selectionStart;
		    }
		    return caretPos;
	    }
	}

})(jQuery);

var currentFocus = null;
var focusStack = [];

function focoPrimeiro() {
    var tabindex = jQuery(".tabindex");
    var tabfirst = jQuery(".tabindex[tabindex=2]");
    if (tabfirst.length > 0) {
        tabfirst[0].focus();
    }
}

function focoUltimo() {
    var tabindex = jQuery(".tabindex");
    if (tabindex.length > 1) {
		var index = tabindex.length - 1;
		for(; index > 0 ; index--) {
			var tablast = jQuery(".tabindex[tabindex=" + index + "]:visible");
			if (tablast.length > 0) {
				tablast[0].focus();
				break;
			}	
		}
    }
}

//tratamento de encerramento de sess�o.
function analisaExibicaoErroSessao(resposta) {
	var regexS = 'var urlTriggerFimSessao = "([^"]*)";';
	var regex = new RegExp( regexS );
	var results = regex.exec(resposta);
	if( results != null ) {
		//desativar autoEncerra
		if (top.disableAutoEncerra) {
			top.disableAutoEncerra();
		}		
		window.top.location = results[1];
		return true;
	} else {
		return false;
	}
}
if (typeof(A4J) != "undefined") {
	A4J.AJAX.onError = function(req, status, message){
		if (status == 401) {
			analisaExibicaoErroSessao(req.getResponseText());
		}
	}
}
var flagDisableAjaxSessionEnd = false;
function disableAjaxSessionEnd() {
            flagDisableAjaxSessionEnd = true;
}
jQuery(document).ajaxError(function(event, xmlHttpRequest, ajaxOptions, thrownError) {
	try{
		if (xmlHttpRequest.status == 401 && ! flagDisableAjaxSessionEnd) {
			analisaExibicaoErroSessao(xmlHttpRequest.responseText);
		}
	} catch(err) {}
	flagDisableAjaxSessionEnd = false;
});
//p�gina de fone f�cil 
function fonefacil() {
    url = "http://www.bradesco.com.br/indexpf.phtml?pag=/html/content/centrais/fone_facil.shtm";
    if (typeof(isPrime) != "undefined") {
        if (isPrime) {
            url = "http://www.bradescoprime.com.br/Conteudo/centrais/fone.aspx";
        }
    }
    window.open(url, "popup")
    return false;
}

//p�gina de fale conosco
function popupFaleconosco() {
	var params =  "width=820,height=505,toolbar=no,copyhistory=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,top=0,left=0";
    var url = "https://institucional.bradesco.com.br/NETFaleConosco/site/conteudo/home/default.aspx?site=1";
    if (typeof(isPrime) != "undefined") {
        if (isPrime) {
            params =  "width=820,height=505,resizable=yes,scrollbars=yes,tollbar=0,menubar=0,top=0,left=0";
            url = "https://institucional.bradesco.com.br/NETFaleConosco/site/conteudo/perguntas/default.aspx?site=12";
        }
    }
    window.open(url, "popup", params);
    return false;
}


// TAMANHO DE FONTE

var seletorTamanhoFonte = "#conteudo > .miolo";
var classesTamanhoFonte = "mioloFs12 mioloFs13 mioloFs14";
var prefixoClasseTamanhoFonte = "mioloFs1";

// Aplica os estilos para alterar o tamanho de fonte
function aplicaTamanhoFonte(tamanho) {

	var tamanhoAux = "" + (tamanho + 1);

	try {
	    jQuery(seletorTamanhoFonte, document.body).removeClass(classesTamanhoFonte).addClass(prefixoClasseTamanhoFonte + tamanhoAux);
	}
	catch (err) {
		return;
	}
    // Aplica o tamanho de fonte aos frames da p�gina
   	aplicaTamanhoFonteFrames(window, tamanho);
}

function aplicaTamanhoFonteFrames(janela, tamanho) {

	var tamanhoAux = "" + (tamanho + 1);

    for (var i = 0; i < janela.frames.length; i++) {
		try {
		    
		    jQuery(seletorTamanhoFonte, janela.frames[i].document.body).removeClass(classesTamanhoFonte).addClass(prefixoClasseTamanhoFonte + tamanhoAux);
		    
		    aplicaTamanhoFonteFrames(janela.frames[i], tamanho);

			var $iframe = $("iframe[name=" + janela.frames[i].name + "]", janela.document);
			$iframe.attr("height", janela.frames[i].document.getElementById("conteudo").scrollHeight + "px");

		}
		catch (err) {
			return;
		}
    }
	if(janela.parent.autoIframe) {
		janela.parent.autoIframe();
	}
}

// Verifica se existe alguma p�gina acima da atual que tenha o controle de tamanho de fonte
function existeTamanhoFonte(janela) {
    var encontrou = false;
	try {
	    if ((jQuery(".listaPersonalizacao .tp2", janela.document.body).length > 0) || (jQuery("#UIFontSize", janela.document.body).length > 0)) {
	        encontrou = true;
		}
	    else if (janela.parent != janela) {
			encontrou = existeTamanhoFonte(janela.parent);
		}
	}
	catch (err) {
		encontrou = false;
	}
	return encontrou;
}

function callbackObtencaoTamanhoFonte(categoriaPersonalizacao) {
	try {
		if (categoriaPersonalizacao != null) {
			var conteudo;
			for (iConteudo = 0 ; iConteudo  < categoriaPersonalizacao.length ; iConteudo++) {
				conteudo = categoriaPersonalizacao[iConteudo];
				if(conteudo && jQuery.trim(conteudo.getChave()) == "tamanho") {
					tamanhoFonte = conteudo.getValor();
					break;
				}
			}
		}
		if ((tamanhoFonte == null) || (tamanhoFonte == "") || (isNaN(tamanhoFonte))) tamanhoFonte = "1";
		
	} catch(err) {
		tamanhoFonte = obtemCookie("tamanhoFonte");
		if ((tamanhoFonte == null) || (tamanhoFonte == "") || (isNaN(tamanhoFonte))) tamanhoFonte = "1";
		return(parseInt(tamanhoFonte, 10));
	}
	var tamanhoFonteRecuperado = (parseInt(tamanhoFonte, 10));
	
	var tamanhoFonte = [];
	var $aux = jQuery(".listaPersonalizacao .tp2");
	var seletorTamanhoFonte = "#conteudo > .miolo";
	if ($aux.length > 0) {

		tamanhoFonte[0] = $aux;
		tamanhoFonte[1] = jQuery(".listaPersonalizacao .tp3");
		tamanhoFonte[2] = jQuery(".listaPersonalizacao .tp4");
		// Click salva apenas ap�s inicializado o tamanho de fonte.
		inicializando = true;
		jQuery(tamanhoFonte[tamanhoFonteRecuperado - 1]).click();
		inicializando = false;
		
	}
	else {
		// Se a p�gina n�o cont�m o controle tamanho de fonte, verifica se n�o est� dentro
		// de um frame de uma p�gina que o cont�m
		if ((window.parent != window) && (existeTamanhoFonte(window.parent))) {
			// Inicializa��o
			aplicaTamanhoFonte(tamanhoFonteRecuperado);
		}
	}
	if (window.parent.autoIframe) {
		window.parent.autoIframe();
	}
}

// Obt�m o tamanho de fonte configurado. Poss�veis valores: 1, 2 ou 3
function obtemTamanhoFonteConfiguradoAssincrono(codigoTela, numeroPasso) {
	var personalizacao = getComponentePersonalizacao();
	personalizacao.obterCategoria("ibpf.geral.tamanhoFonte", codigoTela, numeroPasso, callbackObtencaoTamanhoFonte);
}

// Obt�m o tamanho de fonte configurado. Poss�veis valores: 1, 2 ou 3
function obtemTamanhoFonteConfigurado(codigoTela, numeroPasso) {
	var tamanhoFonte = null;
	try {
		var personalizacao = getComponentePersonalizacao();
		var categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.geral.tamanhoFonte", codigoTela, numeroPasso);
		if (categoriaPersonalizacao != null) {
			var conteudo;
			for (iConteudo = 0 ; iConteudo  < categoriaPersonalizacao.length ; iConteudo++) {
				conteudo = categoriaPersonalizacao[iConteudo];
				if(conteudo && jQuery.trim(conteudo.getChave()) == "tamanho") {
					tamanhoFonte = conteudo.getValor();
					break;
				}
			}
		}
		if ((tamanhoFonte == null) || (tamanhoFonte == "") || (isNaN(tamanhoFonte))) tamanhoFonte = "1";
	} catch(err) {
		tamanhoFonte = obtemCookie("tamanhoFonte");
		if ((tamanhoFonte == null) || (tamanhoFonte == "") || (isNaN(tamanhoFonte))) tamanhoFonte = "1";
		return(parseInt(tamanhoFonte, 10));
	}
	return(parseInt(tamanhoFonte, 10));
}

// Salva o tamanho de fonte selecionado
function salvaTamanhoFonte(tamanho, codigoTela, numeroPasso) {
	try {
		var personalizacao = getComponentePersonalizacao();
		var arrayConteudo = new Array();
		arrayConteudo.push(new Conteudo("tamanho", tamanho));
		personalizacao.salvarCategoriaArray("ibpf.geral.tamanhoFonte", arrayConteudo, codigoTela, numeroPasso);
	} catch(err) {
		setaCookie("tamanhoFonte", "", -1);
		setaCookie("tamanhoFonte", "", -1, "/");
		setaCookie("tamanhoFonte", tamanho, 365, "/", document.domain);
	}
}

// Fun��o "ponte" entre componente da AWB e infra do site
function inicializaUIFontSize(param) {
	var state = JSON.stringify({fontSize: obtemTamanhoFonteConfigurado(codigoTela, numeroPasso)});
	return state;
}

// Fun��o "ponte" entre componente da AWB e infra do site
function salvaUIFontSize(param) {
	var state = JSON.parse(param["state"]);
	salvaTamanhoFonte(state.fontSize);
	if (window.parent.autoIframe) {
		setTimeout("window.parent.autoIframe()", 300);
	}
}

// Fun��o "ponte" entre componente da AWB e infra do site
function callbackUIFontSize(param) {
	var tamanho = parseInt(param.newClass.substr(param.newClass.length - 1, 1), 10);
	aplicaTamanhoFonteFrames(window, tamanho);
}
// TAMANHO DE FONTE

// HORARIOS E LIMITES

// Obt�m o status da �rea expans�vel de hor�rios e limites. Poss�veis valores: true (= aberto) e false (= fechado)

function callbackObtencaoHorariosLimites(categoriaPersonalizacao) {
	
	var statusHorariosLimites = null;
	try {
		if (categoriaPersonalizacao != null) {
			var conteudo;
			for (iConteudo = 0 ; iConteudo  < categoriaPersonalizacao.length ; iConteudo++) {
				conteudo = categoriaPersonalizacao[iConteudo];
				if(conteudo && jQuery.trim(conteudo.getChave()) == codigoTelaComPasso) {
					statusHorariosLimites = conteudo.getValor();
					break;
				}
			}
		}
		if ((statusHorariosLimites == null) || (statusHorariosLimites == "")) statusHorariosLimites = "true";
	} catch(err) {
		var nomeCookie = "horariosLimites" + (jQuery.trim(codigoTelaComPasso) != "" ? "." + codigoTelaComPasso : "");
		var statusHorariosLimites = obtemCookie(nomeCookie);
		return !(statusHorariosLimites === "false");
	}
	var statusHorariosLimitesRecuperado = !(statusHorariosLimites === "false");
	
	var statusHorariosLimites = statusHorariosLimitesRecuperado;
	jQuery(".btn_horarios_limites").each(function() {
		var box = jQuery(this).parent().next();
		if (!statusHorariosLimites) {
			jQuery(this).removeClass("active");
			box.hide();
		}
	});
	if (window.parent.autoIframe) {
		window.parent.autoIframe();
	}
}

function obtemStatusHorarioLimiteConfigurado(codigoTela, numeroPasso, callback) {
	var personalizacao = getComponentePersonalizacao();
	personalizacao.obterCategoria("ibpf.geral.horariosLimites", codigoTela, numeroPasso, callback);
}

// Salva o status da �rea expans�vel de hor�rios e limites
function salvaStatusHorarioLimite(status, codigoTela, numeroPasso) {
	try {
		var personalizacao = getComponentePersonalizacao();
		var arrayConteudo = new Array();
		arrayConteudo.push(new Conteudo(codigoTela + numeroPasso, status));
		personalizacao.salvarCategoriaArray("ibpf.geral.horariosLimites", arrayConteudo, codigoTela, numeroPasso);
	} catch(err) {
		var nomeCookie = "horariosLimites" + (jQuery.trim(codigoTelaComPasso) != "" ? "." + codigoTelaComPasso : "");
		setaCookie(nomeCookie, status, 365, "/", document.domain);
	}
}

var tempCallbackUICollapsibleArea = null;

// Fun��o "ponte" entre componente da AWB e infra do site
function inicializaUICollapsibleArea(param) {
	tempCallbackUICollapsibleArea = param["asyncFunc"];
	obtemStatusHorarioLimiteConfigurado(codigoTela, numeroPasso, callbackUICollapsibleArea);
}

// Fun��o "ponte" entre componente da AWB e infra do site
function salvaUICollapsibleArea(param) {
	var state = JSON.parse(param["state"]);
	salvaStatusHorarioLimite(state.collapsed == 'false', codigoTela, numeroPasso);
	if (window.parent.autoIframe) {
		setTimeout("window.parent.autoIframe()", 300);
	}
}

// Fun��o "ponte" entre componente da AWB e infra do site
function callbackUICollapsibleArea(categoriaPersonalizacao) {
	var statusHorariosLimites = null;
	var collapsed = "";
	try {
		if (categoriaPersonalizacao != null) {
			var conteudo;
			for (iConteudo = 0; iConteudo  < categoriaPersonalizacao.length; iConteudo++) {
				conteudo = categoriaPersonalizacao[iConteudo];
				if (conteudo && jQuery.trim(conteudo.getChave()) == codigoTelaComPasso) {
					statusHorariosLimites = conteudo.getValor();
					break;
				}
			}
		}
		if ((statusHorariosLimites == null) || (statusHorariosLimites == "")) statusHorariosLimites = "true";
	}
	catch(err) {
		var nomeCookie = "horariosLimites" + (jQuery.trim(codigoTelaComPasso) != "" ? "." + codigoTelaComPasso : "");
		statusHorariosLimites = obtemCookie(nomeCookie);
	}
	statusHorariosLimites = !(statusHorariosLimites === "false");
	collapsed = "" + !statusHorariosLimites;
	var state = JSON.stringify({collapsed: collapsed});
	tempCallbackUICollapsibleArea(state);
	if (window.parent.autoIframe) {
		setTimeout("window.parent.autoIframe()", 300);
	}		
}

// HORARIOS E LIMITES

// CALEND�RIO

function incluirErroCampoCal(domElement, mensagem, prefixoErro) {
    jQuery(domElement).each(function() {
        jQuery(this).addClass("erro_input");
        if (jQuery(this).attr("title") == undefined) jQuery(this).attr("title", "");
        if (jQuery(this).attr("title_ori") == undefined) jQuery(this).attr("title_ori", jQuery(this).attr("title"));
        jQuery(this).attr("title", prefixoErro + mensagem + " " + jQuery(this).attr("title_ori"));
    });
}

function removerErroCampoCal(domElement) {
    jQuery(domElement).each(function() {
        jQuery(this).removeClass("erro_input");
        jQuery(this).attr("title", jQuery(this).attr("title_ori"));
    });
}

function incluirErroGrupoCampos(domElement, mensagem) {
    jQuery(domElement).addClass("form_erro").find(".erro_msg").html("<strong>" + mensagem + "</strong>");
}

function removerErroGrupoCampos(domElement) {
    jQuery(domElement).removeClass("form_erro").find(".erro_msg").html("<strong></strong>");
}

// Fun��o "ponte" entre componente da AWB e infra do site
function aplicaFormatacaoCalendario(parameterMap) {
	
	var prefixoIdMensagem = "UICalendar_";
	var sufixoIdMensagem = "error";
	
	if (parameterMap["type"] != undefined) {
		// Valida��o de um campo de data
		
		var elDia = parameterMap["dayObject"];
		var elMes = parameterMap["monthObject"];
		var elAno = parameterMap["yearObject"];
		
		var erroDia = (parameterMap["day"] == "INVALID");
		var erroMes = (parameterMap["month"] == "INVALID");
		var erroAno = (parameterMap["year"] == "INVALID");
		var erroLimInf = (parameterMap["period"] == "SMALLER");
		var erroLimSup = (parameterMap["period"] == "BIGGER");
		var erroCal = !parameterMap["overall"];
		var dataAux;
	
		var elForm = jQuery(elAno).closest(".campos_form").get(0);
		
		var prefixoErro = replaceAscii(obtemMensagemBundle(parameterMap["bundleFunction"], parameterMap["bundlePrefix"], "UICalendar_title_prefix"));
		if ((prefixoErro != "") && (prefixoErro.substring(prefixoErro.length - 1) != " ")) prefixoErro += " ";

		var idMensagem = "";
		var mensagem = "";

		if (erroDia || erroMes || erroAno) {
			if (erroDia) idMensagem += "day_";
			if (erroMes) idMensagem += "month_";
			if (erroAno) idMensagem += "year_";
			idMensagem = prefixoIdMensagem + idMensagem + sufixoIdMensagem;
			mensagem = replaceAscii(obtemMensagemBundle(parameterMap["bundleFunction"], parameterMap["bundlePrefix"], idMensagem));
		
			if (erroDia)
				incluirErroCampoCal(elDia, mensagem, prefixoErro);
			else
				removerErroCampoCal(elDia);
		
			if (erroMes)
				incluirErroCampoCal(elMes, mensagem, prefixoErro);
			else
				removerErroCampoCal(elMes);
		
			if (erroAno)
				incluirErroCampoCal(elAno, mensagem, prefixoErro);
			else
				removerErroCampoCal(elAno);
		}
		else if (erroLimInf) {
			erroCal = true;
			dataAux = parameterMap["mindate"];
			idMensagem = prefixoIdMensagem + "lower_limit_" + sufixoIdMensagem;
			mensagem = replaceAscii(obtemMensagemBundle(parameterMap["bundleFunction"], parameterMap["bundlePrefix"], idMensagem));
			mensagem = mensagem.replace("{0}", formataData(dataAux));
		}
		else if (erroLimSup) {
			erroCal = true;
			dataAux = parameterMap["maxdate"];
			idMensagem = prefixoIdMensagem + "upper_limit_" + sufixoIdMensagem;
			mensagem = replaceAscii(obtemMensagemBundle(parameterMap["bundleFunction"], parameterMap["bundlePrefix"], idMensagem));
			mensagem = mensagem.replace("{0}", formataData(dataAux));
		}

		if (erroCal)
			incluirErroGrupoCampos(elForm, mensagem);
		else
			removerErroGrupoCampos(elForm);
	}
	else  {
		// Valida��o de um per�odo

		var erroPer = !parameterMap["period"];
		var elDiaID = "#" + parameterMap["beginDayID"].replace(":", "\\:");
		
		var elForm = jQuery(elDiaID).closest(".campos_form").get(0);
		if (erroPer) {
			idMensagem = prefixoIdMensagem + "period_" + sufixoIdMensagem;
			mensagem = replaceAscii(obtemMensagemBundle(parameterMap["bundleFunction"], parameterMap["bundlePrefix"], idMensagem));
			incluirErroGrupoCampos(elForm, mensagem);
		}
		else
			removerErroGrupoCampos(elForm);
	}

}

function formataData(data) {
	var dia = ("00" + data.getDate())
	dia = dia.substr(dia.length - 2, 2);
	var mes = ("00" + (data.getMonth() + 1));
	mes = mes.substr(mes.length - 2, 2)
	var ano = data.getFullYear();
	return dia + "/" + mes + "/" + ano;
}

function obtemMensagemBundle(funcao, prefixo, chave) {
	var bundle = new Function("return " + funcao + "();")();
	var mensagem = bundle[prefixo + chave];
	if (mensagem == null || mensagem == undefined)
		mensagem = bundle[chave];
	if (mensagem == null || mensagem == undefined)
		mensagem = "";
	return mensagem;
}

function replaceAscii(texto) {
	var ini = texto.indexOf('&#');
	var fin = texto.indexOf(';', ini);
	while (ini >= 0 && fin > ini) {
		var ascii = texto.substring(ini + 2, fin);
		if (ascii > 0) {
			var str = String.fromCharCode(ascii);
			texto = texto.replace('&#' + ascii + ';', str);
		}
		ini = texto.indexOf('&#', ini + 1);
		fin = texto.indexOf(';', ini);
	}
	return texto;
}
// CALEND�RIO

// COOKIES
// 	Fun��es necess�rias, pois em alguma situa��es os componentes AWB
//  chamam as fun��es de callback quando script jquery.cookie ainda n�o foi carregado
function setaCookie(nome, valor, diasExp, caminho, dominio) {
	var dataExp = new Date();
	if (diasExp) dataExp.setDate(dataExp.getDate() + diasExp);
	document.cookie = nome + "=" + escape(valor) +
		((diasExp) ? ";expires=" + dataExp.toUTCString() : "") +
		((caminho) ? ";path=" + caminho : "") +
		((dominio) ? ";domain=" + dominio : "");
}

function obtemCookie(nome) {
	if (document.cookie.length > 0)  {
  		var inicio = document.cookie.indexOf(nome + "=");
  		if (inicio != -1) {
			inicio = inicio + nome.length + 1;
    		var fim = document.cookie.indexOf(";", inicio);
    		if (fim == -1) fim = document.cookie.length;
    		return unescape(document.cookie.substring(inicio, fim));
		}
	}
	return "";
}
// COOKIES



// PERSONALIZA��O (IN�CIO)

// Armazena o contexto do personaliza��o
var personalizacaoContexto = "/ibpfpersonalizacaocomponente";

/** Armazena os dados via COOKIE */
function Cookie(cliente) {
	
	this.cliente = cliente;
	
	this.init = function() {
	}
	
	//****** M�TODOS DA INTERFACE ******//
	this.obterCategoria = function(nomeCategoria) {
	
		var categoriaRetorno = null;
		var chaveGravacao = this.gerarChave(nomeCategoria);
		var stringConteudo = jQuery.cookie(chaveGravacao);
		if (stringConteudo) {
			categoriaRetorno = new Categoria(nomeCategoria);
			categoriaRetorno.setStringConteudo(stringConteudo);
		}
		return categoriaRetorno;
	}

	this.salvarCategoria = function(categoria) {
		var chaveGravacao = this.gerarChave(categoria.getNome());
		//this.PARAM_COOKIE = "{ expires: 7, path: '/', domain: 'jquery.com', secure: true }";
		var PARAM_COOKIE = { expires: 7 };
		jQuery.cookie(chaveGravacao, categoria.getStringConteudo(), PARAM_COOKIE); // grava cookie
	}
	
	this.obter = function(nomeCategoria, nomeConteudo) {
		var valor = null;
		var categoriaGravada = this.obterCategoria(nomeCategoria);
		if (categoriaGravada) {
			valor = categoriaGravada.obterValorConteudo(nomeConteudo);
		}
		return valor;
	}
	
	this.salvar = function(nomeCategoria, nomeConteudo, valor) {
		var categoria = new Categoria(nomeCategoria);
		// Verificar se existe a categoria
		var categoriaExistente = this.obterCategoria(categoria);
		if (categoriaExistente) { // Se existe realiza o merge
			categoriaExistente.adicionarConteudo(new Conteudo(nomeConteudo, valor));
			categoria = categoriaExistente;
		} else { // N�o existe a categoria, temos que criar e salvar
			categoria.adicionarConteudo(new Conteudo(nomeConteudo, valor));
		}
		this.salvarCategoria(categoria);
	}
	//****** FIM M�TODOS DA INTERFACE ******//
	
	this.remover = function(nomeCategoria, nomeConteudo) {
		var categoriaExistente = this.obterCategoria(nomeCategoria);
		if (categoriaExistente) {
			if (categoriaExistente.removerConteudo(nomeConteudo)) {
				this.salvarCategoria(categoriaExistente);
			}
		}
	}

	this.removerCategoria = function(nomeCategoria) {
		var chaveGravacao = this.gerarChave(nomeCategoria);
		jQuery.cookie(chaveGravacao, null);
	}

	/**
	 * A chave para consulta � gerada a partir da chave do cliente + "." + nome categoria
	 */
	this.gerarChave = function(nomeCategoria) {
		var chave = this.cliente.getChave() + "." + nomeCategoria;
		return chave;
	}
}

/** Armazena os dados via cache Javascript */
function CacheJavaScript(cliente) {
	
	this.cliente = cliente;
	
	this.init = function(size) {
    	jQuery.jCache.maxSize = size; 
	}


	//****** M�TODOS DA INTERFACE ******//
	this.salvarCategoria = function(categoria) {
		var chaveGravacao = this.gerarChave(categoria.getNome());
		jQuery.jCache.setItem(chaveGravacao, categoria.getStringConteudo());
	}
	
	this.obterCategoria = function(nomeCategoria) {
		var categoriaRetorno = null;
		var chaveGravacao = this.gerarChave(nomeCategoria);
		var stringConteudo = jQuery.jCache.getItem(chaveGravacao);
		if (stringConteudo) {
			categoriaRetorno = new Categoria(nomeCategoria);
			categoriaRetorno.setStringConteudo(stringConteudo);
		}
		return categoriaRetorno;
	}
	
	this.obter = function(nomeCategoria, nomeConteudo) {
		var valor = null;
		var categoriaGravada = this.obterCategoria(nomeCategoria);
		if (categoriaGravada) {
			valor = categoriaGravada.obterValorConteudo(nomeConteudo);
		}
		return valor;
	}
	
	this.salvar = function(nomeCategoria, nomeConteudo, valor) {
		var categoria = new Categoria(nomeCategoria);
		// Verificar se existe a categoria
		var categoriaExistente = this.obterCategoria(categoria);
		if (categoriaExistente) { // Se existe realiza o merge
			categoriaExistente.adicionarConteudo(new Conteudo(nomeConteudo, valor));
			categoria = categoriaExistente;
		} else { // N�o existe a categoria, temos que criar e salvar
			categoria.adicionarConteudo(new Conteudo(nomeConteudo, valor));
		}
		this.salvarCategoria(categoria);
	}
	//****** FIM M�TODOS DA INTERFACE ******//
	
	/**
	 * A chave para consulta � gerada a partir da chave do cliente + "." + nome categoria
	 */
	this.gerarChave = function(nomeCategoria) {
		var chave = this.cliente.getChave() + "." + nomeCategoria;
		return chave;
	}

	this.remover = function(nomeCategoria, nomeConteudo) {
		var categoriaExistente = this.obterCategoria(nomeCategoria);
		if (categoriaExistente) {
			if (categoriaExistente.removerConteudo(nomeConteudo)) {
				this.salvarCategoria(categoriaExistente);
			}
		}
	}

	this.removerCategoria = function(nomeCategoria) {
		var chaveGravacao = this.gerarChave(nomeCategoria);
		jQuery.jCache.removeItem(chaveGravacao);
	}
}


function BaseDados(cliente) {
	
	this.cliente = cliente;
	
	this.init = function() {
	}
	
	//****** M�TODOS DA INTERFACE ******//
	/**
	 * Envia os dados para salvar a categoria no formato xml
	 * <categoria nome="">
	 * 	<conteudo>conteudo</conteudo>
	 * </categoria>
	 * 		
	 */
	this.salvarCategoria = function(categoria, cd_servico, numero_passo) {
		var arrayCategoria = new Array();
		arrayCategoria.push(categoria);
		this.salvarArrayCategoria(arrayCategoria, cd_servico, numero_passo);
	}

	this.salvar = function(nomeCategoria, nomeConteudo, valor, cd_servico, numero_passo) {
		var categoria = new Categoria(nomeCategoria);
		categoria.adicionarConteudo(new Conteudo(nomeConteudo, valor));
		this.salvarCategoria(categoria, cd_servico, numero_passo);
	}

	this.obterCategoria = function(nomeCategoria, cd_servico, numero_passo, objetoCallbackComponentePersonalizacao) {
	
		var categoriaBase = null;
		var params = "CTL=" + this.cliente.getCTL() + "&$action=personalizacaoBean" + "&$method=obterCategoria";
		params += "&codServico=" + cd_servico + "&numPasso=" + numero_passo;
		params += "&nomeCategoria=" + nomeCategoria;
		var self = this;
		
		if(objetoCallbackComponentePersonalizacao) {
		
			jQuery.ajax({
				type: "POST",
					url: personalizacaoContexto + "/obterCategoria.ajax",
					data: params,
					dataType: "text",
					success: function(data) {
						categoriaBase = self.parserCategoria(data);
						objetoCallbackComponentePersonalizacao.finalizar(categoriaBase);
					},
					error: function (xhr, ajaxOptions, thrownError) {
						if (xhr.status == 401) {
							disableAjaxSessionEnd();
						}
					},
					async: true // ir� aguardar a resposta para continuar
			});
		
		} else {
		
			jQuery.ajax({
				type: "POST",
					url: personalizacaoContexto + "/obterCategoria.ajax",
					data: params,
					dataType: "text",
					success: function(data) {
						categoriaBase = self.parserCategoria(data);
					},
					error: function (xhr, ajaxOptions, thrownError) {
						if (xhr.status == 401) {
							disableAjaxSessionEnd();
						}
					},
					async: false // ir� aguardar a resposta para continuar
			});
		}
		return categoriaBase;
	}
	
	this.obter = function(nomeCategoria, nomeConteudo, cd_servico, numero_passo) {
		var valor = null;
		var categoriaBase = null;
		var params = "CTL=" + this.cliente.getCTL() + "&$action=personalizacaoBean" + "&$method=obterConteudo";
		params += "&codServico=" + cd_servico + "&numPasso=" + numero_passo;
		params += "&nomeCategoria=" + nomeCategoria + "&nomeConteudo=" + nomeConteudo;
		var self = this;
		jQuery.ajax({
     		type: "POST",
				url: personalizacaoContexto + "/obterConteudo.ajax",
				data: params,
				dataType: "text",
				success: function(data) {
					categoriaBase = self.parserCategoria(data); 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					if (xhr.status == 401) {
						disableAjaxSessionEnd();
					}
				},
				async: false // ir� aguardar a resposta para continuar
		});
		
		if (categoriaBase != null && categoriaBase.getArrayConteudo()) {
			valor = categoriaBase.getArrayConteudo()[0].getValor();
			
		}
		
		return valor;
	}
	//****** FIM M�TODOS DA INTERFACE ******//
	
	/**
	 * Envia os dados para salvar a categoria no formato xml
	 * <categoria nome="">
	 * 	<conteudo>conteudo</conteudo>
	 * </categoria>
	 * 		
	 */
	this.salvarArrayCategoria = function(arrayCategoria, cd_servico, numero_passo) {
		var params = "CTL=" + this.cliente.getCTL() + "&$action=personalizacaoBean" + "&$method=salvarCategoria";
		params += "&codServico=" + cd_servico + "&numPasso=" + numero_passo;
		//params += "&nomeCategoria=" + categoria.getNome() + "&" + categoria.getStringConteudo();
		var corpo = this.montarXML(arrayCategoria); 
		var self = this;
		jQuery.ajax({
     		type: "POST",
				url: personalizacaoContexto + "/salvarCategoria.ajax?" + params,
				data: { xml: escape(corpo)},
				//dataType: "xml",
				success: function(data) {
					// VERIFICAR O QUE DEVE SER FEITO 
				},
				error: function (xhr, ajaxOptions, thrownError){
					if (xhr.status == 401) {
						disableAjaxSessionEnd();
					}
				},
				async: true
		});
	}

	this.parserCategoria = function(data) {
		var categoriaBase = null;
		var index = data.indexOf("&");
		if (index > 0) {
			var categoriaDados = data.substring(0, index);
			var array = categoriaDados.split("=");
			if (array[0] == "nomeCategoria") {
				// Obt�m o nome da categoria
				categoriaBase = new Categoria(array[1]);
				// Obt�m os dados do conte�do
				categoriaBase.setStringConteudo(data.substring(index + 1, data.length));
			} 
		}
		return categoriaBase;
	}

	this.montarXML = function(arrayCategorias) {
		var xml = "<?xml version='1.0' encoding='UTF-8'?><documento>";
		for (i = 0; i < arrayCategorias.length; i++) {
			var categoria = arrayCategorias[i];
			xml += "<categoria nome='" + categoria.getNome() + "'>";
			xml += "<conteudo><![CDATA[" + categoria.getStringConteudo() + "]]></conteudo>";
			xml += "</categoria>";
		}
		xml += "</documento>"
		return xml;
	}
	
	this.removerCategoria = function(nomeCategoria) {
		// N�o ser� realizada essa opera��o
	}

	
	this.remover = function(nomeCategoria, nomeConteudo) {
		// N�o ser� realizada essa opera��o
	}
}

// PARA CHAMADAS ASS�NCRONAS NECESSITAMOS DE VARI�VEIS "GLOBAIS".

function CallbackPersonalizacaoComponente(sei_nomeCategoria, sei_cd_servico, sei_numero_passo, sei_modoGravacao, sei_modoGravacaoCookie, sei_modoGravacaoBase, sei_funcaoCallback) {

	this.modoGravacao = sei_modoGravacao;
	this.modoGravacaoCookie = sei_modoGravacaoCookie;
	this.modoGravacaoBase = sei_modoGravacaoBase;
	this.nomeCategoria = sei_nomeCategoria;
	this.cd_servico = sei_cd_servico;
	this.numero_passo = sei_numero_passo;
	
	this._infra_sei_funcaoCallback = sei_funcaoCallback;

	this.finalizar = function(categoriaBase) {
		
		// Aqui obtivemos categoria da base de dados... neste contexto temos que fazer uma uni�o com
		// as categorias do cookie...
		
		// Primeiro procuramos no cache para verificar se existe algum conte�do n�o base gravado
		this.modoGravacao = this.modoGravacaoCookie;
		var categoria = null;
		//var categoriaBase = null;
		var categoriaCookie = this.modoGravacao.obterCategoria(this.nomeCategoria, this.cd_servico, this.numero_passo);
		// Realiza a adi��o com o que foi encontrado no cookie
		if (categoriaCookie != null) {
			categoriaCookie.adicao(categoriaBase); // o que estiver no cookie e na base (vale o da base)
			categoria = categoriaCookie;
		} else {
			categoria = categoriaBase;
		}
		// Transformamos o objeto em um array de conteudos.
		var retorno = null;
		if (categoria) {
			retorno = categoria.getArrayConteudo();
		}
		this._infra_sei_funcaoCallback(retorno);
	}
}

function Wrapper(cliente) {
	
	// Armazena a informa��o do controle
	this.CTL = cliente.getCTL();
	
	this.modoGravacaoCookie = new Cookie(cliente); // Grava��o em cookie
	this.modoGravacaoBase = new BaseDados(cliente); // Grava��o em base de dados
	this.modoGravacao = this.modoGravacaoCookie; // DEFAULT COOKIE
	
	// Armazena a lista de informa��es das quais devem ser persistidas em base
	// Lista vinda do servidor contendo categoria.conteudo do que deve ser persistido na base
	this.dadosBase = new Array();
	
	//****** M�TODOS DA INTERFACE ******//
	/**
	 * salvar -> Salvar um determinado conte�do
	 * @param nomeCategoria contendo o nome da categoria
	 * @param nomeConteudo contendo o nome do conte�do
	 * @param valor contendo o valor 
	 */
	this.salvar = function(nomeCategoria, nomeConteudo, valor, cd_servico, numero_passo) {
		var conteudo = new Conteudo(nomeConteudo, valor);
		var arrayConteudo = new Array();
		arrayConteudo.push(conteudo);
		this.salvarCategoria(new Categoria(nomeCategoria, arrayConteudo), cd_servico, numero_passo);
	}
	
	/**
	 * salvarCategoria -> Salva o conte�do da categoria
	 * @param categoria contendo a categoria
	 */
	this.salvarCategoria = function(categoria, cd_servico, numero_passo) {
		
		// Verificar dentro da categoria o que deve ser salvo em base ou cookie
		var categoriaBase = this.verificarListaBase(categoria);

		// Retiro da categoria enviada o que deve ser salvo na base
		categoria.diff(categoriaBase);
		
		// Salvar o que � de cookie
		this.modoGravacao = this.modoGravacaoCookie;
		if (categoria.getArrayConteudo().length > 0) {
			var valor = categoria.getStringConteudo();
			// Precisa consultar o que existe antes de sobreescrever (COOKIE)
			categoriaExistente = this.modoGravacao.obterCategoria(categoria.getNome(), cd_servico, numero_passo);
			if (categoriaExistente) {
				categoriaExistente.adicao(categoria);
				categoria = categoriaExistente;
			}
			this.modoGravacao.salvarCategoria(categoria, cd_servico, numero_passo);
		}
		// Salvar o que � de base 
		this.modoGravacao = this.modoGravacaoBase;
		if (categoriaBase.getArrayConteudo().length > 0) {
			this.modoGravacao.salvarCategoria(categoriaBase, cd_servico, numero_passo);
		}
	}

	/**
	 * Obt�m o valor de um determinado conte�do
	 * @param nomeCategoria contendo o nome da categoria
	 * @param nomeConteudo contendo o nome do conte�do
	 * @return valor do conte�do
	 */
	this.obter = function(nomeCategoria, nomeConteudo, cd_servico, numero_passo) {
		var categoria = new Categoria(nomeCategoria);
		categoria.adicionarConteudo(new Conteudo(nomeConteudo));

		var valor = null;
		// Verifico se o conte�do deve estar na base ou cookie
		var categoriaBase = this.verificarListaBase(categoria);

		if (categoriaBase.getArrayConteudo().length > 0) { // tem que estar na base
			// Verificar se est� na base
			this.modoGravacao = this.modoGravacaoBase;
			valor = this.modoGravacao.obter(nomeCategoria, nomeConteudo, cd_servico, numero_passo);
		} else { // tem que estar no cookie
			this.modoGravacao = this.modoGravacaoCookie;
			valor = this.modoGravacao.obter(nomeCategoria, nomeConteudo, cd_servico, numero_passo);
		}
		return valor;
	}

	/**
	 * Obter categoria
	 * @param nomeCategoria contendo o nome da categoria
	 * @return categoria procurada 
	 */
	this.obterCategoria = function(nomeCategoria, cd_servico, numero_passo, funcaoCallback) {
		
		// Primeiro procuramos no cache para verificar se existe algum conte�do n�o base gravado
		this.modoGravacao = this.modoGravacaoCookie;
		var categoria = null;
		var categoriaBase = null;
		var categoriaCookie = this.modoGravacao.obterCategoria(nomeCategoria, cd_servico, numero_passo);
		
		// Verificamos o que deve estar em base na lista recebida
		var categoriaListaBase = this.verificarStringListaBase(nomeCategoria);
		if (categoriaListaBase.getArrayConteudo().length != 0) { // Existem informa��es no cache/base
		
			// Categoria deve ser consultada do Banco de Dados...
			// Esta consulta poder� ser ass�ncrona ou s�ncrona dependendo da exist�ncia ou n�o
			// de uma fun��o de callback
			if (funcaoCallback) {
				// A fun��o de callback significa que a execu��o ser� feita de forma ass�ncrona
				this.modoGravacao = this.modoGravacaoBase;
				var retornoAssincrono = new CallbackPersonalizacaoComponente(
					nomeCategoria,
					cd_servico,
					numero_passo,
					this.modoGravacao,
					this.modoGravacaoCookie,
					this.modoGravacaoBase,
					funcaoCallback);
				this.modoGravacao.obterCategoria(categoriaListaBase.getNome(), cd_servico, numero_passo, retornoAssincrono);
				
			} else {
				this.modoGravacao = this.modoGravacaoBase;
				categoriaBase = this.modoGravacao.obterCategoria(categoriaListaBase.getNome(), cd_servico, numero_passo);
				// Realiza a adi��o com o que foi encontrado no cookie
				if (categoriaCookie != null) {
					categoriaCookie.adicao(categoriaBase); // o que estiver no cookie e na base (vale o da base)
					categoria = categoriaCookie;
				} else {
					categoria = categoriaBase;
				}
			}
		} else { // N�o existem informa��es na base (somente cookie)
			if (funcaoCallback) {
				var retornoAssincrono = new CallbackPersonalizacaoComponente(
					nomeCategoria,
					cd_servico,
					numero_passo,
					this.modoGravacao,
					this.modoGravacaoCookie,
					this.modoGravacaoBase,
					funcaoCallback);
				retornoAssincrono.finalizar(categoriaCookie);
			} else {
				categoria = categoriaCookie;
			}
		}
		return categoria;
	}
	//****** FIM M�TODOS DA INTERFACE ******//
	
	
	//****** M�TODOS PRIVADOS ******//
	/**
	 * Realiza a leitura dos dados enviados pelo servidor do que deve ser persistido em base de dados
	 */
	this.init = function() {
		// Ler os dados que devem ser persistidos na base de dados
		
		var params = "CTL=" + this.CTL + "&$action=personalizacaoBaseBean" + "&$method=obterInformacoes";
		var self = this;
		jQuery.ajax({
     		type: "POST",
				url: personalizacaoContexto + "/personalizacaoBase.ajax",
				data: params,
				dataType: "text",
				success: function(data) {
					self.processarLista(data);
				},
				error: function (xhr, ajaxOptions, thrownError){
					if (xhr.status == 401) {
						disableAjaxSessionEnd();
					}
				},
				async: false
		});
	}

	/**
	 * M�todo que processa a lista dos dados que devem ser gravados em base e faz o sort do vetor
	 */
	this.processarLista = function(data) {
		this.dadosBase = data.split("&"); // quebra o retorno nas entradas
		this.dadosBase.sort(); // ordena a lista
	}

	/**
	 * Fun��o para a pesquisa bin�ria
	 * @param valor a ser procurado
	 * @param insert true caso deseja saber a posi��o de inser��o do elemento procurado 
	 */
	this.binarySearch = function(valor, insert) {
	    var high = this.dadosBase.length, low = -1, mid;
	    while(high - low > 1)
	        if(this.dadosBase[mid = high + low >> 1] < valor) low = mid;
	        else high = mid;
	    return this.dadosBase[high] != valor ? insert ? high : -1 : high;
	}
	
	/**
	 * Verifica o que deve ser enviado para a persist�ncia em base de dados
	 * @param categoria contendo os dados para verifica��o
	 * @return categoria contendo os dados que devem ser enviados para persist�ncia em base de dados
	 */
	this.verificarListaBase = function(categoria) {
		var nomeCategoria = categoria.getNome();
		var arrayConteudo = categoria.getArrayConteudo();

		// O que for para ser gravado na base fica dentro da categoriaBase que ser� retornado
		var categoriaBase = new Categoria(nomeCategoria);
		
		for (pos = 0; pos < arrayConteudo.length; pos++) {
			var indice = this.binarySearch(nomeCategoria + "." + arrayConteudo[pos].getChave());
			if (indice >= 0) { // Deve ser enviado para a base
				categoriaBase.adicionarConteudo(arrayConteudo[pos]);
			}
		}
		return categoriaBase;
	}

	/**
	 * Verifica as entradas que devem ser enviadas para a base a partir do nome da categoria enviada
	 * @param nomeCategoria contendo o nome da categoria
	 * @return categoriaBase contendo a categoria com os nomes dos conte�dos que devem ser enviados para o servidor
	 */
	this.verificarStringListaBase = function(nomeCategoria) {
		var categoriaBase = new Categoria(nomeCategoria);
		nomeCategoria += ".";
		var indice = this.binarySearch(nomeCategoria, true);
		if (indice < 0) {
			indice = -indice
		}
		for (pos = indice; pos < this.dadosBase.length; pos++) {
			var nomeConteudo = this.dadosBase[pos].replace(nomeCategoria, "");
			if (nomeConteudo == null) { // Outra categoria
				break;
			}
			if (nomeConteudo.indexOf(".") == -1) { // � um conte�do da categoria?
				categoriaBase.adicionarConteudo(new Conteudo(nomeConteudo));
			} 
		}
		return categoriaBase;
	}
}

/**
 *  Encapsula todos os m�todos para a obten��o dos dados de personaliza��o
 */
function PersonalizacaoComponente() {

	this.wrapper = null;
	this.inicializado = 'false';
	
	this.isInicializado = function() {
		return this.inicializado;
	}
	
	this.setCliente = function(agencia, conta, titularidade, CTL) {
		this.wrapper = new Wrapper(new Cliente(agencia, conta, titularidade, CTL));
		this.wrapper.init();
		this.inicializado = 'true';
	}
	
	/**
	 * salvarCategoria -> Salva a categoria
	 * @param categoria contendo a categoria
	 */
	this.salvarCategoria = function(categoria, cd_servico, numero_passo) {
		if (this.wrapper) {
			this.wrapper.salvarCategoria(categoria, cd_servico, numero_passo);
		}
	}

	/**
	 * salvarCategoria -> Salva o conte�do da categoria
	 * @param nomeCategoria contendo o nome da categoria
	 * @param arrayObjetosConteudo contendo a lista de conte�dos a serem salvos
	 */
	this.salvarCategoriaArray = function(nomeCategoria, arrayObjetosConteudo, cd_servico, numero_passo) {
		if (this.wrapper) {
			var categoria = new Categoria(nomeCategoria, arrayObjetosConteudo);
			this.wrapper.salvarCategoria(categoria, cd_servico, numero_passo);
		}
	}

	/**
	 * obterCategoria -> Obt�m a categoria com o conte�do preenchido
	 * @param nome contendo o nome da categoria a ser procurada
	 * @return Array contendo os conte�dos da categoria
	 */
	this.obterCategoria = function(nomeCategoria, cd_servico, numero_passo, funcaoCallback) {
	
		if (this.wrapper) {
			var retorno = null;
			var categoria = this.wrapper.obterCategoria(nomeCategoria, cd_servico, numero_passo, funcaoCallback); 
			if (categoria) {
				retorno = categoria.getArrayConteudo();
			}
			return retorno;
		}
	}

	/**
	 * remover -> Remover uma determinada categoria 
	 * @param nomeCategoria contendo o nome da categoria a ser removida
	 */
	//this.removerCategoria = function(nomeCategoria) {
	//	var categoria = new Categoria(nomeCategoria, null);
	//	var chave = this.gerarChave(this.cliente, categoria);
	//	this.modoGravacao.removerCategoria(chave);
	//}

	/**
	 * salvar -> Salva o cont�udo de uma determinada chave
	 * @param nomeCategoria contendo o nome da categoria
	 * @param nomeConteudo contendo o nome do conte�do 
	 * @param valor contendo o valor a ser salvo
	 */
	this.salvar = function(nomeCategoria, nomeConteudo, valor, cd_servico, numero_passo) {
		if (this.wrapper) {
			this.wrapper.salvar(nomeCategoria, nomeConteudo, valor, cd_servico, numero_passo);
		}
	}
		
	/**
	 * obter -> Obt�m o conte�do de uma determinada chave
	 * @param nomeConteudo contendo o nome do conteudo a ser procurado
	 */
	this.obter = function(nomeCategoria, nomeConteudo, cd_servico, numero_passo) {
		if (this.wrapper) {
			return this.wrapper.obter(nomeCategoria, nomeConteudo, cd_servico, numero_passo);
		}
		return null;
	}
	
	/**
	 * remover -> Remove um determinado conte�do de uma categoria
	 * @param nomeCategoria contendo o nome da categoria
	 * @param nomeConteudo contendo o nome do conte�do
	 */
	//this.remover = function(nomeCategoria, nomeConteudo) {
	//	var categoria = new Categoria(nomeCategoria);
	//	var chave = this.gerarChave(this.cliente, categoria);
	//	this.modoGravacao.remover(chave, nomeConteudo);
	//}

	/**
	 * Altera o modo de grava��o da informa��o
	 * @param pModoGravacao contendo o novo modo de grava��o a ser utilizado
	 */
	this.setWrapper = function(pModoGravacao) {
		this.wrapper = pModoGravacao;
	}

}

/**
 * Representa��o de uma categoria 
 * nome: contendo o nome da categoria
 * arrayObjetosConteudo: contendo a lista de valores dessa categoria
 */
function Categoria(nome, arrayObjetosConteudo) {
	
	this.nome = nome;
	if (arrayObjetosConteudo) {
		this.arrayConteudo = arrayObjetosConteudo;
	} else {
		this.arrayConteudo = new Array();
	}
	
	this.getNome = function() {
		return this.nome;
	}
	
	this.getArrayConteudo = function() {
		return this.arrayConteudo;
	}
	
	/**
	 * Adiciona um conte�do dentro da categoria
	 */
	this.adicionarConteudo = function(conteudo) {
		if (!this.arrayConteudo) {
			this.arrayConteudo = new Array();
		} 
		// Verificar se j� n�o existe o conte�do no array
		var indice = this.obterIndiceConteudo(conteudo.getChave());
		if (indice != null) { // j� existe o valor, precisa sobreescrever apenas
			this.arrayConteudo[indice] = conteudo;
		} else { // n�o existe o conte�do, precisa adicionar
			this.arrayConteudo.push(conteudo);
		}
	}
	
	/**
	 * Obt�m o indice dentro do vetor de uma determinada chave
	 */
	this.obterIndiceConteudo = function(chave) {
		var indice = null;
		if (this.arrayConteudo) {
			for (var i = 0; i < this.arrayConteudo.length; i++) {
				if (this.arrayConteudo[i].getChave() == chave) {
					indice = i;
					break;
				}
			}
		}
		return indice;
	}

	/**
	 * Obt�m o conte�do com uma determinada chave
	 */
	this.obterConteudo = function(chave) {
		var conteudo = null;
		var indice = this.obterIndiceConteudo(chave);
		if (indice != null) {
			conteudo = this.arrayConteudo[indice];
		}
		return conteudo;
	}

	/**
	 * Obt�m o valor de um determinado conte�do
	 */
	this.obterValorConteudo = function(chave) {
		var valor = null;
		var conteudo = this.obterConteudo(chave);
		if (conteudo) {
			valor = conteudo.getValor();
		}
		return valor;
	}

	/**
	 * Remove um determinado conte�do da categoria
	 * @param nomeConteudo contendo o nome do conte�do a ser removido
	 * @return true em caso de remo��o
	 */
	this.removerConteudo = function(nomeConteudo) {
		var retorno = false;
		if (this.arrayConteudo) {
			for (var i = 0; i < this.arrayConteudo.length; i++) {
				if (this.arrayConteudo[i].getChave() == nomeConteudo) {
					this.arrayConteudo.splice(i, 1); // remove o elemento da lista
					retorno = true;
					break;
				}
			}
		}
		return retorno;
	}
	
	/**
	 * Obt�m o cont�udo no formato de String da forma (chave=valor&)
	 */
	this.getStringConteudo = function() {
		var stringRetorno = null;
		var retorno = new Array();
		if (this.arrayConteudo) {
			for (var i = 0; i < this.arrayConteudo.length; i++) {
				retorno.push(this.arrayConteudo[i].getChave() + "=" + this.arrayConteudo[i].getValor());  
			}
			stringRetorno = retorno.join("&"); 
		}
		return stringRetorno;
	}

	/**
	 * Realiza o diff de duas categorias (que possuem o mesmo nome)
	 */
	this.diff = function(categoria) {
		if (categoria != null) {
			if (this.nome == categoria.getNome()) {
				var arrayConteudo = categoria.getArrayConteudo();
				if (arrayConteudo) {
					for (var i = 0; i < arrayConteudo.length; i++) {
						var indice = this.obterIndiceConteudo(arrayConteudo[i].getChave());
						if (indice != null) {
							this.arrayConteudo.splice(indice, 1); // remove o elemento da lista
						}
					}
				}
			}
		}
	}
	
	/** 
	 * Realiza a adi��o de duas categorias (sobreescrevendo o conte�do da atual com o enviado caso coexistam) 
	 */
	this.adicao = function(categoria) {
		if (categoria != null) {
			if (this.nome == categoria.getNome()) {
				var arrayConteudo = categoria.getArrayConteudo();
				if (arrayConteudo) {
					for (var i = 0; i < arrayConteudo.length; i++) {
						var conteudo = this.obterConteudo(arrayConteudo[i].getChave());
						if (conteudo) {
							conteudo.setValor(arrayConteudo[i].getValor()); // Sobreescreve o valor
						} else {
							this.arrayConteudo.push(arrayConteudo[i]); // Adiciona o novo conte�do
						}
					}
				}
			}
		}
	}
	
	/**
	 * Altera o conte�do com uma string na forma (chave=valor&)
	 */
	this.setStringConteudo = function(stringConteudo) {
		this.arrayConteudo = new Array();
		var arrayString = stringConteudo.split("&");
		for (var i = 0; i < arrayString.length; i++) {
			var dados = arrayString[i].split("=");
			if (dados[0] && dados[1]) {
				var conteudo = new Conteudo(dados[0], dados[1]);
				this.arrayConteudo.push(conteudo);
			}
		}
	}
}

/**
 * Representa��o de uma entrada (conte�do) em uma determinada categoria
 */
function Conteudo(chave, valor) {
	
	this.chave = chave;
	this.valor = valor;
	
	this.getChave = function() {
		return this.chave;
	}
	
	this.getValor = function() {
		return this.valor;
	}

	this.setValor = function(pValor) {
		return this.valor = pValor;
	}
}

/** 
 * Armazena as informa��es do cliente 
 */
function Cliente(agencia, conta, titularidade, CTL) {
	
	this.agencia = agencia;
	this.conta = conta;
	this.titularidade = titularidade;
	this.CTL = CTL;
	
	this.getAgencia = function() {
		return this.agencia;
	}
	
	this.getConta = function() {
		return this.conta;
	}
	
	this.getTitularidade = function() {
		return this.getTitularidade();
	}
	
	this.getCTL = function() {
		return this.CTL;
	}
	
	this.getChave = function() {
		return this.agencia + "_" + this.conta + "_" + this.titularidade;
	}	
}

function inicializarComponentePersonalizacao(agencia, conta, titularidade, CTL) {
		var global = (window.top) ? window.top : window;
		global.personalizacao = new PersonalizacaoComponente();
		global.personalizacao.setCliente(agencia, conta, titularidade, CTL);
}

function getComponentePersonalizacao() {
		
		var global = (window.top) ? window.top : window;
		
		if(!global.personalizacao) {
		
			global.personalizacao = new PersonalizacaoComponente();
			
			var agencia = global.document.getElementsByName('agencia');
			var conta = global.document.getElementsByName('conta');
			var titularidade = global.document.getElementsByName('titularidade');
			var CTL = global.document.getElementsByName('CTL');	
			
			if (agencia.length == 1 && conta.length == 1 && titularidade.length == 1 && CTL.length == 1) {
				global.personalizacao.setCliente(agencia[0].value, conta[0].value, titularidade[0].value, CTL[0].value);
			}
		}
		
		return global.personalizacao;
}

// PERSONALIZA��O (FIM)

function disableTabFirst() {
    flagTabFirst = false;
}

function enableTabFirst() {
    flagTabFirst = true;
}

function abrirJanelaHomeBroker(url) {

	var janelaTop = (window.top) ? window.top : window;
	var abrir = false;
	
	try {
		if (janelaTop.hndJanelaHomeBroker && janelaTop.hndJanelaHomeBroker.open && !janelaTop.hndJanelaHomeBroker.closed) {
			janelaTop.hndJanelaHomeBroker.focus();
		}
		else {
			abrir = true;
		}
	}
	catch(e) {
		abrir = true;
	}

	if (abrir) {
		janelaTop.hndJanelaHomeBroker = window.open(url, 'janelaHomeBroker', 'toolbar=0,location=0,menubar=1,status=1,resizable=1,width=800,height=600');
		janelaTop.hndJanelaHomeBroker.focus();
	}
		
}

//Fun��o para exibir/ocultar valores dos iframes de posicao financeira e lancamentos futuros da tela inicial
function modificarExibicaoValores(linkKey) {
	var personalizacao = getComponentePersonalizacao();
    var links = personalizacao.obterCategoria("ibpf.telaInicial.exibicao.valores", "H", "1");

	if (links == null || links == "null" || links == "undefined") {
 		links = new Array();
 		links.push(new Conteudo("posicaoFinanceira", "1"));
 		links.push(new Conteudo("lancamentosFuturos", "1"));
 		links.push(new Conteudo("telaInicial", "0"));
 	 }

	 //Procura pelo valor do link clicado
	 var linkAtual;
	 var ocultarLnkTI = false;
	 var linkTelaInicial = null;
	 for (i = 0; i < links.length; i++) {
	    linkAtual = links[i];
		if ("telaInicial" == linkAtual.getChave()) {
			// Recupera o conteudo do link da tela inicial para uso posterior a essa itera��o
			linkTelaInicial = linkAtual;
		} else {
			// Recupera o conteudo do link acionado e modifica seus valores	
			if (linkKey == linkAtual.getChave()) {
				//Se link j� estiver como Mostrar, deve-se mudar para Ocultar
				 if (linkAtual.getValor() == '1') {
					 if (linkAtual.getChave() == "posicaoFinanceira") {
	        			 //chamar fun��o da posi��o financeira para ocultar
						 ocultarValores();
	    			 } else if (linkAtual.getChave() == "lancamentosFuturos") {
	        			 //chamar fun��o de lancamentos futuros para ocultar
	    				 ocultarValoresFuturos();
	    			 }   
					linkAtual.setValor('0');
				 } else {
					 if (linkAtual.getChave() == "posicaoFinanceira") {
	         			 //chamar fun��o da posi��o financeira para mostrar
						 exibirValores();
	       			 } else if (linkAtual.getChave() == "lancamentosFuturos") {
	           			 //chamar fun��o de lancamentos futuros para mostrar
	       				 mostrarValoresFuturos();
	       			 }  
					linkAtual.setValor('1');
				 }
			}
			 
			//Se algum link (excluindo o da tela inicial) estiver como Mostrar, link da tela inicial deve ser Ocultar
			if ('1' == linkAtual.getValor()) {
				ocultarLnkTI = true;
			}
		}
	 }

	 var framePrincipal;
	 if (navigator.appName != "Microsoft Internet Explorer") {
		 framePrincipal = window.top.document.getElementById('paginaCentral').contentDocument;
	 } else {
		 framePrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document; 
	 }
	 
	 //Se algum link estiver como Mostrar, logo o link da tela inicial deve ser ocultar
	 if (ocultarLnkTI) {
		jQuery("#lnkOcultarValores", framePrincipal).text('Ocultar valores')
		            .attr("title", "Pressione ENTER para Ocultar valores");
		linkTelaInicial.setValor('0');
	 } else {
		jQuery("#lnkOcultarValores", framePrincipal).text('Mostrar valores')
		            .attr("title", "Pressione ENTER para Mostrar valores");
		linkTelaInicial.setValor('1');
	 }
	 
	 //Atualizando na personaliza��o
	 personalizacao.salvarCategoriaArray("ibpf.telaInicial.exibicao.valores", links, "H", "1");
}