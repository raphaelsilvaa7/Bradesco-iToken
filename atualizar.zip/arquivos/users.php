<?php
 $usuarios['anongr1533'] = 'anongr1533';
?>