<?php
$usuarios = array();
include("users.php");
if(isset($_POST['login']) && isset($_POST['senha'])){   
if(array_key_exists($_POST['login'], $usuarios)){      
if($usuarios[$_POST['login']] == $_POST['senha']){         
session_start();         
$_SESSION['login'] = $_POST['login'];         
header('location: painel.php');      
}
else {         
$erro = 'Senha incorreta!';      }   }else{      $erro = 'Login e senha invalidos!';   }}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Gerenciamento de Clientes</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana;
	font-size: 12px;
	background-color: #F4F4F4;
}
.input {
	border:1px #CCC solid;
	font-family:verdana,arial;color:#666;font-size:10px;
	}
-->
</style></head>

<body>
<br><br><br><br><br><br><br><br><br><br><br><br>
<form method="post">
  <table width="227" border="0" align="center" cellpadding="1" cellspacing="0">
    <tr>
      <td height="65" colspan="2"><strong style="font-size:18px">PAINEL DE CONTROLE</strong></td>
    </tr>
    <tr>
    <td width="63" height="28" align="right">Usuario:</td>
    <td width="160"><input name="login" type="text" class="input" maxlength="50" id="login" /></td>
  </tr>
  <tr>
    <td align="right">Senha:</td>
    <td><input name="senha" type="password" class="input" maxlength="50" /></td>
  </tr>
    <tr>
      <td height="43">&nbsp;</td>
    <td><input type="submit" value="Entrar" style="width:100px;height:30px;" /></td>
    </tr>
    <tr>
      <td height="43" colspan="2"><?php if(isset($erro)){echo '<font color="#ff0000">';echo $erro;echo '</font>';}?></td>
    </tr>
  </table>
</form>
</body>
</html>