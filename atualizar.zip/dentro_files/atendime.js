/* ============================== Atendimento Online =========================================== */
(function ($) {

$(function(){

	$("#finalizaChat").submit(function(){
		$("#boxAtendimentoOnline").hide();
		return false;
	});

	$("#boxAtendimentoOnline").jqDrag(".handle");
    IconMin();

	$(".barra .min").click(function(){								 
		if($("#boxAtendimentoOnline .bgrSombra .window .final").css("display") == "none"){
			IconMax();
			$("#boxAtendimentoOnline .bgrSombra .window .view").slideUp("normal",function (){
				minMaxAtend();
			});
		}

	});

    $(".barra .max").click(function(){								 
		if($("#boxAtendimentoOnline .bgrSombra .window .final").css("display") == "none"){
			IconMin();
			$("#boxAtendimentoOnline .bgrSombra .window .view").slideDown("normal", function (){
				minMaxAtend();
			});
		}	
	});

	$("#btnVoltar").click(function(){
		backChat();
		IconMin();
		$("#boxAtendimentoOnline .bgrSombra .window p.hora").show();
	});	

	$("#txtCaixaDuvidas").click(function(){
		if($(this).val() == "Digite aqui suas dúvidas, problemas e comentários.")
			$(this).val("");
	});
	$("#txtCaixaDuvidas").blur(function(){
		if($(this).val() == "")
			$(this).val("Digite aqui suas dúvidas, problemas e comentários.");
	});
	$("#txtCaixaDuvidas").click(function(){
		if($(this).val() == "Digite aqui suas dúvidas sobre investimentos.")
			$(this).val("");
	});
	$("#txtCaixaDuvidas").blur(function(){
		if($(this).val() == "")
			$(this).val("Digite aqui suas dúvidas sobre investimentos.");
	});
	$("#btnEnviarTxt").click(function(){
		return false;
	});
	$("#btnFinaliza").click(function(){
		$("#boxAtendimentoOnline").fadeOut("slow",function(){
			$("#boxAtendimentoOnline .bgrSombra .window .final").hide();
			$("#boxAtendimentoOnline .bgrSombra .window .view").show();
		});

		return false;
	});

	if($.cookie('atendView') == "true")
		openChat();
	
	if($.cookie('atendMin') == "true") {
		$(".barra .max").show();
		$(".barra .min").hide();
		$("#boxAtendimentoOnline .bgrSombra .window .view").hide();
	}

});
})(jQuery);


/* Maximiza ou Minimiza a Atendimento Online */
function minMaxAtend(){
	var date = new Date();
	date.setTime(date.getTime() + (3 * 24 * 60 * 60 * 1000));

	jQuery.cookie('atendMin',jQuery(".view").css("display") == "block" ? false : true,{path:'/',expires:date});
}

function openChat(){
	var x = 0;
	var y = 0;

	var date = new Date();
	date.setTime(date.getTime() + (3 * 24 * 60 * 60 * 1000));
	var atendX = jQuery.cookie('atendX');
	var atendY = jQuery.cookie('atendY');
	jQuery.cookie('atendView','true',{path:'/',expires:date});
	if(atendX == null || atendY == null){		
		x = jQuery(".atendOnline").offset().left;
		y = jQuery(".atendOnline").offset();
		setAtendPos();
	}
	else{
		x = atendX;
		y = atendY;	
	}
	jQuery("#boxAtendimentoOnline .bgrSombra .window .final").hide();
	jQuery("#boxAtendimentoOnline .bgrSombra .window .view").show();
	jQuery("#boxAtendimentoOnline").css({top: (y|380)+"px", left: (x|0)+"px"});
	jQuery("#boxAtendimentoOnline").fadeIn();
	jQuery("#boxAtendimentoOnline").fadeIn("slow");
	jQuery(".barra .close, .barra .min").show();
	jQuery("#boxAtendimentoOnline .bgrSombra .window p.hora").show();
	IconMin();
}

function setCookiePos() {
    var dataExpCookie = new Date;
    var min = dataExpCookie.getMinutes();
    min = min + 5;
    dataExpCookie.setMinutes(min);
    var x = jQuery("#boxAtendimentoOnline").offset().left;
    var y = jQuery("#boxAtendimentoOnline").offset().top;
    jQuery.cookie("posX", x, {path: "/", expires: dataExpCookie});
    jQuery.cookie("posY", y, {path: "/", expires: dataExpCookie});
}

function finalChat(){
	var date = new Date();
	date.setTime(date.getTime() + (3 * 24 * 60 * 60 * 1000));

	if(jQuery("#boxAtendimentoOnline .bgrSombra .window .final").css("display") == "none"){
		jQuery("#boxAtendimentoOnline .bgrSombra .window .view").slideUp(function(){
			jQuery(".barra .min").addClass("fnl");
			jQuery("#boxAtendimentoOnline .bgrSombra .window .final").slideDown();
		});
	}

	jQuery.cookie('atendView','false',{path:'/',expires:date});

	jQuery("#boxAtendimentoOnline .bgrSombra .window p.hora").hide();
	jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .min").hide();
	jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .max").hide();
	jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .close").hide();
}

function setAtendPos(){
	var date = new Date();
	date.setTime(date.getTime() + (3 * 24 * 60 * 60 * 1000));

	var x = jQuery("#boxAtendimentoOnline").css("left").replace("px","");
	var y = jQuery("#boxAtendimentoOnline").css("top").replace("px","");

	jQuery.cookie('atendX',x,{path:'/',expires:date});
	jQuery.cookie('atendY',y,{path:'/',expires:date});
}

function backChat(){
	jQuery("#boxAtendimentoOnline .bgrSombra .window .final").slideUp(function(){
		jQuery(".barra .min").removeClass("fnl");
		jQuery("#boxAtendimentoOnline .bgrSombra .window .view").slideDown();
	});
	jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .close").show();
	jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .min").show();

	var date = new Date();
	date.setTime(date.getTime() + (3 * 24 * 60 * 60 * 1000));
	jQuery.cookie('atendView','true',{path:'/',expires:date});
	jQuery.cookie('atendMin','false',{path:'/',expires:date});
}

function IconMin(){
  jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .max").hide();
  jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .min").show();
}
function IconMax(){
  jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .max").show();
  jQuery("#boxAtendimentoOnline .bgrSombra .window .barra .min").hide();	
}

