(function ($) {

$(function() {

	$("#txtPesquisar").change( function() {
		var texto = $(this).val();
		if (texto.replace(/^\s+|\s+$/g, "").length == 0) {
			$(".btnBuscador").attr("title", "OK");
		}
		else {
			$(".btnBuscador").attr("title", "OK. Pesquisar por: " + texto);
		}
	});

	// Buscador Site Principal
	var ct = top.getParametroUrlGet("CTL");
	var paramCtl = '/ibpfbuscador/buscadorAutoComplete.jsf?CTL='+ ct

	$("#txtPesquisar").autocomplete(paramCtl,{
		matchContains:true,
		selectFirst: false,
		selectOnly: true,
		minChars:3,
		width: 226,
		highlight: function(value, term) {
			return "<a href=\"javascript:;\" title=\"" + value + "\">" + accent_folded_hilite(value, term) + "</a>";
		},
		parse: function(data){
			var parsed = [];
			data=data.replace(new RegExp('\\+','g'),' ');
			var rows = unescape(data).split("\n");

			for (var i=0; i < rows.length; i++) {
				var row = rows[i].replace(/^\s+|\s+$/g, "");

				if(row.indexOf('##FIM##') != -1){
					break;
				}
				if (row) {
					row = row.split("|");
					parsed[parsed.length] = {
							data: row,
							value: row[0],
							result: row[0]
					};
				}
			}
			return parsed;
		}
	});


	var ct = $("#a4jCTL").val();
	var paramCtl = '/ibpfacessorapido/acessorapidoAutoComplete.jsf?CTL='+ ct;

	$("#txtAtalho").autocomplete(paramCtl,{
		matchContains:true,
		selectFirst: true,
		selectOnly: true,
		minChars: 1,
		scroll: false,
		scrollHeight: 250,
		width: 507,
		cacheLength: 0,
		highlight: function(value, term) {
			var temp = value.split("~");
			var output = "<table><tr>";
			if (temp[3] != "") {
				output += "<td class=\"codigo\" height=\"20\" width=\"30\"><a href=\"javascript:;\" class=\"tabindex\" title=\"" + temp[0] + ", " + temp[3] + ": " + temp[1] + ", " + temp[2] + "\">" + accent_folded_hilite(temp[0], term) + "</a></td>";
				output += "<td class=\"titulo\" width=\"350\"><a href=\"javascript:;\" title=\"" + temp[0] + ", " + temp[3] + ": " + temp[1] + ", " + temp[2] + "\"><span class=\"subfamilia\">" + temp[3] + ":</span> " + accent_folded_hilite(temp[1], term) + "</a></td>";
				output += "<td class=\"familia\" width=\"150\"><a href=\"javascript:;\" title=\"" + temp[0] + ", " + temp[3] + ": " + temp[1] + ", " + temp[2] + "\">" + accent_folded_hilite(temp[2], term) + "</a></td>";
			}
			else {
				output += "<td class=\"codigo\" height=\"20\" width=\"30\"><a href=\"javascript:;\" class=\"tabindex\" title=\"" + temp[0] + ", " + temp[1] + ", " + temp[2] + "\">" + accent_folded_hilite(temp[0], term) + "</a></td>";
				output += "<td class=\"titulo\" width=\"350\"><a href=\"javascript:;\" title=\"" + temp[0] + ", " + temp[1] + ", " + temp[2] + "\">" + accent_folded_hilite(temp[1], term) + "</a></td>";
				output += "<td class=\"familia\" width=\"150\"><a href=\"javascript:;\" title=\"" + temp[0] + ", " + temp[1] + ", " + temp[2] + "\">" + accent_folded_hilite(temp[2], term) + "</a></td>";
			}
			output += "</tr></table>";
			return output;
		},
		formatItem: function(row, i, max) {
			// OBSERVACAO:
			// A formatacao dos itens sera tratada pelo highlight, que ira destacar o texto de entrada nos termos retornados.
			// Por isso, a funcao de formatacao foi simplificada para facilitar o tratamento na proxima etapa.
			return row[0] + "~" + row[1] + "~" + row[2] + "~" + row[3];
		},
		formatResult: function(row) {
			return row[1];
		},
		parse: function(data) {
			var parsed = [];
			data=data.replace(new RegExp('\\+','g'),' ');
			var rows = unescape(data).split("\n");

			for (var i=0; i < rows.length; i++) {
				var row = rows[i].replace(/^\s+|\s+$/g, "");

				if(row.indexOf('##FIM##') != -1){
					break;
				}
				if (row) {
					row = row.split("|");
					parsed[parsed.length] = {
							data: row,
							value: row[0],
							result: row[0]
					};
				}
			}
			return parsed;
		}
	}).result(function(a,b,c){
		if (b[4].length > 3){
			parent.document.getElementById("paginaCentral").src = b[4];
			parent.fecharModalInfraEstrutura();
		}
	});
});

})(jQuery);


function getParametroCTL(  )
{
	var name='CTL'
	name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var regexS = "[\\?&]"+name+"=([^&#]*)";
	var regex = new RegExp( regexS );
	var results = regex.exec( window.location.href );
	if( results == null )
		return "";
	else
		return results[1];
}

// Tratamento de caracteres acentuados
// http://github.com/aristus/accent-folding
// Artigo sobre tratamento de acentuacao:
// http://www.alistapart.com/articles/accent-folding-for-auto-complete/

//accent-folding function
var accent_map = {
'A':'A', '�':'A', '�':'A', '�':'A', '�':'A', '�':'A',
'a':'a', '�':'a', '�':'a', '�':'a', '�':'a', '�':'a',
'B':'B', 'b':'b',
'C':'C', '�':'C', 'c':'c', '�':'c',
'D':'D', 'd':'d',
'E':'E', '�':'E', '�':'E', '�':'E', '�':'E',
'e':'e', '�':'e', '�':'e', '�':'e', '�':'e',
'F':'F', 'f':'f',
'G':'G', 'g':'g',
'H':'H', 'h':'h',
'I':'I', '�':'I', '�':'I', '�':'I', '�':'I',
'i':'i', '�':'i', '�':'i', '�':'i', '�':'i',
'J':'J', 'j':'j',
'K':'K', 'k':'k',
'L':'L', 'l':'l',
'M':'M', 'm':'m',
'N':'N', '�':'N', 'n':'n', '�':'n',
'O':'O', '�':'O', '�':'O', '�':'O', '�':'O', '�':'O',
'o':'o', '�':'o', '�':'o', '�':'o', '�':'o', '�':'o',
'P':'P', 'p':'p',
'Q':'Q', 'q':'q',
'R':'R', 'r':'r',
'S':'S', 's':'s',
'T':'T', 't':'t',
'U':'U', '�':'U', '�':'U', '�':'U', '�':'U',
'u':'u', '�':'u', '�':'u', '�':'u', '�':'u',
'V':'V', 'v':'v',
'W':'W', 'w':'w',
'X':'X', 'x':'x',
'Y':'Y', '�':'Y',
'y':'y', '�':'y',
'Z':'Z', 'z':'z',
'0':'0', '1':'1', '2':'2', '3':'3', '4':'4', '5':'5', '6':'6', '7':'7', '8':'8', '9':'9'
};

var accentMap = {
    '�':'a', '�':'e', '�':'i','�':'o','�':'u'
};

function accent_fold (s) {
	if (!s) { return ''; }
    var ret = '';
    for (var i=0; i<s.length; i++) {
		ret += accent_map[s.charAt(i)] || s.charAt(i);
    }
    return ret;
}


// accent_folded_hilite("Fulanilo L�pez", 'lo')
//   --> "Fulani<b>lo</b> <b>L�</b>pez"
//
function accent_folded_hilite(str, q) {
  var str_folded = accent_fold(str).toLowerCase().replace(/[<>]+/g, '');
  var q_folded = accent_fold(q).toLowerCase().replace(/[<>]+/g, '');

  // create an intermediary string with hilite hints
  // example: fulani<lo> <lo>pez
  //var re = new RegExp(q_folded, 'g');
  // Alteracao na expressao para considerar somente os matches no inicio do termo
  var re = new RegExp("^" + q_folded);

  var hilite_hints = str_folded.replace(re, '<'+q_folded+'>');

  // index pointer for the original string
  var spos = 0;
  // accumulator for our final string
  var highlighted = '';

  // walk down the original string and the hilite hint
  // string in parallel. when you encounter a < or > hint,
  // append the opening / closing tag in our final string.
  // if the current char is not a hint, append the corresponding
  // char from the *original* string to our final string and
  // advance the original string's pointer.
  for (var i=0; i<hilite_hints.length; i++) {
    var c = str.charAt(spos);
    var h = hilite_hints.charAt(i);
    if (h === '<') {
       highlighted += '<span style="font-weight:bold;">';
    } else if (h === '>') {
       highlighted += '</span>';
    } else {
      spos += 1;
      highlighted += c;
    }
  }
  return highlighted;
}