// INICIO - CONTROLE DO BROWSER
if (typeof(flagAutoEncerra) == "undefined") {
    flagAutoEncerra = false;
}

function disableAutoEncerra() { 
    flagAutoEncerra = false;
}

function enableAutoEncerra() {
    flagAutoEncerra = true;
}

function onClickSairIB() {
    disableAutoEncerra();
    var urlEncerra = mainTelaInicialUrlEncerra + "?" + mainTelaInicialNomeCtl + "=" + mainTelaInicialCtl
    window.top.location = urlEncerra;
}

jQuery(window).load(function() {
    //verificar se � moldura principal da tela inicial:
    if (typeof(mainTelaInicialUrlEncerra) != "undefined") {
          //ativar controle de fechamento do browser.
          enableAutoEncerra();
          jQuery(window).unload(autoEncerra);
          if(identificarBrowser() != "msie") {
          	jQuery(window).bind("beforeunload", autoEncerra);
          }
    }
});
function fechaImplic(urlEncerra) {
    jQuery.ajax({
        url: urlEncerra,
        timeout: 2000,
        success: function(){},
        error: function(){},
        async: false
    });
}
var autoEncerraProc = false; 
function autoEncerra() {
    if (!autoEncerraProc) {
        autoEncerraProc = true;
	    if (flagAutoEncerra) {
	          var urlEncerra = mainTelaInicialUrlEncerra + "?" + mainTelaInicialNomeCtl + "=" + mainTelaInicialCtl
	          fechaImplic(urlEncerra);//garantir encerramento.
	          window.open(urlEncerra, "fechasessao", "toolbar=1,location=1,directories=1,status=1,menubar=1,scrollbars=1,resizable=1,screenX=0,screenY=0,left=0,top=0,width=1024,height=820");
	    }
    }
}

// FIM - CONTROLE DO BROWSER

// IN�CIO - MENU LATERAL
function ordenarDivs(arrayConteudo) {
	var divAnterior = jQuery("#iframePostit");
	if (arrayConteudo == null || arrayConteudo == "null" || arrayConteudo == "undefined" || arrayConteudo.length == 0) {
		arrayConteudo = new Array();
		arrayConteudo.push(new Conteudo("0", "lateral_meus_saldos"));
		arrayConteudo.push(new Conteudo("1", "lateral_mais_utilizadas"));
		arrayConteudo.push(new Conteudo("2", "lateral_outras_funcoes"));
		arrayConteudo.push(new Conteudo("3", "lateral_apoio_atendimento"));
	}
	for (iConteudo = 0; iConteudo < arrayConteudo.length; iConteudo++) {
		var conteudo = arrayConteudo[iConteudo];
		var divSeguinte = jQuery("#" + conteudo.getValor());
		divSeguinte.insertAfter(divAnterior);
		if (conteudo.getValor() != 'lateral_meus_saldos' && conteudo.getValor() != 'lateral_apoio_atendimento') {
		      divSeguinte.css("display", "");
		}
		divAnterior = divSeguinte;
	}
}

function atualizarVisibilidadeDivs(arrayConteudo) {
	if (arrayConteudo == null || arrayConteudo == "null" || arrayConteudo == "undefined" || arrayConteudo.length == 0) {
		arrayConteudo = new Array();
		arrayConteudo.push(new Conteudo("lateral_mais_utilizadas", "1"));
		arrayConteudo.push(new Conteudo("lateral_outras_funcoes", "1"));
		arrayConteudo.push(new Conteudo("lateral_apoio_atendimento", "1"));
		arrayConteudo.push(new Conteudo("lateral_meus_saldos", "1"));
	}
	for (iConteudo = 0; iConteudo < arrayConteudo.length; iConteudo++) {
		var conteudo = arrayConteudo[iConteudo];
		if (conteudo.getValor() == '1') {
			if (conteudo.getChave() != 'lateral_apoio_atendimento') {
				jQuery("#" + "box_" + conteudo.getChave()).addClass("on");
			} else {
				jQuery("#hdaLateral").addClass("on");
			}
			jQuery("#"+"conteudo_" + conteudo.getChave()).css("display", "block");
		}
	}
}

function atualizarMaisUtilizadas(arrayConteudo) {
	if (arrayConteudo == null || arrayConteudo == "null" || arrayConteudo == "undefined" || arrayConteudo.length == 0) {
		arrayConteudo = new Array();
		arrayConteudo.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|X|G"));
	}
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.personalizacao.obter.lista.conteudo.servico&codServicos="+arrayConteudo[0].getValor(),
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			atualizarMaisUtilizadasSucesso(data.conteudo);
		},
		error: function(req,status) {
		}
	});
}

function atualizarMaisUtilizadasSucesso(conteudoServicos) {
	var conteudoValidado = conteudoServicos.split("|");
	var siglasValidadas = "";
	
	for (i = 0; i < conteudoValidado.length; i++) {
		valores = conteudoValidado[i].split("#");
		jQuery("#maisUtilizadas" + i).css("display", "block");
		jQuery("#tituloLink" + i).html("<span style='color:#666666; font: 11px Tahoma'>" + valores[4] + 
				": </span><br><span style='color:#333333; font:13px Tahoma'>" + valores[1] + "</span>");
		if (valores[2] != "javascript:;") {
			jQuery("#linkMaisUtilizadas" + i).attr("href", valores[2]);
		} else {
			jQuery("#linkMaisUtilizadas" + i).attr("href", valores[2]);
		}
		jQuery("#linkMaisUtilizadas" + i).attr("title", valores[4] + ": " + valores[1]);
		
		if (siglasValidadas == "") {
			siglasValidadas = valores[5];
		} else {
			siglasValidadas = siglasValidadas + "|" + valores[5];
		}
	}
}

function exibirMiniPosFinan() {
	if (flagAtivarMiniPosicaoFinanceira == 1) {
		jQuery("#lateral_meus_saldos").css("display", "block");
	}
}

function ocultarMiniPosFinan() {
	jQuery("#lateral_meus_saldos").css("display", "none");
}

function carregarMenuLateral(tempoPosFinan) {
	(function ($) {
		$(document).ready(function(){
			var arrayConteudoMaisUtilizadas = personalizacao.obterCategoria("ibpf.telaInicial.maisUtilizadas.opcoes", "NAB", "1");
			if (arrayConteudoMaisUtilizadas == null || arrayConteudoMaisUtilizadas == "null" || arrayConteudoMaisUtilizadas == "undefined" || arrayConteudoMaisUtilizadas.length == 0) {
				arrayConteudoMaisUtilizadas = new Array();
				arrayConteudoMaisUtilizadas.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|X|G"));
				personalizacao.salvarCategoriaArray("ibpf.telaInicial.maisUtilizadas.opcoes", arrayConteudoMaisUtilizadas, "NAB", "1");
				atualizarMaisUtilizadas(arrayConteudoMaisUtilizadas);
			} else {
				atualizarMaisUtilizadas(arrayConteudoMaisUtilizadas);
			}
			var arrayConteudoOrdem = personalizacao.obterCategoria("ibpf.telaIncial.menuLateralPosicaoItem", "MLO", "1");
			if (arrayConteudoOrdem == null || arrayConteudoOrdem == "null" || arrayConteudoOrdem == "undefined" || arrayConteudoOrdem.length == 0) {
				arrayConteudoOrdem = new Array();
				arrayConteudoOrdem.push(new Conteudo("0", "lateral_meus_saldos"));
				arrayConteudoOrdem.push(new Conteudo("1", "lateral_mais_utilizadas"));
				arrayConteudoOrdem.push(new Conteudo("2", "lateral_outras_funcoes"));
				arrayConteudoOrdem.push(new Conteudo("3", "lateral_apoio_atendimento"));
				personalizacao.salvarCategoriaArray("ibpf.telaIncial.menuLateralPosicaoItem", arrayConteudoOrdem, "MLO", "1");
			}
			ordenarDivs(arrayConteudoOrdem);
			var arrayConteudoVisibilidade = personalizacao.obterCategoria("ibpf.telaIncial.menuLateralStatusItem", "MLV", "1");
			if (arrayConteudoVisibilidade == null || arrayConteudoVisibilidade == "null" || arrayConteudoVisibilidade == "undefined" || arrayConteudoVisibilidade.length == 0) {
				arrayConteudoVisibilidade = new Array();
				arrayConteudoVisibilidade.push(new Conteudo("lateral_mais_utilizadas", "1"));
				arrayConteudoVisibilidade.push(new Conteudo("lateral_outras_funcoes", "1"));
				arrayConteudoVisibilidade.push(new Conteudo("lateral_apoio_atendimento", "1"));
				arrayConteudoVisibilidade.push(new Conteudo("lateral_meus_saldos", "1"));
				personalizacao.salvarCategoriaArray("ibpf.telaIncial.menuLateralStatusItem", arrayConteudoVisibilidade, "MLV", "1");
			}
			atualizarVisibilidadeDivs(arrayConteudoVisibilidade);
			if (window.parent.ajustaAlturaMiolo) {
				window.parent.ajustaAlturaMiolo();
			}
		});
		
		$("#lateral").bind("sortupdate", function(event, ui) {
			var novoArrayConteudo = new Array();
			$("#lateral").find("dl").each(function(index) {
				novoArrayConteudo.push(new Conteudo(index, $(this).attr("id")));
			});
			personalizacao.salvarCategoriaArray("ibpf.telaIncial.menuLateralPosicaoItem", novoArrayConteudo, "MLO", "1");
		});
		
		//Posicao Financeira
		if (flagAtivarMiniPosicaoFinanceira == 1) {
			temporizadorPosicaoFinanceira(tempoPosFinan);
		}
		
	})(jQuery);
}

//Posicao Financeira
function temporizadorPosicaoFinanceira(tempo) {
	atualizarMiniPosicaoFinanceira();
	if (tempo != null && tempo != '' && tempo > 0) {
		setTimeout("temporizadorPosicaoFinanceira("+tempo+")", tempo*1000);
	}
}

function atualizarMiniPosicaoFinanceira() {
	jQuery.ajax({
			type:"POST",
			url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
			data:"AJAX_REQUEST=ajax.command.menu.lateral.posicao.financeira",
			dataType:"json",
			beforeSend: function() {
				jQuery("#boxLisPosFinan").find("li.itemPosFin").remove();
				jQuery("#boxLisPosFinan").addClass("none");
				jQuery('#atualizandoMiniPosicao').removeClass("none");
			},
			complete: function() {
			},
			success: function(data,textStatus) {
				var clone = null;
				var obj = null;
				if (data == null || data.length == 0) {
					return;
				}
				//Removendo lista para atualiza��o
				jQuery("#boxLisPosFinan").find("li.itemPosFin").remove();
				
				for(i = 0; i < data.length; i++) {
					clone = jQuery("#boxLisPosCloner").clone();
					clone.appendTo(jQuery("#boxLisPosFinan"));
					clone.attr("id","").removeClass("none").addClass("itemPosFin");

					obj = data[i];
					clone.find("#lnkDescPos").addClass("tabindex").attr("id","").attr("title", obj.desc+", R$ " + obj.valor);
					clone.find("#txtDescPos").addClass("tabindex").attr("id","").html(obj.desc);
					try {
						var valor = parseFloat(obj.valor);
						if (valor < 0) {
							clone.find("#txtValPos").addClass("tabindex negativo").attr("id","").html(obj.valor);
						} else {
							clone.find("#txtValPos").addClass("tabindex").attr("id","").html(obj.valor);
						}
					} catch (e) {
						clone.find("#txtValPos").addClass("tabindex").attr("id","").html(obj.valor);
					}
				}

				obterDataHoraAtualMPF();
				jQuery('#atualizandoMiniPosicao').addClass("none");
				jQuery("#boxLisPosFinan").removeClass("none");
				var pg = window.top.document.getElementById('paginaCentral').contentWindow.document.getElementById('paginaInicial');
				if (pg != null && pg.value == "Simplificada") {
					exibirMiniPosFinan();
					if (window.parent.ajustaAlturaMiolo) {
						window.parent.ajustaAlturaMiolo();
					}
				}
			},
			error: function(req,status) {
				ocultarMiniPosFinan();
			}
		});
}

function obterDataHoraAtualMPF() {
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.menu.lateral.obter.data.hora.atual",
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			clone = jQuery("#linkAtualizarMiniPosicaoCloner").clone();
			clone.appendTo(jQuery("#boxLisPosFinan"));
			clone.attr("id","").removeClass("none").addClass("itemPosFin");
			jQuery(".valorDataAtual").html(data.conteudo);
		},
		error: function(req,status) {
		}
	});
}

function atualizarPosicaoFinanceira() {
	if (flagAtivarMiniPosicaoFinanceira == 1) {
		atualizarMiniPosicaoFinanceira();
	}
}

function recarregarMaisUtilizadas() {
	for (i = 0; i < 10; i++) {
		jQuery("#maisUtilizadas" + i).css("display", "none");
		jQuery("#tituloLink" + i).html("");
		jQuery("#linkMaisUtilizadas" + i).attr("href", "javascript:;");
		jQuery("#linkMaisUtilizadas" + i).attr("title", "");
	}
	var arrayConteudoMaisUtilizadas = personalizacao.obterCategoria("ibpf.telaInicial.maisUtilizadas.opcoes", "NAB", "1");
	atualizarMaisUtilizadas(arrayConteudoMaisUtilizadas);
}

function atualizarPersonalizacaoSideMenu(chave, valor) {
	var novoArrayConteudo = new Array();
	novoArrayConteudo.push(new Conteudo(chave, valor));
	personalizacao.salvarCategoriaArray("ibpf.telaIncial.menuLateralStatusItem", novoArrayConteudo, "MLV", "1");
}

function atualizaSaudacao(horaSaudacao, minutoSaudacao, segundoSaudacao) {
	if (segundoSaudacao >= 59) {
		segundoSaudacao = -1;
		minutoSaudacao = minutoSaudacao + 1;
		if (minutoSaudacao >= 60) {
			minutoSaudacao = 00;
			horaSaudacao = horaSaudacao + 1;
			if (horaSaudacao >= 24) {
				horaSaudacao = 00;
			}
		}
	}

	segundoSaudacao = segundoSaudacao + 1;
    
	var saudacao = "Boa noite, ";
    if (0 <= horaSaudacao && horaSaudacao < 12) {
    	saudacao = "Bom dia, ";
    } else if (12 <= horaSaudacao && horaSaudacao < 18) {
    	saudacao = "Boa tarde, ";
    }
    document.getElementById("saudacao").innerHTML = saudacao;
    document.getElementById("saudacao").title = saudacao + document.getElementById("vvSaudacao").value;

    setTimeout("atualizaSaudacao("+ horaSaudacao +","+ minutoSaudacao +","+ segundoSaudacao +")", 1000);
}

function obterEmailMenuLateral() {
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.menu.lateral.email.consultar",
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			if (data.conteudo > 0) {
				window.top.document.getElementById("caixaEmailMenuLateral").style.display = "";
			}
		},
		error: function(req,status) {
		}
	});
}
// FIM - MENU LATERAL


//INICIO - PAGINA INICIAL SIMPLIFICADA
function carregarPaginaInicialSimplificada() {
	(function ($) {
		$(document).ready(function(){
			var personalizacao = getComponentePersonalizacao();
			var arrayConteudoOperacao = personalizacao.obterCategoria("ibpf.telaInicial.opcoesPaginaSimplificada", "NAA", "1");
			if (arrayConteudoOperacao == null || arrayConteudoOperacao == "null" || arrayConteudoOperacao == "undefined" || arrayConteudoOperacao.length == 0) {
				arrayConteudoOperacao = new Array();
				arrayConteudoOperacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|PDV|SCF|X|G"));
				personalizacao.salvarCategoriaArray("ibpf.telaInicial.opcoesPaginaSimplificada", arrayConteudoOperacao, "NAA", "1");
			}
			atualizarListaOperacao(arrayConteudoOperacao);
		});
	})(jQuery);
}

function atualizarListaOperacao(arrayConteudo) {
	if (arrayConteudo == null || arrayConteudo == "null" || arrayConteudo == "undefined" || arrayConteudo.length == 0) {
		arrayConteudo = new Array();
		arrayConteudo.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|PDV|SCF|X|G"));
	}
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.personalizacao.obter.lista.conteudo.servico&codServicos="+arrayConteudo[0].getValor(),
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			atualizarListaOperacaoSucesso(data.conteudo);
		},
		error: function(req,status) {
		}
	});
}

function atualizarListaOperacaoSucesso(conteudoServicos) {
	var conteudoValidado = conteudoServicos.split("|");
	var siglasValidadas = "";
	
	var valores;
	var descricaoPai;
	var descricaoItem;
	var descricaoItemPai;
	var url;
	var siglaPai;
	var siglaServico;
	
	for (i = 0; i < conteudoValidado.length; i++) {
		valores = conteudoValidado[i].split("#");
		descricaoPai = valores[0];
		descricaoItem = valores[1];
		descricaoItemPai = valores[4];
		url = valores[2];
		siglaPai = valores[3];
		siglaServico = valores[5];
		jQuery("#" + "operacao" + i).css("display", "block");
		jQuery("#linkOperacao" + i).html(descricaoPai + jQuery("#linkOperacao" + i).html());
		jQuery("#subtituloOperacao" + i).html(descricaoItemPai + ":");
		jQuery("#descricaoOperacao" + i).html(descricaoItem);
		if (url != 'javascript:;' && url != "") {
			jQuery("#linkOperacao" + i).attr("href", url);
		} else {
			jQuery("#linkOperacao" + i).attr("href", url);
		}
		jQuery("#linkOperacao" + i).attr("title", descricaoPai + ": " + descricaoItem);
		if (siglaPai == "S") {
			jQuery("#" + "operacao" + i).addClass("conta");
		} else if (siglaPai == "P") {
			jQuery("#" + "operacao" + i).addClass("pagamento");
		} else if (siglaPai == "T") {
			jQuery("#" + "operacao" + i).addClass("transferencia");
		} else if (siglaPai == "C") {
			jQuery("#" + "operacao" + i).addClass("cartoes");
		} else if (siglaPai == "L") {
			jQuery("#" + "operacao" + i).addClass("celulares");
		} else if (siglaPai == "E") {
			jQuery("#" + "operacao" + i).addClass("emprestimos");
		} else if (siglaPai == "I") {
			jQuery("#" + "operacao" + i).addClass("investimentos");
		} else if (siglaPai == "B") {
			jQuery("#" + "operacao" + i).addClass("homebroker");
		} else if (siglaPai == "Q") {
			jQuery("#" + "operacao" + i).addClass("capitalizacao");
		} else if (siglaPai == "V") {
			jQuery("#" + "operacao" + i).addClass("previdencia");
		} else if (siglaPai == "N") {
			jQuery("#" + "operacao" + i).addClass("seguranca");
		} else if (siglaPai == "O") {
			if (siglaServico == "OI") {
				jQuery("#" + "operacao" + i).addClass("infoemail");
			} else {
				jQuery("#" + "operacao" + i).addClass("servicos");
			}
			
		} else if (siglaPai == "Z1") {
			if (siglaServico == "G") {
				jQuery("#" + "operacao" + i).addClass("agendamentos");
			} else if (siglaServico == "OI") {
				jQuery("#" + "operacao" + i).addClass("infoemail");
			} else if (siglaServico == "Z11") {
				jQuery("#" + "operacao" + i).addClass("calculadora");
			} else if (siglaServico == "M") {
				jQuery("#" + "operacao" + i).addClass("avisos");
			} else if (siglaServico == "D") {
				jQuery("#" + "operacao" + i).addClass("agendadanaoefetuadas");
			} else {
				jQuery("#" + "operacao" + i).addClass("funcoes");
			}
		
		} else if (siglaPai == "Z2") {
			if (siglaServico == "ACR") {
				jQuery("#" + "operacao" + i).addClass("acessorapido");
			} else if (siglaServico == "Y") {
				jQuery("#" + "operacao" + i).addClass("buscador");
			} else if (siglaServico == "W") {
				jQuery("#" + "operacao" + i).addClass("mapadeservicos");
			} else {
				jQuery("#" + "operacao" + i).addClass("atendimento");
			}
			
		} else {
			jQuery("#" + "operacao" + i).addClass("conta");
		}
		
		if (siglasValidadas == "") {
			siglasValidadas = siglaServico;
		} else {
			siglasValidadas = siglasValidadas + "|" + siglaServico;
		}
	}
	
	btoSize();
	
	if (window.parent && window.parent.ajustaAlturaMiolo) {
		window.parent.ajustaAlturaMiolo();
	}
}
//FIM - PAGINA INICIAL SIMPLIFICADA


//INICIO - PAGINA INICIAL AVAN�ADA
function identificarBrowser() {
	var ua = navigator.userAgent.toLowerCase();
	var browserName = "";
	if ( ua.indexOf( "opera" ) != -1 ) {
		browserName = "opera";
	} else if ( ua.indexOf( "msie" ) != -1 ) {
		browserName = "msie";
	} else if ( ua.indexOf( "safari" ) != -1 ) {
		browserName = "safari";
	} else if ( ua.indexOf( "mozilla" ) != -1 ) {
		if ( ua.indexOf( "firefox" ) != -1 ) {
			browserName = "firefox";
		} else {
			browserName = "mozilla";
		}
	}
	return browserName;
}

function obtemAlturaIframeLanctoFuturos(idDoIframeSerRedimensionado) {
	var browserName = identificarBrowser();
	var frame = document.getElementById(idDoIframeSerRedimensionado);
	var frameDoc = (frame.contentDocument) ? frame.contentDocument : frame.contentWindow.document;
	var frameStyle = (frame.style) ? frame.style : frame;
	var height = 0;
	var heightItensFlutuantes = 0;
	var allTags;
    var tag = 0;

	if(browserName == "msie") {
		allTags = frameDoc.getElementsByTagName("div");
		for (var tg = 0; tg < allTags.length; tg++) {
			tag = allTags[tg];
			if (tag.scrollHeight > height) {
				height = tag.scrollHeight;
			}
			if (tag.className == "dp-popup") {
				if (heightItensFlutuantes < tag.offsetTop + tag.scrollHeight + 25) {
					heightItensFlutuantes = tag.offsetTop + tag.scrollHeight + 25;
				}
			}
		}
	} else {
		allTags = frameDoc.getElementsByTagName('html');
		for (var tg = 0; tg < allTags.length; tg++)
		{
			tag = allTags[tg];
			if (browserName == "safari" || browserName == "opera") {
				height = tag.offsetTop + tag.scrollHeight;
			} else {
				height = tag.offsetTop + tag.offsetHeight;
			}
		}
		allTags = frameDoc.getElementsByClassName('dp-popup');
		for (var tg = 0; tg < allTags.length; tg++)
		{
			tag = allTags[tg];
			if (heightItensFlutuantes < tag.offsetTop + tag.scrollHeight + 25) {
				heightItensFlutuantes = tag.offsetTop + tag.scrollHeight + 25;
			}
		}
	}

	if (heightItensFlutuantes > height) {
		height = heightItensFlutuantes;
	}

	return height;

}

var tLactoFut = null;
function autoIframeInicializacaoLanctoFuturos() {
	try {
		var frame = document.getElementById("lancamentosFuturos");
		var frameDoc = (frame.contentDocument) ? frame.contentDocument : frame.contentWindow.document;
		var frameStyle = (frame.style) ? frame.style : frame;

		var maxHeight = obtemAlturaIframeLanctoFuturos("lancamentosFuturos");
				
		var height = maxHeight;
		
		frameStyle.height = height + "px";
		alturaAtualFrame = height;
		
		if (window.parent && window.parent.autoIframe) {
			window.parent.autoIframe();
		}
        if (tLactoFut == null) {
            tLactoFut = setInterval("autoIframeInicializacaoLanctoFuturos()", 500);
        }
	}
	catch (err) {
	}
}

var t = null;

function autoIframePosicaoFinanceira(frame) {
    try {
		var frameDoc = (frame.contentDocument) ? frame.contentDocument : frame.contentWindow.document;
		var frameStyle = (frame.style) ? frame.style : frame;

		var height = obtemAlturaIframeLanctoFuturos("posicaoFinanceira");
				
		frameStyle.height = height + "px";
		alturaAtualFrame = height;
		
		if (window.parent && window.parent.autoIframe) {
            window.parent.autoIframe();
        }
		
        if (t == null) {
			t = setInterval("iframeThreadPosicaoFinanceira()", 500);
		}
    } catch (e) {
    }
}

/**
*    Thread para autoredimencionamento
*/
function iframeThreadPosicaoFinanceira() {
    autoIframePosicaoFinanceira(document.getElementById("posicaoFinanceira"));
}
//FIM - PAGINA INICIAL AVAN�ADA


// INICIO - P�GINA INICIAL
function definirPaginaInicial() {
	var paginaInicial = document.getElementById("urlInicial").value;
	if (paginaInicial != "") {
		if (paginaInicial.indexOf("paginaInicialSimplificada.jsf") > 0) {
			setEstilo('Simplificada');
		}
		document.getElementById("paginaCentral").src = paginaInicial;
	} else {
		var personalizacao = getComponentePersonalizacao();
		var categoriaPersonalizacao = personalizacao.obterCategoria("paginaInicial", "H", "1");
		if (!categoriaPersonalizacao || categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined") {
			paginaInicial = "0";
			categoriaPersonalizacao = new Array();
			categoriaPersonalizacao.push(new Conteudo("url", "0"));
			personalizacao.salvarCategoriaArray("paginaInicial", categoriaPersonalizacao, "H", "1");
		} else {
			paginaInicial = categoriaPersonalizacao[0].getValor();
		}
		if (paginaInicial == "1") {
			paginaInicial = "/ibpftelainicial/paginaInicialSimplificada.jsf";
			setEstilo('Simplificada');
		} else {
			paginaInicial = "/ibpftelainicial/paginaInicialAvancada.jsf";
			setEstilo('Avancada');
		}
		document.getElementById("paginaCentral").src = document.getElementById("urlBase").value + paginaInicial + "?CTL=" + document.getElementById('ctl').value;
	}
}

function gravaPreferenciaPaginaInicial(paginaInicial) {
	var personalizacao = getComponentePersonalizacao();
	var categoriaPersonalizacao = personalizacao.obterCategoria("paginaInicial", "H", "1");
	if (!categoriaPersonalizacao || categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined") {
		categoriaPersonalizacao = new Array();
		categoriaPersonalizacao.push(new Conteudo("url", "0"));
	} else {
		if (paginaInicial == "Simplificada") {
			categoriaPersonalizacao.push(new Conteudo("url", "1"));
		} else {
			categoriaPersonalizacao.push(new Conteudo("url", "0"));
		}
	}
	personalizacao.salvarCategoriaArray("paginaInicial", categoriaPersonalizacao, "H", "1");
}

function redirecionarPaginaInicial() {
	var personalizacao = getComponentePersonalizacao();
	var categoriaPersonalizacao = personalizacao.obterCategoria("paginaInicial", "H", "1");
	var url = "";
	if (!categoriaPersonalizacao || categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined") {
		url = "0";
		categoriaPersonalizacao = new Array();
		categoriaPersonalizacao.push(new Conteudo("url", "0"));
		personalizacao.salvarCategoriaArray("paginaInicial", categoriaPersonalizacao, "H", "1");
	} else {
		url = categoriaPersonalizacao[0].getValor();
	}
	if (url == "1") {
		url = "/ibpftelainicial/paginaInicialSimplificada.jsf";
		setEstilo('Simplificada');
	} else {
		url = "/ibpftelainicial/paginaInicialAvancada.jsf";
		setEstilo('Avancada');
	}

	window.location = document.getElementById("urlBase").value + 
					url + "?CTL=" + 
					document.getElementById('ctl').value;
}
// FIM - P�GINA INICIAL


//INICIO - HEADER
function ativarItemMenu(obj){
	jQuery(".menuPrincipal li a.on").removeClass("on");
	jQuery(obj).addClass("on");
}

function setEstilo(itemAcionado) {
	if (itemAcionado == "Simplificada") {
		window.top.document.getElementById("menuSimplificada").className = "tp1 tp1On";
		window.top.document.getElementById("menuAvancada").className = "tp1";
	} else if (itemAcionado == "Avancada") {
		window.top.document.getElementById("menuSimplificada").className = "tp1";
		window.top.document.getElementById("menuAvancada").className = "tp1 tp1On";
	} else {
		window.top.document.getElementById("menuSimplificada").className = "tp1";
		window.top.document.getElementById("menuAvancada").className = "tp1";
	}
}

function inicializarHeader() {
	if (document.getElementById('filtroBuscador').value == 'S') {
		jQuery("#buscadorHeader").show();
	} else {
		jQuery("#buscadorHeader").hide();
	}
}

function removerEstiloMenuAtivo() {
	jQuery(".menuPrincipal li a.on").removeClass("on");
}
//FIM - HEADER

//Verificando personaliza��o
jQuery(document).ready(function(){
	var personalizacao = getComponentePersonalizacao();
	var links = personalizacao.obterCategoria("ibpf.telaInicial.exibicao.valores", "H", "1");
	if (links == null || links == "null" || links == "undefined") {
		links = new Array();
		links.push(new Conteudo("posicaoFinanceira", "1"));
		links.push(new Conteudo("lancamentosFuturos", "1"));
		links.push(new Conteudo("telaInicial", "0"));
		personalizacao.salvarCategoriaArray("ibpf.telaInicial.exibicao.valores", links, "H", "1");
	} 

	//Link da tela inicial
	jQuery("#lnkOcultarValores").unbind('click').bind('click', function(){
	    var links = personalizacao.obterCategoria("ibpf.telaInicial.exibicao.valores", "H", "1");
	    if (links == null || links == "null" || links == "undefined") {
			links = new Array();
			links.push(new Conteudo("posicaoFinanceira", "1"));
			links.push(new Conteudo("lancamentosFuturos", "1"));
			links.push(new Conteudo("telaInicial", "0"));
		} 
		var linkTelaInicial = null;
		var linkAux = null;
		for (i = 0; i < links.length; i++) {
			linkAux = links[i];
			if ("telaInicial" == linkAux.getChave()) {
				// Recupera o conteudo do link da tela inicial para uso posterior a essa itera��o
				linkTelaInicial = linkAux;
				break;
			} 
		}

		for (i = 0; i < links.length; i++) {
			linkAux = links[i];
			if ("telaInicial" != linkAux.getChave()) {
				try {
					if ('0' == linkTelaInicial.getValor()) {
						 if (linkAux.getChave() == "posicaoFinanceira") {
							 //chamar fun��o da posi��o financeira para ocultar
							 document.getElementById(linkAux.getChave()).contentWindow.ocultarValores();
						 } else if (linkAux.getChave() == "lancamentosFuturos") {
							 //chamar fun��o de lancamentos futuros para ocultar
							 document.getElementById(linkAux.getChave()).contentWindow.ocultarValoresFuturos();
						 }   
						linkAux.setValor('0');
					} else {
						if (linkAux.getChave() == "posicaoFinanceira") {
							 //chamar fun��o da posi��o financeira para mostrar
							 document.getElementById(linkAux.getChave()).contentWindow.exibirValores();
						 } else if (linkAux.getChave() == "lancamentosFuturos") {
							 //chamar fun��o de lancamentos futuros para mostrar
							 document.getElementById(linkAux.getChave()).contentWindow.mostrarValoresFuturos();
						 }   
						linkAux.setValor('1');
					}
				} catch (err){}
			}
		}
		
		if ('1' == linkTelaInicial.getValor()) {
			jQuery(this).text('Ocultar valores')
						.attr("title", "Pressione ENTER para Ocultar valores");
			linkTelaInicial.setValor('0');
		} else {
			jQuery(this).text('Mostrar valores')
						.attr("title", "Pressione ENTER para Mostrar valores");
			linkTelaInicial.setValor('1');
		}
		
		//Atualizando na personaliza��o
		personalizacao.salvarCategoriaArray("ibpf.telaInicial.exibicao.valores", links, "H", "1");
	});
});

function carregarExibicaoLancFuturos() {
	var personalizacao = getComponentePersonalizacao();
	//Verifica��o Inicial
	var links = personalizacao.obterCategoria("ibpf.telaInicial.exibicao.valores", "H", "1");
	if (links == null || links == "null" || links == "undefined") {
		links = new Array();
		links.push(new Conteudo("posicaoFinanceira", "1"));
		links.push(new Conteudo("lancamentosFuturos", "1"));
		links.push(new Conteudo("telaInicial", "0"));
	}
	var linkAux = null;
	var ocultarLnkTI = false;
	for (i = 0; i < links.length; i++) {
		linkAux = links[i];
		if ("telaInicial" == linkAux.getChave()) {
			// Recupera o conteudo do link da tela inicial para uso posterior a essa itera��o
			linkTelaInicial = linkAux;
		} else {
			try {
				//Se valor igual a zero, deve-se Ocultar
				 if ('0' == linkAux.getValor()) {
					 if (linkAux.getChave() == "lancamentosFuturos") {
						 //chamar fun��o de lancamentos futuros para ocultar
						 document.getElementById(linkAux.getChave()).contentWindow.ocultarValoresFuturos();
					 }
				} else {
					if (linkAux.getChave() == "lancamentosFuturos") {
						 //chamar fun��o de lancamentos futuros para mostrar
						document.getElementById(linkAux.getChave()).contentWindow.mostrarValoresFuturos();
					 }  
					ocultarLnkTI = true;
				}
			} catch (err){}
		 }
	 }

	//Se algum link estiver como Mostrar, logo o link da tela inicial deve ser ocultar
	 if (ocultarLnkTI) {
		jQuery("#lnkOcultarValores", window.parent.frames['paginaCentral'].document).text('Ocultar valores')
					.attr("title", "Pressione ENTER para Ocultar valores");
		linkTelaInicial.setValor('0');
	 } else {
		jQuery("#lnkOcultarValores", window.parent.frames['paginaCentral'].document).text('Mostrar valores')
					.attr("title", "Pressione ENTER para Mostrar valores");
		linkTelaInicial.setValor('1');
	 }
	 //Atualiza��o no personalizacao
	 personalizacao.salvarCategoriaArray("ibpf.telaInicial.exibicao.valores", links, "H", "1");
}