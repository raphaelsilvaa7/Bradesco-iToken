var listaSinonimosComprovantes = "SX|PX|TX|CX|LX|EX|IX|QX|VX|OX";
var listaSinonimosInfoemail = "OI1|OI2";
var listaSinonimosAgendamentos = "OG";

(function ($) {
	
	$(document).ready(function() {
		// pega o nome do arquivo shtm 
		// usado para nao aparecer o carregando no mais utilizados na pagina de personalizacao da pagina simplificada
		var u = document.URL;
		var up = u.lastIndexOf('/');
		u = u.slice(up+1);
		var modalPrincipal;
		if (navigator.appName != "Microsoft Internet Explorer") {
			modalPrincipal = window.top.document.getElementById('paginaCentral').contentDocument;
		}
		
		var ctl = parent.$('#ctl').val();
		
		// funcao de personalizacao ################################################################
		$('.lista_personalizacao li a').live('click',function() {
			$(this).addClass('fill_label');
		});
	
		
		$('#modalInfraEstrutura .colMenu ul li a').click(function() {
			if (navigator.appName == "Microsoft Internet Explorer") {
				modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
			}
			var codServico = $(this).parent().attr('class');
			if (listaSinonimosComprovantes.indexOf(codServico) > -1) {
				codServico = "X";
			}
			if (listaSinonimosInfoemail.indexOf(codServico) > -1) {
				codServico = "OI";
			}
			if (listaSinonimosAgendamentos.indexOf(codServico) > -1) {
				codServico = "G";
			}
			
			var atalhoId = $('.fill_label', modalPrincipal).parent().attr('class');
			atalhoId = atalhoId.substr('atalho_').replace('atalho_','');
			if (atalhoId.indexOf(" ") > 0) {
				atalhoId = atalhoId.substr(0, atalhoId.indexOf(" "));
			}
		
			var codServicoCadastrado;
			var erro = false;
			//verifica se o item j� consta na lista		
			listaCadastrados =  $('.lista_personalizacao li.fill', modalPrincipal).each(function() {
				codServicoCadastrado = $(this).attr('class').split('servcod_');
				if(codServico == codServicoCadastrado[1]) {
					$('#mapaServicosPersonalizacao').hide();
					$('#boxRetorno').show();
					$('#boxStatus').addClass('box-erro');
					$('#mensagemPersonalizacao').attr('title', 'Este atalho j� existe.').html('Este atalho j� existe.');
					$('.tabindex').removeClass("tabindex").removeAttr("tabindex");
					$('#mensagemPersonalizacao').addClass("tabindex tab-1");
					$('.bto_fechar').addClass("tabindex tab-1");
					$('.lnkFechar').addClass("tabindex");
					$.tabindex();
					erro = true;
					return false;
				}
			});
			
			if (codServico == '') {
				$('#mapaServicosPersonalizacao').hide();
				$('#boxRetorno').show();
				$('#boxStatus').addClass('box-erro');
				$('#mensagemPersonalizacao').attr('title', 'C�digo de servi�o n�o cadastrado.').html('C�digo de servi�o n�o cadastrado.');
				erro = true;
			}
			
			if (erro) {
				return false;
			}
			
			var titulo = $(this).attr('title');
			var url = $(this).attr('class');
			url = url.substring(url.lastIndexOf('url_') + 4);
			
			personalizacao = getComponentePersonalizacao();
			var categoriaPersonalizacao;
			var novoArray = new Array();
			var novoServicos;
			
			if ($('#conteudo .titulo h2 sup', modalPrincipal).text() == "NAB") {
				categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.telaInicial.maisUtilizadas.opcoes", "NAB", "1");
				if (categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined" || categoriaPersonalizacao.length == 0) {
					categoriaPersonalizacao = new Array();
					categoriaPersonalizacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|X|G"));
				}
				novoServicos = categoriaPersonalizacao[0].getValor() + "|" + codServico;
				novoArray.push(new Conteudo("atalhos", novoServicos));
				personalizacao.salvarCategoriaArray("ibpf.telaInicial.maisUtilizadas.opcoes", novoArray, "NAB", "1");
				for (var posicao = 1; posicao < 11; posicao++) {
					$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('span').attr('class', 'num');
					$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('a:first').attr('class', 'lnk_seta_personalizacao tabindex').attr('title', 'Incluir atalho').attr('target', 'modal_infra_estrutura').attr('href', 'personalizarMaisUtilizadasIncluir.jsf?CTL=' + ctl).html('Incluir atalho').next().attr('class', 'bto_excluir tabindex').attr('style', 'display: none ! important;').attr('href', 'personalizarMaisUtilizadasExcluir.jsf?CTL=' + ctl);
					$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).attr('class', 'atalho_' + posicao);
				}
			} else {
				categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.telaInicial.opcoesPaginaSimplificada", "NAA", "1");
				if (categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined" || categoriaPersonalizacao.length == 0) {
					categoriaPersonalizacao = new Array();
					categoriaPersonalizacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|PDV|SCF|X|G"));
				}
				novoServicos = categoriaPersonalizacao[0].getValor() + "|" + codServico;
				novoArray.push(new Conteudo("atalhos", novoServicos));
				personalizacao.salvarCategoriaArray("ibpf.telaInicial.opcoesPaginaSimplificada", novoArray, "NAA", "1");
				for (var posicao = 1; posicao < 13; posicao++) {
					$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('span').attr('class', 'num');
					$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('a:first').attr('class', 'lnk_seta_personalizacao tabindex').attr('title', 'Incluir atalho').attr('target', 'modal_infra_estrutura').attr('href', 'personalizarPaginaSimplificadaIncluir.jsf?CTL=' + ctl).html('Incluir atalho').next().attr('class', 'bto_excluir tabindex').attr('style', 'display: none ! important;').attr('href', 'personalizarPaginaSimplificadaExcluir.jsf?CTL=' + ctl);
					$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).attr('class', 'atalho_' + posicao);
				}
			}
			
			var conteudo;
		    var listaLI;
		    var arrayValor;
		    var descricaoItem;
		    var descricaoItemPai;
		    var servicos = novoServicos.split("|");
	
		    var linha = 0;
		    for (i = 0; i < servicos.length; i++) {
		    	conteudo = obterConteudoServico(servicos[i]);
				linha = i + 1;
				listaLI = $('.lista_personalizacao li.atalho_' + linha, modalPrincipal);
				arrayValor = (conteudo).split('|');
				descricaoItem = arrayValor[1];
				descricaoItemPai = arrayValor[4];
				listaLI.removeClass('fill_label').addClass('fill servcod_' + servicos[i]);
				listaLI.find('a:first').html("<font style='color:#666666; font:Tahoma'>" + descricaoItemPai + 
						":&nbsp;</font><font style='color:#333333; font:Tahoma'>" + descricaoItem + "</font>").removeAttr('target').attr('href','javascript:;').attr('title',descricaoItemPai + ": " + descricaoItem);
				if (servicos.length > 1) {
					listaLI.find('span').addClass('drag').css('cursor','move');
					listaLI.find('a:eq(1)').attr("title","Excluir atalho " + descricaoItem).css("display", "");
				}
			}
			
			parent.fecharModalInfraEstrutura();
			
			setTimeout (function(){parent.$('.carregando_nav_content').fadeOut(200);} , 1000);
			
			if ($('#conteudo .titulo h2 sup', modalPrincipal).text() == "NAB") {
				parent.recarregarMaisUtilizadas();
			}
			
		});
	
		
		$('.lista_personalizacao li .bto_excluir').click(function() {
			$('.lista_personalizacao li .bto_excluir').each(function() {
				$(this).parent().removeClass('exclude');
			});
			
			$(this).parent().addClass('exclude');
			$('.item_delete').html($(this).prev().html());
		});
		
		
		$('#modalInfraEstrutura .excluir_mais_utilizadas').click(function() {
			if (navigator.appName == "Microsoft Internet Explorer") {
				modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
			}
					
			atalhoId = $('.exclude', modalPrincipal).find('a:first').addClass('lnk_seta_personalizacao').parent().attr('class');
			atalhoId = atalhoId.substr('atalho_').replace('atalho_','');
			if (atalhoId.indexOf(" ") > 0) {
				atalhoId = atalhoId.substr(0, atalhoId.indexOf(" "));
			}
	
			var codServico;
			var arrayClasse = $('.exclude', modalPrincipal).attr('class').split(' ');
			for (var i = 0; i < arrayClasse.length; i++) {
				if (arrayClasse[i].indexOf('servcod_') > -1) {
					codServico = arrayClasse[i].substr(8);
					break;
				}
			}
			
			personalizacao = getComponentePersonalizacao();
			var categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.telaInicial.maisUtilizadas.opcoes", "NAB", "1");
			if (categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined" || categoriaPersonalizacao.length == 0) {
				categoriaPersonalizacao = new Array();
				categoriaPersonalizacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|X|G"));
			}
			var servicos = categoriaPersonalizacao[0].getValor().split("|");
			var novoServicos = "";
			
			if (servicos) {
				var novoArray = new Array();
			    for (i = 0; i < servicos.length; i++) {
					if (servicos[i] != codServico) {
						if (novoServicos == "") {
							novoServicos += servicos[i];
						} else {
							novoServicos += "|" + servicos[i];
						}
					}
			    }
			    novoArray.push(new Conteudo("atalhos", novoServicos));
				personalizacao.salvarCategoriaArray("ibpf.telaInicial.maisUtilizadas.opcoes", novoArray, "NAB", "1");
			}
			
			for (var posicao = 1; posicao < 11; posicao++) {
				$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('span').attr('class', 'num');
				$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('a:first').attr('class', 'lnk_seta_personalizacao tabindex').attr('title', 'Incluir atalho').attr('target', 'modal_infra_estrutura').attr('href', 'personalizarMaisUtilizadasIncluir.jsf?CTL=' + ctl).html('Incluir atalho').next().attr('class', 'bto_excluir tabindex').attr('style', 'display: none ! important;').attr('href', 'personalizarMaisUtilizadasExcluir.jsf?CTL=' + ctl);
				$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).attr('class', 'atalho_' + posicao);
			}
			
			var linha = 0;
			var conteudo;
		    var listaLI;
		    var arrayValor;
		    var descricaoItem;
		    var descricaoItemPai;
		    servicos = novoServicos.split("|");
		    for (i = 0; i < servicos.length; i++) {
		    	conteudo = obterConteudoServico(servicos[i]);
				linha = i + 1;
				listaLI = $('.atalho_' + linha, modalPrincipal);
				arrayValor = (conteudo).split('|');
				descricaoItem = arrayValor[1];
				descricaoItemPai = arrayValor[4];
				listaLI.removeClass('fill_label').addClass('fill servcod_' + servicos[i]);
				listaLI.find('a:first').html("<font style='color:#666666; font:Tahoma'>" + descricaoItemPai + 
						":&nbsp;</font><font style='color:#333333; font:Tahoma'>" + descricaoItem + "</font>").removeAttr('target').attr('href','javascript:;').attr('title',descricaoItemPai + ": " + descricaoItem);
				if (servicos.length > 1) {
					listaLI.find('span').addClass('drag').css('cursor','move');
					listaLI.find('a:eq(1)').attr("title","Excluir atalho " + descricaoItem).css("display", "");
				}
			}
		    
		    obj = $('.lista_personalizacao li', modalPrincipal).find('a.lnk_seta_personalizacao');
			if (obj.length == 9) {
				$('.lista_personalizacao li', modalPrincipal).find('a.bto_excluir').hide();
			}
							
			setTimeout (function(){parent.$('.carregando_nav_content').fadeOut(200);} , 1000);
			
			parent.recarregarMaisUtilizadas();
	
		});
	
		
		$('#modalInfraEstrutura .btn_sim_personalizacao_simplificada').click(function(){
			if (navigator.appName == "Microsoft Internet Explorer") {
				modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
			}
			
			atalhoId = $('.exclude', modalPrincipal).find('a:first').addClass('lnk_seta_personalizacao').parent().attr('class');
			atalhoId = atalhoId.substr('atalho_').replace('atalho_','');
			if (atalhoId.indexOf(" ") > 0) {
				atalhoId = atalhoId.substr(0, atalhoId.indexOf(" "));
			}
			
			var codServico;
			var arrayClasse = $('.exclude', modalPrincipal).attr('class').split(' ');
			for (var i = 0; i < arrayClasse.length; i++) {
				if (arrayClasse[i].indexOf('servcod_') > -1) {
					codServico = arrayClasse[i].substr(8);
					break;
				}
			}
		    
			personalizacao = getComponentePersonalizacao();
			
			var categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.telaInicial.opcoesPaginaSimplificada", "NAA", "1");
			if (categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined" || categoriaPersonalizacao.length == 0) {
				categoriaPersonalizacao = new Array();
				categoriaPersonalizacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|PDV|SCF|X|G"));
			}
			var servicos = categoriaPersonalizacao[0].getValor().split("|");
			var novoServicos = "";
			
			if (servicos) {
				var novoArray = new Array();
			    for (i = 0; i < servicos.length; i++) {
					if (servicos[i] != codServico) {
						novoServicos += "|" + servicos[i];
					}
			    }
			    novoServicos = novoServicos.substr(1);
			    novoArray.push(new Conteudo("atalhos", novoServicos));
				personalizacao.salvarCategoriaArray("ibpf.telaInicial.opcoesPaginaSimplificada", novoArray, "NAA", "1");
			}
			
			for (var posicao = 1; posicao < 13; posicao++) {
				$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('span').attr('class', 'num');
				$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('a:first').attr('class', 'lnk_seta_personalizacao tabindex').attr('title', 'Incluir atalho').attr('target', 'modal_infra_estrutura').attr('href', 'personalizarPaginaSimplificadaIncluir.jsf?CTL=' + ctl).html('Incluir atalho').next().attr('class', 'bto_excluir tabindex').attr('style', 'display: none ! important;').attr('href', 'personalizarPaginaSimplificadaExcluir.jsf?CTL=' + ctl);
				$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).attr('class', 'atalho_' + posicao);
			}
			
			var linha = 1;
			var conteudo;
		    var listaLI;
		    var arrayValor;
		    var descricaoItem;
		    var descricaoItemPai;
		    servicos = novoServicos.split("|");
		    for (i = 0; i < servicos.length; i++) {
		    	conteudo = obterConteudoServico(servicos[i]);
				linha = i + 1;
				listaLI = $('.atalho_' + linha, modalPrincipal);
				arrayValor = (conteudo).split('|');
				descricaoItem = arrayValor[1];
				descricaoItemPai = arrayValor[4];
				listaLI.removeClass('fill_label').addClass('fill servcod_' + servicos[i]);
				listaLI.find('a:first').html("<font style='color:#666666; font:Tahoma'>" + descricaoItemPai + 
						":&nbsp;</font><font style='color:#333333; font:Tahoma'>" + descricaoItem + "</font>").removeAttr('target').attr('href','javascript:;').attr('title',descricaoItemPai + ": " + descricaoItem);
				if (servicos.length > 1) {
					listaLI.find('span').addClass('drag').css('cursor','move');
					listaLI.find('a:eq(1)').attr("title","Excluir atalho " + descricaoItem).css("display", "");
				}
			}
	
		});
		
		$('#modalInfraEstrutura .btn_nao_mais_utilizadas').click(function(){
			if (navigator.appName == "Microsoft Internet Explorer") {
				modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
			}
			$('.lista_personalizacao li', modalPrincipal).removeClass('exclude');
			parent.fecharModalInfraEstrutura();
		});
		
		$('#modalInfraEstrutura .btn_nao_personalizacao_simplificada').click(function(){
			if (navigator.appName == "Microsoft Internet Explorer") {
				modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
			}
			$('.lista_personalizacao li', modalPrincipal).removeClass('exclude');
			parent.fecharModalInfraEstrutura();
		});
	
		
		$('ul.lista_personalizacao .drag').css('cursor', 'move');
		
		$('ul.lista_personalizacao').sortable({
			axis: 'y',
			helper : 'move',
			handle: 'span.drag, a.drag',
			items: 'li',
			placeholder: 'swap',
			tolerance: 'intersect',
			dropOnEmpty: false,
			start: function (){
				$(this).find(".ui-sortable-helper").css("background-color","#C6C6C6")
				.find(".num").css("visibility","hidden");
			},
			stop: function (){
				if ($('#conteudo .titulo h2 sup', modalPrincipal).text() == "NAB") {
					for (var posicao = 1; posicao < 11; posicao++) {
						$('.lista_personalizacao', modalPrincipal).find('li:eq(' + (posicao-1) + ')').attr('class', 'atalho_' + posicao);
						$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('span').attr('class', 'num').html(posicao + '�');
						$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('a:first').attr('class', 'lnk_seta_personalizacao tabindex').attr('title', 'Incluir atalho').attr('target', 'modal_infra_estrutura').attr('href', 'personalizarMaisUtilizadasIncluir.jsf?CTL=' + ctl).html('Incluir atalho').next().attr('class', 'bto_excluir tabindex').attr('style', 'display: none ! important;').attr('href', 'personalizarMaisUtilizadasExcluir.jsf?CTL=' + ctl);
					}
					setTimeout (function(){parent.$('.carregando_nav_content').fadeOut(200);} , 1000);
					lnksLateral = parent.$('#lateral_mais_utilizadas li').each(function () {
						$(this).css("display", "none");
					});
					parent.recarregarMaisUtilizadas();
					setTimeout (function(){parent.$('.carregando_nav_content').fadeOut(200);} , 1000);
					
					buscarLinksMaisUtilizados();

				} else {
					for (var posicao = 1; posicao < 13; posicao++) {
						$('.lista_personalizacao', modalPrincipal).find('li:eq(' + (posicao-1) + ')').attr('class', 'atalho_' + posicao);
						$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('span').attr('class', 'num').html(posicao + '�');
						$('.lista_personalizacao li.atalho_' + posicao, modalPrincipal).find('a:first').attr('class', 'lnk_seta_personalizacao tabindex').attr('title', 'Incluir atalho').attr('target', 'modal_infra_estrutura').attr('href', 'personalizarPaginaSimplificadaIncluir.jsf?CTL=' + ctl).html('Incluir atalho').next().attr('class', 'bto_excluir tabindex').attr('style', 'display: none ! important;').attr('href', 'personalizarPaginaSimplificadaExcluir.jsf?CTL=' + ctl);
					}
					buscarLinksPersonalizados();
				}
				
			},
			update: function (){
				atualizarPersonalizacao($('#conteudo .titulo h2 sup').text());
			}
	
		});
		
		$('#mapaServicosPersonalizacao .btn_personalizacao').click(function() {
			var textoVirtualVision = "";
			if ($(this).attr('class').indexOf('item_expandido') > 0) {
				$(this).removeClass("item_expandido");
				textoVirtualVision = $(this).find('span').html();
				$(this).attr('title', "Pressione ENTER para expandir se��o de op��es de " + textoVirtualVision);
			} else {
				$(this).addClass("item_expandido");
				textoVirtualVision = $(this).find('span').html();
				$(this).attr('title', "Pressione ENTER para suprimir se��o de op��es de " + textoVirtualVision);
			}
			var idLinhaClicada = $(this).attr('href');
			$('a.btn_collapse_on').each(function() {
				if ($(this).attr('href') != idLinhaClicada) {
					$(this).removeClass("btn_collapse_on");
					textoVirtualVision = $(this).find('span').html();
					$(this).attr('title', "Pressione ENTER para expandir se��o de op��es de " + textoVirtualVision);
					$(this).next().attr('style', 'display: none;');
				}
			});
		});
	
	});
	
})(jQuery);

function buscarLinksPersonalizados() {
	personalizacao = getComponentePersonalizacao();
	var categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.telaInicial.opcoesPaginaSimplificada", "NAA", "1");
	if (!categoriaPersonalizacao || categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined") {
		categoriaPersonalizacao = new Array();
		categoriaPersonalizacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|PDV|SCF|X|G"));
		personalizacao.salvarCategoriaArray("ibpf.telaInicial.opcoesPaginaSimplificada", categoriaPersonalizacao, "NAA", "1");
	}
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.personalizacao.obter.lista.conteudo.servico&codServicos="+categoriaPersonalizacao[0].getValor(),
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			buscarLinksPersonalizadosSucesso(data.conteudo);
		},
		error: function(req,status) {
		}
	});
}

function buscarLinksPersonalizadosSucesso(conteudoServicos) {
	var listaLI;
    var linha;
    var arrayValor;
    var item;
    var itemPai;
    var conteudoValidado = conteudoServicos.split("|");
	var siglasValidadas = "";
    
	for (i = 0; i < conteudoValidado.length; i++) {
		arrayValor = conteudoValidado[i].split("#");
		item = arrayValor[1];
		itemPai = arrayValor[4];
		linha = i + 1;
		
		listaLI = jQuery('.atalho_' + linha);
		listaLI.removeClass('fill_label').addClass('fill servcod_' + arrayValor[5]);
		listaLI.find('a:first').html("<font style='color:#666666; font:Tahoma'>" + itemPai +
				":&nbsp;</font><font style='color:#333333; font:Tahoma'>" + item + "</font>").removeAttr('target').attr('href','javascript:;').attr('title',itemPai + ": " + item);
		
		if (conteudoValidado.length > 1) {
			listaLI.find('span').addClass('drag').css('cursor','move');
			listaLI.find('a:eq(1)').attr("title","Excluir atalho " + item).css("display", "");
		}
		
		if (siglasValidadas == "") {
			siglasValidadas = arrayValor[5];
		} else {
			siglasValidadas = siglasValidadas + "|" + arrayValor[5];
		}
	}
	
	var novaCategoria = new Array();
    novaCategoria.push(new Conteudo("atalhos", siglasValidadas));
	personalizacao.salvarCategoriaArray("ibpf.telaInicial.opcoesPaginaSimplificada", novaCategoria, "NAA", "1");
}

function atualizarPersonalizacao(tela) {
	var personalizacao = getComponentePersonalizacao();
	var categoriaPersonalizacao = new Array();
	var servicos = "";
	var modalPrincipal = window.top.document.getElementById('paginaCentral').contentDocument;
	if (navigator.appName == "Microsoft Internet Explorer") {
		modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
	}
	jQuery("#atalhos", modalPrincipal).find("li").each(function(index) {
		var codServico = jQuery(this).attr('class');
		if (codServico.indexOf('servcod_') == -1) {
			return;
		}
		servicos += "|" + codServico.substr(codServico.indexOf('servcod_') + 8, 3);
	});
	categoriaPersonalizacao.push(new Conteudo("atalhos", servicos.substr(1)));
	if (tela == "NAA") {
		personalizacao.salvarCategoriaArray("ibpf.telaInicial.opcoesPaginaSimplificada", categoriaPersonalizacao, "NAA", "1");
	} else {
		personalizacao.salvarCategoriaArray("ibpf.telaInicial.maisUtilizadas.opcoes", categoriaPersonalizacao, "NAB", "1");
	}
}

function buscarLinksMaisUtilizados() {
	personalizacao = getComponentePersonalizacao();
	var categoriaPersonalizacao = personalizacao.obterCategoria("ibpf.telaInicial.maisUtilizadas.opcoes", "NAB", "1");
	if (!categoriaPersonalizacao || categoriaPersonalizacao == null || categoriaPersonalizacao == "null" || categoriaPersonalizacao == "undefined") {
		categoriaPersonalizacao = new Array();
		categoriaPersonalizacao.push(new Conteudo("atalhos", "SSC|SEC|SLC|PBC|PAL|TCB|TDT|LRC|X|G"));
		personalizacao.salvarCategoriaArray("ibpf.telaInicial.maisUtilizadas.opcoes", categoriaPersonalizacao, "NAB", "1");
	}
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.personalizacao.obter.lista.conteudo.servico&codServicos="+categoriaPersonalizacao[0].getValor(),
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			buscarLinksMaisUtilizadosSucesso(data.conteudo);
		},
		error: function(req,status) {
		}
	});
}

function buscarLinksMaisUtilizadosSucesso(conteudoServicos) {
    var listaLI;
    var linha;
    var arrayValor;
    var item;
    var itemPai;
    var conteudoValidado = conteudoServicos.split("|");
	var siglasValidadas = "";
    
	for (i = 0; i < conteudoValidado.length; i++) {
		arrayValor = conteudoValidado[i].split("#");
		item = arrayValor[1];
		itemPai = arrayValor[4];
		linha = i + 1;
		
		listaLI = jQuery('.atalho_' + linha);
		listaLI.removeClass('fill_label').addClass('fill servcod_' + arrayValor[5]);
		listaLI.find('a:first').html("<font style='color:#666666; font:Tahoma'>" + itemPai + 
				":&nbsp;</font><font style='color:#333333; font:Tahoma'>" + item + "</font>").removeAttr('target').attr('href','javascript:;').attr('title',itemPai + ": " + item);
		if (conteudoValidado.length > 1) {
			listaLI.find('span').addClass('drag').css('cursor','move');
			listaLI.find('a:eq(1)').attr("title","Excluir atalho " + item).css("display", "");
		}
		
		if (siglasValidadas == "") {
			siglasValidadas = arrayValor[5];
		} else {
			siglasValidadas = siglasValidadas + "|" + arrayValor[5];
		}
	}
	
	var novaCategoria = new Array();
    novaCategoria.push(new Conteudo("atalhos", siglasValidadas));
    personalizacao.salvarCategoriaArray("ibpf.telaInicial.maisUtilizadas.opcoes", novaCategoria, "NAB", "1");
}

function carregarTelaModalExclusaoNOU() {
	var modalPrincipal = window.top.document.getElementById('paginaCentral').contentDocument;
	if (navigator.appName == "Microsoft Internet Explorer") {
		modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
	}
	var nomeAtalho = jQuery('.exclude', modalPrincipal).find('a:first').find('font').eq(1).html();
	jQuery('.item_delete').html(nomeAtalho);
	jQuery('.msg_excluir_atalho_nou').attr("title", 'Voc� realmente deseja excluir o atalho ' + nomeAtalho + '? Utilize a tecla TAB para navegar.');
}

function carregarTelaModalExclusaoNIS() {
	var modalPrincipal = window.top.document.getElementById('paginaCentral').contentDocument;
	if (navigator.appName == "Microsoft Internet Explorer") {
		modalPrincipal = window.top.document.getElementById('paginaCentral').contentWindow.document;
	}
	var nomeAtalho = jQuery('.exclude', modalPrincipal).find('a:first').find('font').eq(1).html();
	jQuery('.item_delete').html(nomeAtalho);
	jQuery('.msg_excluir_atalho_nis').attr("title", 'Voc� realmente deseja excluir o atalho ' + nomeAtalho + ' da p�gina inicial simplificada? Utilize a tecla TAB para navegar.');
}

function obterConteudoServico(codServico) {
	var retorno = "";
	jQuery.ajax({
		type:"POST",
		async: false,
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.personalizacao.obter.conteudo.servico&codServico="+codServico,
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			retorno = data.conteudo;
		},
		error: function(req,status) {
		}
	});
	return retorno;
}

function retornarMapaServicosPersonalizacao() {
	jQuery('.tabindex').removeClass("tabindex").removeAttr("tabindex");
	jQuery('a').addClass("tabindex");
	jQuery('.bto_fechar').addClass("tabindex");
	jQuery('.lnkFechar').addClass("tabindex");
	jQuery.tabindex();
	jQuery('#mapaServicosPersonalizacao').show();
	jQuery('#boxRetorno').hide();
}

function inicializarVirtualVisionMapaServicos() {
	jQuery('#mapaServicosPersonalizacao .btn_personalizacao').each(function() {
		var textoVirtualVision = "";
		if (jQuery(this).attr('class').indexOf('btn_collapse_on') > 0) {
			textoVirtualVision = jQuery(this).find('span').html();
			jQuery(this).attr('title', "Pressione ENTER para suprimir se��o de op��es de " + textoVirtualVision);
		} else {
			textoVirtualVision = jQuery(this).find('span').html();
			jQuery(this).attr('title', "Pressione ENTER para expandir se��o de op��es de " + textoVirtualVision);
		}
	});
}

