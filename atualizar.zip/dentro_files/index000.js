$(function(){
		
	$('.listaPersonalizacao li').click(btoSize);
	
// LISTA DE DICAS
	var lstDica = {
		$lista : $("#listaDicas ul"),
		$v : $("#listaDicas li.tp1"),
		$a : $("#listaDicas li.tp3"),
		liW : 290,
		w: 0,
		n: 0,
		i: 0
	};
		
	lstDica.$v.css("opacity",0.5);
	lstDica.w = lstDica.$lista.find("li").length * lstDica.liW;
	lstDica.$lista.css("width", lstDica.w);
	
	lstDica.$v.click(function(){
		if (lstDica.n) {
			lstDica.i--;
			lstDica.$a.fadeTo("fast",1);
			lstDica.n += lstDica.liW;
			lstDica.$lista.animate({"left": lstDica.n}, "slow");
			if (!lstDica.i) lstDica.$v.fadeTo("normal",0.5);
		}
	});
	
	lstDica.$a.click(function(){
		if (Math.abs(lstDica.n - lstDica.liW) < lstDica.w) {
			lstDica.i++;
			lstDica.$v.fadeTo("fast",1);
			lstDica.n -= lstDica.liW;
			lstDica.$lista.animate({"left": lstDica.n}, "slow");
			if (lstDica.i + 1 === lstDica.$lista.find("li").length) lstDica.$a.fadeTo("normal",0.5);
		}
	});
// LISTA DE DICAS

// SALDOS
	var timerSaldos;

	$("#listaSaldos > li").hover(function(){
		var $saldos = $(this);

		timerSaldos = setTimeout(function(){
			$("#listaSaldos > li .detalhe:visible").not($saldos.find(".detalhe")).slideUp(200, function() {
				$(this).parent().removeClass("on");
			});

			$saldos.find(".detalhe").slideDown(200, function() { // 400 is default
			if (window.parent.autoIframe) {
					window.parent.autoIframe();
				}
			});
			$saldos.addClass("on");
		},200);
	},function(){
		if (timerSaldos) clearTimeout(timerSaldos);
	});
	/*
	$("#listaSaldos > li").click(function(evt) {
		$(this).find(".detalhe:visible").not(":animated").slideUp(200,function() {
			$(this).parent().removeClass("on");
		});
		evt.preventDefault();
	});
	*/
// SALDOS

// BANNER
	$("#lnkBanners li a").click(function(){
		var index = $("#lnkBanners li a").index(this);
		if ($("#lstBanners li").index($("#lstBanners li.on")) !== index) {
			$("#lstBanners li.on").fadeOut("500", function(){
				$(this).removeClass("on");
				$("#lnkBanners li a").removeClass("on").filter(":eq("+ index +")").addClass("on");
				$("#lstBanners li:eq(" + index + ")").fadeIn("500", function(){
					$(this).addClass("on");
				});
			});
		}
	});
//

// CALENDARIO
	//SETUP DO CALEND�RIO
	var dataAtual = new Date();
	dataAtual.setDate(21);
	dataAtual.setMonth(6);
	var diaSemana = (dataAtual.getDay() > 0 && dataAtual.getDay() < 6) ? dataAtual.getDay() - 1 : 0,
		dia = dataAtual.getDate(),
		mes = dataAtual.getMonth(),
		ano = dataAtual.getFullYear(),
		semana = [],
		meses = ["31", ano % 4 == 0 ? 29 : 28 ,"31","30","31","30","31","31","30","31","30","31"],
		mesCalendario = mes,
		anoCalendario = ano,
		lancamentos = [22,23,26];

	semana[diaSemana] = dia;

	for (var i = 0 ;i < 5 ;i++ ) {
		if (!semana[i]) 
			diaSemana < i ? semana[i] = (dia - 1) + i : semana[i] = dia - (i + 1);
	};

	$("#boxCalendario li li .dia").each(function(i){
		$(this).text(semana[i]);
	});

	//A��O DE CLICK EM ALGUM DIA DA ESTEIRA
	$("#boxCalendario li li").bind("click", function(){
		ativarDia($(this));
	});

	//A��O DO BOT�O DE VOLTAR
	$("#boxCalendario .tp1").click(function(){
		if ($("#listaDias").css("left") != "0px") {
			$("#listaDias")
				.fadeTo("normal","0.5",function(){
					$(this).animate({"left": parseInt($("#listaDias").css("left") ,10) + 275},"normal", function(){
						$(this).fadeTo("normal","1");
					});
				});
		}
	});

	//A��O DO BOT�O DE AVAN�AR
	$("#boxCalendario .tp3").click(function(){
		var diaRestante = semana[semana.length  - 1] - meses[mesCalendario];
		switch (diaRestante){
			case 0:
				var diaInicial = 2;
				break;
			case 1:
				var diaInicial = 1;
				break;
			default:
				var diaInicial = 0;
		}
		
		var diaFinal = semana[semana.length  - 1] + 3,
			validador = true,
			diaSemana;

		for (var i = 0 ;i < 5 ;i++ ) {
			semana[i] = diaFinal + i;
			
			if (mesCalendario == 11) {
				anoCalendario++;
				mesCalendario = 0;
			}

			if (semana[i] > meses[mesCalendario]) {
				diaInicial++;
				if (validador) {
					mesCalendario++;
					validador = false;
				} 
				semana[i] = diaInicial;
			}
			
			switch(i){
				case 0:
					diaSemana = "SEG";
					break;
				case 1:
					diaSemana = "TER";
					break;
				case 2:
					diaSemana = "QUA";
					break;
				case 3:
					diaSemana = "QUI";
					break;
				case 4:
					diaSemana = "SEX";
					break;
			}

			var rel = lancamentos[$.inArray(semana[i], lancamentos)],
				$dia = rel ? $('<li><a href="javascript:;" rel="' + rel + '"><span class="mes">'+ diaSemana +'</span><span class="dia">'+ semana[i] +'</span></a></li>') : $('<li class="off"><a href="javascript:;"><span class="mes">'+ diaSemana +'</span><span class="dia">'+ semana[i] +'</span></a></li>');
			
			$dia.bind("click", function(){
				ativarDia($(this));
			});
			$("#listaDias").append($dia);
		}

		$("#listaDias")
			.width($("#listaDias").width() + 275)
			.fadeTo("normal","0.5",function(){
				$(this).animate({"left": parseInt($("#listaDias").css("left") ,10) - 275},"normal", function(){
					$(this).fadeTo("normal","1");
				});
			});
	});
// CALENDARIO

// AVISOS
	$(".boxAvisos .sair").click(function(){
		$(".boxAvisos").fadeOut(function(){
			$(this).remove();
		});
	});

	$("#voltarAviso").click(function(){
		mostrarAviso($(this));
        parent.autoIframePostit();
	});

	$("#avancarAviso").click(function(){
		mostrarAviso($(this));
	    parent.autoIframePostit();
	});
// AVISOS

// SIMPLIFICADA
	if ($.browser.msie && $.browser.version === "6.0" && location.href.indexOf("simplificada") != -1) {
		$("#listaOperacoes li").hover(function(){
			$(this).addClass("hover");
		},function(){
			$(this).removeClass("hover");
		});
	}
// SIMPLIFICADA

});

// Funcao que o flash chama ao fechar
var closeFlashHighlight = function() {
	$("#boxPopBanner").remove();
	$("#bannerOverlay").remove();
}

function mostrarAviso(elm){
	var $avisos = $(".listaAvisos li"),
		$avisoVisivel = $avisos.filter(":visible"),
		$paginador = $("#pagAviso"),
		totalAvisos = $avisos.length,
		id = $(elm).attr("id");

	if (id === "voltarAviso") {
		if (($avisos.index($avisos.filter(":visible")) + 1) > 1) {
			if (($avisos.index($avisos.filter(":visible"))) == 1) $(elm).css("opacity","0.5");
			atualizarAvisos($avisos, $avisoVisivel, $paginador, totalAvisos, id);
		}
	} else {
		if (($avisos.index($avisos.filter(":visible")) + 2) <= totalAvisos) {
			if (($avisos.index($avisos.filter(":visible")) + 2) == totalAvisos) $(elm).css("opacity","0.5");
			atualizarAvisos($avisos, $avisoVisivel, $paginador, totalAvisos, id);
		}
	}
}

function atualizarAvisos($avisos ,$avisoVisivel , $paginador, totalAvisos, id) {
	$("#" + id).css("opacity","1");
	$avisos.hide();
	id == "voltarAviso" ? $avisoVisivel.prev().fadeIn() : $avisoVisivel.next().fadeIn();
	$paginador.text(($avisos.index($avisos.filter(":visible")) + 1) + " de " + totalAvisos);
}

function ativarDia(elm){
	var dia = $(elm).find("a").attr("rel") || 0;

	$(elm).parent().find("li").removeClass("on");
	$(elm).addClass("on");

	$("#boxLancamentos").hide();
	$("#boxLancamentos").next().hide();
	$("#boxLancamentos").load("calendario.html .listaLancamentos[id='" + dia + "']", function(){
		$("#boxLancamentos").fadeIn(200).find(".lancamentosDia").append("<br />"+$(elm).find(".dia").html()+"/05/2009");
		$("#boxLancamentos").next().fadeIn(200);
	});
}

function btoSize (){

	var tul = 0;
    $('#listaOperacoes > li a').css('height','auto');
	$('#listaOperacoes > li a').each(function(){
        var tv = $(this).height();
        
        if (tul <= tv){
            tul = tv;
        }
    });
    $('#listaOperacoes > li a').css('height',(tul));	
}

function controlaMenuSuperior() {
	var linkAtual = ((window.location.href).split(/[;?]/))[0];
	var itemEncontrado = false;
	var listaLinksAux = window.top.listaLinks;
	for (var i = 0; i < listaLinksAux.length; i++) {
		if (listaLinksAux[i].indexOf(linkAtual) > -1) {
			var itemAcionado = window.top.document.getElementById('topmenu_' + listaLinksAux[i].substr(0, 1));
			jQuery(".menuPrincipal li a.on", window.top.document).removeClass("on");
			jQuery(itemAcionado).addClass("on");
			itemEncontrado = true;
			break;
		}
	}
	if (!itemEncontrado) {
		jQuery(".menuPrincipal li a.on", window.top.document).removeClass("on");
	}
}