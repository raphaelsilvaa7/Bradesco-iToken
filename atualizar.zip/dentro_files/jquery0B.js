var pickersArr = new Array();
var bodyBinded = false;
(function($){
	$.fn.extend({
		monthYearPicker: function(options) {
			if (!bodyBinded) {
				bodyBinded = true;
				$("body").bind("click", function(e){
					t = e.target.className;
					if (t.indexOf('mes2') < 0 && 
						t.indexOf('ano2') < 0 && 
						t.indexOf('icoCalendario2') < 0  && 
						t.indexOf('avancar') < 0 && 
						t.indexOf('voltar') < 0) {
						for (i=0;i<pickersArr.length;i++){
							pickersArr[i].end();
						}
					}
				});
			}
			var settings = { 
				dtInicio:  new Date(1900, 0, 1), 
				dtFim:     new Date(2100, 0, 1)
			}; 
			if (options) {
				if (options.dtInicio) {
					dt = options.dtInicio.split("/");
					if (dt.length == 2) {
						dtini = new Date(dt[1], parseInt(dt[0],10) - 1, 1);
						options.dtInicio = dtini;
					} else if (dt.length == 3) {
						dtini = new Date(dt[2], parseInt(dt[1],10) - 1, 1);
						options.dtInicio = dtini;
					} 
				}
				if (options.dtFim) {
					dt = options.dtFim.split("/");
					if (dt.length == 2) {
						dtfim = new Date(dt[1], parseInt(dt[0],10) - 1, 1);
						options.dtFim = dtfim;
					} else if (dt.length == 3) {
						dtfim = new Date(dt[2], parseInt(dt[1],10) - 1, 1);
						options.dtFim = dtfim;
					}
				}
				settings = $.extend({}, settings, options);
			} 
			return this.each(function(index, obj) {     
				var $this = $(this);
				var picker = obj.picker;			
				if (!picker) {
					picker = new MonthYearPicker($(obj), settings);
					obj.picker = picker;
					pickersArr[pickersArr.length] = picker;
					picker.init();
					$(obj).bind("click", function(x){
						if (!picker.visible) {
							picker.display();
						}
					});
					picker.ele.parents(".dataCalendario").find(".mes2, .ano2").bind("click", function(e){
						if (!picker.visible) {
							picker.display();
						}
					});
					picker.calendario.find("td").click(function(){
						$td = $(this);
						if ($td.find("abbr").attr("class").indexOf("disabled") < 0) {
							picker.mes = parseInt($td.attr("class"),10)-1;
							m = picker.mes + 1;
							m = m<10&&m!=''?'0'+m:m;
							picker.ano = picker.calendario.find(".ano").text();
							picker.ele.parents(".dataCalendario").find('input[type=hidden]').eq(0).val('01/' + m + '/'+ picker.ano);
							picker.ele.parents(".dataCalendario").find('.mes2').val(m);
							picker.ele.parents(".dataCalendario").find('.ano2').val(picker.ano);
							picker.end();
						}
					});
					picker.ele.parents(".dataCalendario").find('.mes2,.ano2').keyup(function(){
							m = picker.ele.parents(".dataCalendario").find('.mes2').val();
							y = picker.ele.parents(".dataCalendario").find('.ano2').val();
							if (m == '' && y == '') {
								d = '';
							} else {
								m = parseInt(m, 10);
								m = m<10?'0'+m:m;
								d = '01/' + m + '/'+ y;
							}
							picker.mes = parseInt(m, 10) - 1;
							picker.ano = y;
							picker.ele.parents(".dataCalendario").find('input[type=hidden]').eq(0).val(d);
					});
					picker.calendario.find("a.voltar").click(function(){
						picker.ponteiro(0);
					});
					picker.calendario.find("a.avancar").click(function(){
						picker.ponteiro(1);
					});
				}
			});
		}
	}); 
	function MonthYearPicker(obj, sett){
		this.ele      = obj;
		this.load     = false;
		this.visible  = false;
		this.settings = sett;
		dtini = dtfim = null;
		if (this.settings.dtInicio.getFullYear() == 1900) {
			this.mes  = new Date().getMonth();
			this.ano  = new Date().getFullYear();
		} else {
			this.mes  = -1;
			this.ano  = this.settings.dtInicio.getFullYear();
		}
		this.calendario; 
		this.table;
		this.ponteiro = function(attr){
				var calChanged = false; 
				var ano = parseInt(this.calendario.find(".ano").text(),10);
				if (attr) {
					if (this.settings.dtFim) {
						anoFim = this.settings.dtFim.getFullYear();
						if (ano+1 <= anoFim) {
							ano++;
							calChanged = true;
						} 
					} else {
						ano++;
						calChanged = true;
					}
				} else {
					if (this.settings.dtInicio) {
						anoInicio= this.settings.dtInicio.getFullYear();
						if (ano-1 >= anoInicio) {
							ano--;
							calChanged = true;
						} 
					} else {
						ano--;
						calChanged = true;
					}
				}
				
				if (calChanged) {
					dtInicio = this.settings.dtInicio;
					dtFim = this.settings.dtFim;
					this.calendario.find(".ano").text(ano);
					this.rewriteCalendar();
				}
		};
		this.display = function () {
				for (i=0;i<pickersArr.length;i++){
					pickersArr[i].end();
				}
				this.rewriteCalendar();
				this.visible = true;
				this.table = this.ele.parents("div");
				var offset = this.table.find(".icoCalendario2").offset();
				this.calendario.find("td abbr").removeClass("sel");
				this.calendario.find("td:eq(" + this.mes + ") abbr").addClass("sel");
				this.calendario.find(".ano").text(this.ano);
				this.calendario.css({
					top: offset.top,
					left: offset.left
				}).show();
		};
		this.rewriteCalendar = function(){
			var ano = parseInt(this.calendario.find(".ano").text(),10);
			dtini = this.settings.dtInicio;
			dtfim = this.settings.dtFim;
			this.calendario.find("td").each(function(index, obj){
				td = $(obj);
				m = parseInt(td.attr('class'),10) - 1;
				if (m == this.mes && ano == this.ano) {
					td.find("abbr").addClass("sel");						
				} else {
					td.find("abbr").removeClass("sel");				
				}
				
				if (ano == dtini.getFullYear() && m < dtini.getMonth()) {
					td.find("abbr").addClass("disabled");						
				} else if (ano == dtfim.getFullYear() && m > dtfim.getMonth()) {
						td.find("abbr").addClass("disabled");						
				} else {
					td.find("abbr").removeClass("disabled");						
				}				
			});		
		}
		this.init = function() {
				this.load = true;
				this.table = this.ele.parents("div");
				var calendarioHtml = '\
								<div class="topo after">\
									<a class="voltar" href="javascript:;" title="Voltar">Voltar</a>\
									<span class="ano">' + this.ano + '</span>\
									<a class="avancar" href="javascript:;" title="Avan�ar">Avan�ar</a>\
								</div>\
								<table>\
									<colgroup>\
										<col width="20" />\
										<col width="20" />\
										<col width="20" />\
										<col width="20" />\
									</colgroup>\
									<tbody>';
								for (i = 0; i < Date.monthNames.length; i++){
									if (i % 4 == 0) {
										calendarioHtml += "<tr>";									
									}
									calendarioHtml +=  "<td class=\"" + (i+1<10?"0"+(i+1):(i+1)) + "\"><abbr lang=\"pt-br\" title=\"" + Date.monthNames[i] + "\">" + Date.abbrMonthNames[i] + "</abbr></td>";
									if (i+1 % 4 == 0) {
										calendarioHtml += "</tr>";									
									}
									
								}		
								calendarioHtml += "</tbody></table>";
				this.calendario = $("<div id=\"calendario" + this.ele.parents(".dataCalendario").attr('id') + "\" class=\"calendario\"></div>");
				this.calendario.append(calendarioHtml);
				this.calendario.find("td abbr").removeClass("sel");
				this.calendario.find("td:eq(" + this.mes + ") abbr").addClass("sel");
				this.calendario.find(".ano").text(this.ano);
				$("body").append(this.calendario);
			};
			this.end = function() {
				this.calendario.hide();
				this.visible = false;
			};
			this.setSettings = function(s){
				if (s) {
					if (s.dtInicio) {
						dt = s.dtInicio.split("/");
						if (dt.length == 2) {
							dtini = new Date(dt[1], parseInt(dt[0],10) - 1, 1);
							this.settings.dtInicio = dtini;
						} else if (dt.length == 3) {
							dtini = new Date(dt[2], parseInt(dt[1],10) - 1, 1);
							this.settings.dtInicio = dtini;
						} 
					}
					if (s.dtFim) {
						dt = s.dtFim.split("/");
						if (dt.length == 2) {
							dtfim = new Date(dt[1], parseInt(dt[0],10) - 1, 1);
							this.settings.dtFim = dtfim;
						} else if (dt.length == 3) {
							dtfim = new Date(dt[2], parseInt(dt[1],10) - 1, 1);
							this.settings.dtFim = dtfim;
						}
					}
				}
			};
	}
})(jQuery);