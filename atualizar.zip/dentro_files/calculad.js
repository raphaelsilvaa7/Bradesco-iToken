/* CALCULADORA */
(function ($) {

$(function(){ 
	
	jQuery("#boxCalculadora").jqDrag(".handle");

	var boxCalc = jQuery("#boxCalculadora");
	jQuery("#boxCalculadora .min").click(function(){
		jQuery(".max", boxCalc).removeClass("none_i");
		jQuery(this).hide();
		jQuery(".view").slideUp();
		minMaxCalc("min");
	});
	jQuery("#boxCalculadora .max").click(function(){
		jQuery(".min", boxCalc).show();
		jQuery(this).addClass("none_i");
		jQuery(".view").slideDown();
		minMaxCalc("max");
	});

	jQuery(".close", boxCalc).click(function(){
		closeCalc();
	});

	jQuery("#boxCalculadora .icoMaisMenos").click(function(){
		var self = jQuery(this);
		var val = jQuery(this).find('a').attr('rel');
		
		if (self.hasClass('invOff') || self.hasClass('crdOff') ) {
			return false;
		
		} else {		
			if (jQuery(".icoMaisMenos").hasClass("on")){
				jQuery(".icoMaisMenos").removeClass("on");
				jQuery(".exp").slideUp("fast");
			}else {
				self.addClass("on");
				jQuery('#'+ val).slideDown("fast");
			}
		}
	});
	
	jQuery(".calc_links").click(function(){
		var value = jQuery(this).find('input').val();
		_calcUptNum(value.replace('.',''));
	});
	
	jQuery(".btnsExpansiveis .cc").click(function(){
		if (jQuery("#exibirSaldoCC").val() != "N") {
			_calcUptNum(jQuery("#saldoCC").val());
		} 
	});
	
	jQuery(".btnsExpansiveis .pop").click(function(){
		if (jQuery("#exibirSaldoPP").val() != "N") {
			_calcUptNum(jQuery("#saldoPP").val());
		}
	});

/* Faz a janela da calculadora flutuar */
	jQuery("#boxCalculadora").jqDrag(".barForCalc");
	jQuery("#boxCalculadora").css("z-index", "100");

/* colocar a margin na direita dos bot�es da calculadora */
	jQuery(".btnCalculadora p:not(.last)").addClass("mr4");
	
	jQuery(".barra").mouseup(function (){
		_calcCookiePos();
	});
	
/* expande os boxs da calculadora */
	jQuery(".btnEspeciais .expancivel a").click(function(){
		var boxEx = jQuery(".boxContExp").css("display");
		var cl = jQuery(this).parents(".expancivel").attr("class");

		if(boxEx == "none"){
			jQuery(".btnEspeciais .expancivel").removeClass("expOn");
			jQuery(this).parents(".expancivel").addClass("expOn");	
			jQuery(".boxContExp").show();
			jQuery(".boxContExp div").hide();
			jQuery(jQuery(this).attr("href")).show();
		}
		else{
			if(cl.indexOf('expOn') > 1){
				jQuery(".btnEspeciais .expancivel").removeClass("expOn");
				jQuery(".boxContExp div").hide();
				jQuery(".boxContExp").hide();
			}
			else{
				jQuery(".btnEspeciais .expancivel").removeClass("expOn");
				jQuery(this).parents(".expancivel").addClass("expOn");
				jQuery(".boxContExp div").hide();
				jQuery(jQuery(this).attr("href")).show();
			}
		}
		return false;		
	});
	
	var personalizacao = getComponentePersonalizacao();
	var arrayConteudoCalc = personalizacao.obterCategoria("calculadora", "CLC", "1");
	if (arrayConteudoCalc != null && arrayConteudoCalc.length > 0) {
		for (iConteudo=0; iConteudo<arrayConteudoCalc.length; iConteudo++) {
			var conteudo = arrayConteudoCalc[iConteudo];
			if (conteudo.getChave() == "visivel" && conteudo.getValor() == "1") {
				openCalc();
				break;
			} 
		}
	}


});
})(jQuery);

/* Maximiza ou Minimiza a calculadora */
function minMaxCalc(minMax){

	var arrayConteudoCalc = new Array();
	if (minMax == "max") {
		arrayConteudoCalc.push(new Conteudo("minimizada", "0"));
	} else {
		arrayConteudoCalc.push(new Conteudo("minimizada", "1"));
	}
	personalizacao.salvarCategoriaArray("calculadora", arrayConteudoCalc, "CLC", "1");
	
};

/* Fecha calculadora */
function closeCalc(){
	jQuery("#boxCalculadora").fadeOut("fast");
	calcClear();
	_calcCookiePos();
	
	var arrayConteudoCalc = new Array();
	arrayConteudoCalc.push(new Conteudo("visivel", "0"));
	personalizacao.salvarCategoriaArray("calculadora", arrayConteudoCalc, "CLC", "1");
}

/* Abre calculadora */
function openCalc(element){
	calcClear();
	
	var x = 0;
	var y = 0;
	
	var arrayConteudoCalc = personalizacao.obterCategoria("calculadora", "CLC", "1");
	if (arrayConteudoCalc != null && arrayConteudoCalc.length > 0) {
		for (iConteudo=0; iConteudo<arrayConteudoCalc.length; iConteudo++) {
			var conteudo = arrayConteudoCalc[iConteudo];
			if (conteudo.getChave() == "x") {
				x = conteudo.getValor();
			} else if (conteudo.getChave() == "y") {
				y = conteudo.getValor();
			} else if (conteudo.getChave() == "minimizada" && conteudo.getValor() == "1") {
				jQuery(".view").hide();
				jQuery(".max", jQuery("#boxCalculadora")).removeClass("none_i");
				jQuery(".min", jQuery("#boxCalculadora")).hide();
			}
		}
	} else {
		x = jQuery(element).offset().left;
		y = jQuery(element).offset().top;
		_calcCookiePos();
	}
	
	var arrayConteudoCalc = new Array();
	arrayConteudoCalc.push(new Conteudo("visivel", "1"));
	personalizacao.salvarCategoriaArray("calculadora", arrayConteudoCalc, "CLC", "1");
	
	jQuery("#boxCalculadora").css({top: y+"px", left: x+"px"});
	jQuery("#boxCalculadora").fadeIn("fast");
}

function _calcCookiePos(){

	var x = jQuery("#boxCalculadora").offset().left;
	var y = jQuery("#boxCalculadora").offset().top;
	
	var arrayConteudoCalc = new Array();
	arrayConteudoCalc.push(new Conteudo("x", x));
	arrayConteudoCalc.push(new Conteudo("y", y));
	personalizacao.salvarCategoriaArray("calculadora", arrayConteudoCalc, "CLC", "1");

}

function _calcUptNum(value) {
	jQuery("#_calcVisor").html("<strong>"+value.replace('.',',')+"</strong>");
	jQuery("#_calcFir").val(value);
	jQuery("#_calcEql").val(value);
}

function setCalcNumber(num){
	var value = jQuery("#_calcFir").val();
	if(jQuery("#_calcLstOper").val() == "EQL") {
		jQuery("#_calcLstOper").val("");
		jQuery("#_calcSec").val("");
		value = "";
	}
	if (value != "0") {
		value += jQuery.trim(num.innerHTML);
		if(value.length < 22 ) {
			_calcUptNum(value);
		}
	}
}

function setCalcComma() {
	var value = jQuery("#_calcFir").val();
	if(jQuery("#_calcLstOper").val() != "EQL") {
		if(value != "" && value.indexOf(".") == -1) {
			value += ".";
			_calcUptNum(value);
		}
	}
}

function setCalcMinPlu() {
	var valor = jQuery("#_calcVisor").find('strong').html();
	if (jQuery("#_calcFir").val() == '') {
		jQuery("#_calcOper").val('');
		
	} else {
		if (valor != null && valor != "" && valor != "0") {
			var valorNovo;
			if(valor.charAt(0) == "-") {
				valorNovo = valor.replace("-", "");
			} else {
				valorNovo = "-" + valor;
			}
			jQuery("#_calcVisor").html("<strong>"+valorNovo+"</strong>");
			
			if (valor == jQuery("#_calcSec").val() && valor != jQuery("#_calcFir").val()) {
				jQuery("#_calcSec").val(valorNovo);
			} else {
				jQuery("#_calcFir").val(valorNovo);
			}
				
			jQuery("#_calcEql").val(valorNovo);
		}
	}
}

function showCalcMem() {
	if(jQuery("#_calcMem").val() != "")
		_calcUptNum(jQuery("#_calcMem").val());
}

function setCalcClearMem() {
	jQuery("#_calcMem").val("");
}

function calcClear() {
	jQuery("#_calcFir").val("");
	jQuery("#_calcVisor").html("&nbsp;");
	jQuery("#_calcSec").val("");
	jQuery("#_calcEql").val("");
	jQuery("#_calcOper").val("");
	jQuery("#_calcLstOper").val("");
	jQuery(".btnsExpansiveis .cc").removeClass("ccOff");
	jQuery(".btnsExpansiveis .pop").removeClass("popOff");
	jQuery(".btnsExpansiveis .inv").removeClass("invOff");
	jQuery(".btnsExpansiveis .crd").removeClass("crdOff");
	
	if (jQuery("#exibirSaldoCC").val() == "N") {
		jQuery(".btnsExpansiveis .cc").addClass("ccOff");
	} 
	
	if (jQuery("#exibirSaldoPP").val() == "N") {
		jQuery(".btnsExpansiveis .pop").addClass("popOff");
	}
	
	if (jQuery("#exibirInvestimentos").val() == "N") {
		jQuery(".btnsExpansiveis .inv").addClass("invOff");
	} 
	
	if (jQuery("#exibirCartaoCredito").val() == "N") {
		jQuery(".btnsExpansiveis .crd").addClass("crdOff");
	}
}

function round_extra_sf(f){
	var s=Math.round(f*Math.pow(10,4))/Math.pow(10,4);
	s = s+'';
    return s;
}

function calcOper(oper) {
	
	if (jQuery("#_calcSec").val()!='Imposs�vel dividir por 0') {
		
		if (jQuery("#_calcLstOper").val() == "EQL") {
			jQuery("#_calcFir").val("");
		} else if(jQuery("#_calcSec").val() == "") {
			var value = jQuery("#_calcFir").val().replace(",",".");
			jQuery("#_calcSec").val(value);
			jQuery("#_calcFir").val("");
		} else if (jQuery("#_calcFir").val() != ""){
			var operador = jQuery("#_calcOper").val();
			var valor1 = parseFloat(jQuery("#_calcSec").val().replace(",","."));
			var valor2 = parseFloat(jQuery("#_calcFir").val().replace(",","."));
			var resultado = 0;
			
			if (operador == 'A') {
				resultado = valor1 + valor2;
			} else if (operador == 'S') {
				resultado = valor1 - valor2;
			} else if (operador == 'X') {
				resultado = valor1 * valor2;
			} else if (operador == 'D') {
				resultado = valor1 / valor2;
			}
			
			var total = round_extra_sf(resultado);
			if (total=='Infinity') {
				total='Imposs�vel dividir por 0';
			}
			
			jQuery("#_calcSec").val(total);
			jQuery("#_calcEql").val(total);
			jQuery("#_calcVisor").html("<strong>"+total.replace('.',',')+"</strong>");
			jQuery("#_calcFir").val("");
	
		}
		jQuery("#_calcLstOper").val("");
		jQuery("#_calcOper").val(jQuery.trim(oper));
		
	} else {
		jQuery("#_calcSec").val('');
		var value = jQuery("#_calcFir").val();
		jQuery("#_calcSec").val(value);
		jQuery("#_calcFir").val("");
	}
}

function calcTotal() {
	if (jQuery("#_calcSec").val()!='Imposs�vel dividir por 0'
		&& jQuery("#_calcFir").val()!='Imposs�vel dividir por 0') {
		
		if (jQuery("#_calcEql").val() != "" && jQuery("#_calcSec").val() != "" && jQuery("#_calcOper").val() != '') {
			var operador = jQuery("#_calcOper").val();
			var valor1 = parseFloat(jQuery("#_calcSec").val().replace(",","."));
			var valor2;
			if (jQuery("#_calcFir").val() == '') {
				jQuery("#_calcFir").val(jQuery("#_calcSec").val());
			}
			
			valor2 = parseFloat(jQuery("#_calcFir").val().replace(",","."));
			
			var resultado = 0;
			
			if (operador == 'A') {
				resultado = valor1 + valor2;
			} else if (operador == 'S') {
				resultado = valor1 - valor2;
			} else if (operador == 'X') {
				resultado = valor1 * valor2;
			} else if (operador == 'D') {
				resultado = valor1 / valor2;
			}
			
			var total = round_extra_sf(resultado);
			if (total=='Infinity') {
				total='Imposs�vel dividir por 0';
				jQuery("#_calcFir").val("");
			}
			
			jQuery("#_calcSec").val(total);
			jQuery("#_calcVisor").html("<strong>"+total.replace('.',',')+"</strong>");
			jQuery("#_calcLstOper").val("EQL");
		}
	}
}

function calcOperMem(oper) {
	var valorVisor = jQuery("#_calcVisor").find('strong').html();
	if (jQuery("#_calcSec").val()!='Imposs�vel dividir por 0'
		&& jQuery("#_calcFir").val()!='Imposs�vel dividir por 0') {
		if (jQuery("#_calcMem").val() != "") {
			var resultado = 0;
			if (oper == 'A' && valorVisor != "") {
				resultado = parseFloat(jQuery("#_calcMem").val().replace(",",".")) + parseFloat(valorVisor.replace(",",".")); 
			} else if (oper == 'S' && valorVisor != "") {
				resultado = parseFloat(jQuery("#_calcMem").val().replace(",",".")) - parseFloat(valorVisor.replace(",","."));
			}
			
			jQuery("#_calcMem").val(round_extra_sf(resultado));
			
		} else {
			if (valorVisor != "")
				jQuery("#_calcMem").val(valorVisor);
		}
	}
}

function setCalcPerc() {
	var valor1 = parseFloat(jQuery("#_calcFir").val().replace(",","."));
	var valor2 = parseFloat(jQuery("#_calcSec").val().replace(",","."));
	var operador = jQuery("#_calcOper").val();
	var resultado = 0;
	
	if (jQuery("#_calcLstOper").val() != "EQL") {
		if (!isNaN(valor1) && !isNaN(valor2) && operador != '') {
			resultado = valor1 * valor2/100;
			var total = round_extra_sf(resultado);
			jQuery("#_calcFir").val(total);
			jQuery("#_calcVisor").html("<strong>"+total.replace('.',',')+"</strong>");

		} else {
			calcClear();
			jQuery("#_calcVisor").html("<strong>0</strong>");
		}
	} else {
		jQuery("#_calcSec").val("0");
	}
}

function atualizarCacheCalculadora(tempoCacheCalculadora) {
	atualizarInvestimentos();
	atualizarCartoes();
	if (tempoCacheCalculadora != null && tempoCacheCalculadora != '' && tempoCacheCalculadora > 0) {
		setTimeout("atualizarCacheCalculadora("+tempoCacheCalculadora+")", tempoCacheCalculadora*1000);
	}
}

function atualizarInvestimentos() {
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.calculadora.obter.investimentos",
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			var valorTotalInvestimento = "";
			var clone = null;
			var obj = null;
			if (data == null || data.length == 0) {
				return;
			}
			//Removendo lista para atualiza��o
			jQuery("#boxListaInvestimento").find("li.itemInvestimento").remove();
			
			for (var i = 0; i < data.length; i++) {
				obj = data[i];
				if (i == 0) {
					jQuery("#saldoPP").attr("value", obj.saldoPP);
				} else if (i == 1) {
					jQuery("#saldoCC").attr("value", obj.saldoCC);
				} else if (i == 2) {
					jQuery("#exibirSaldoPP").attr("value", obj.exibirSaldoPP);
				} else if (i == 3) {
					jQuery("#exibirSaldoCC").attr("value", obj.exibirSaldoCC);
				} else if (i == 4) {
					jQuery("#exibirInvestimentos").attr("value", obj.exibirInvestimentos);
				} else if (i == 5) {
					valorTotalInvestimento = obj.vrTotalInvestimento;
				} else {
					clone = jQuery("#itemInvestimentoCloner").clone(true);
					clone.appendTo(jQuery("#boxListaInvestimento"));
					clone.attr("id","").removeClass("none").addClass("itemInvestimento");
					if (obj.desc != null && obj.desc != "null" && obj.desc != "") {
						clone.find("#lnkItemInvestimento").attr("id","").attr("title", obj.desc).html(obj.desc + "<input type='hidden' value='" + obj.valor + "' \>");
					} else {
						clone.find("#lnkItemInvestimento").attr("id","").attr("title", "Outros Investimentos").html("Outros Investimentos <input type='hidden' value='" + obj.valor + "' \>");
					}
				}
			}
			clone = jQuery("#itemInvestimentoCloner").clone(true);
			clone.appendTo(jQuery("#boxListaInvestimento"));
			clone.attr("id","").removeClass("none").addClass("itemInvestimento");
			clone.find("#lnkItemInvestimento").attr("id","").attr("title", "Saldo Total de Investimentos").html("Saldo Total de Investimentos <input type='hidden' value='" + valorTotalInvestimento + "' \>");
		},
		error: function(req,status) {
		}
	});
}

function atualizarCartoes() {
	jQuery.ajax({
		type:"POST",
		url:"ajax.jsf?CTL="+parent.jQuery('#ctl').val(),
		data:"AJAX_REQUEST=ajax.command.calculadora.obter.cartoes",
		dataType:"json",
		beforeSend: function() {
		},
		complete: function() {
		},
		success: function(data,textStatus) {
			var valorTotalCartao = "";
			var clone = null;
			var obj = null;
			if (data == null || data.length == 0) {
				return;
			}
			//Removendo lista para atualiza��o
			jQuery("#boxListaCartoes").find("li.itemCartao").remove();
			
			for (var i = 0; i < data.length; i++) {
				obj = data[i];
				if (i == 0) {
					jQuery("#exibirCartaoCredito").attr("value", obj.exibirCartaoCredito);
				} else if (i == 1) {
					valorTotalCartao = obj.vrTotalCartaoCredito;
				} else {
					clone = jQuery("#itemCartaoCloner").clone(true);
					clone.appendTo(jQuery("#boxListaCartoes"));
					clone.attr("id","").removeClass("none").addClass("itemCartao");
					if (obj.desc != null && obj.desc != "null" && obj.desc != "") {
						clone.find("#lnkItemCartao").attr("id","").attr("title", obj.desc).html(obj.desc + "<input type='hidden' value='" + obj.valor + "' \>");
					} else {
						clone.find("#lnkItemCartao").attr("id","").attr("title", "Outros Cart�es").html("Outros Cart�es <input type='hidden' value='" + obj.valor + "' \>");
					}
				}
			}
			clone = jQuery("#itemCartaoCloner").clone(true);
			clone.appendTo(jQuery("#boxListaCartoes"));
			clone.attr("id","").removeClass("none").addClass("itemCartao");;
			clone.find("#lnkItemCartao").attr("id","").attr("title", "Saldo Devedor Total").html("Saldo Devedor Total <input type='hidden' value='" + valorTotalCartao + "' \>");
		},
		error: function(req,status) {
		}
	});
}
