(function ($) {

$(function() {

	// BUSCA DETALHADA
	renderBuscaDetalhada();
	validaSemPalavra();
	$('#btn_dicas').click(function(){
		if($('#boxAjuda').is(':visible')){
			$('#boxAjuda').slideToggle(500, function(){
				$('#boxDicas').slideToggle(500);
				$('#btn_dica').addClass('active');
				$('#btn_ajuda').removeClass('active');
			});
		}else{
			if($('#btn_dicas').hasClass('active')){
					$('#boxDicas').slideToggle(500,function(){
						$('#btn_dicas').removeClass('active')
					});
			}else{
					$('#boxDicas').slideToggle(500);
					$('#btn_dicas').addClass('active');
			}
			$('#btn_ajuda').removeClass('active');
		}
	});

	//BOTAOFECHAR
	$('#btFechadorBusc').click(function(){
		$('#busca_detalhada').slideToggle(500);
	});

	$('.btnBuscador').click(function(evt){
		submitFormBuscador();
		return false;
	});



	$('#txtPesquisar').keypress(function(evt){
		return submitEnter(evt);
	});

	//CAMPO TEXTO AUTO COMPLETA BUSCADOR
	//inicializaAutoComplete();
	var ct = $("#a4jCTL").val();
	var paramCtl = '/ibpfbuscador/buscadorAutoComplete.jsf?CTL='+ ct

	$("#txtPesquisar2").autocomplete(paramCtl,{
		matchContains: true,
		selectFirst: false,
		selectOnly: true,
		minChars: 3,
		width: 358,
		highlight: function(value, term) {
			return "<a href=\"javascript:;\" title=\"" + value + "\">" + accent_folded_hilite(value, term) + "</a>";
		},
		parse: function(data) {
			var parsed = [];
			data=data.replace(new RegExp('\\+','g'),' ');
			var rows = unescape(data).split("\n");

			for (var i=0; i < rows.length; i++) {
				var row = rows[i].replace(/^\s+|\s+$/g, "");;

				if(row.indexOf('##FIM##') != -1){
					break;
				}
				if (row) {
					row = row.split("|");
					parsed[parsed.length] = {
							data: row,
							value: row[0],
							result: row[0]
					};
				}
			}
			return parsed;
		}
	});

	$("span.cont_"+$(this).attr("id")).text("[" + ($(this).attr("maxlength") - $(this).val().length) + "]");
});

})(jQuery);

   // FORMULARIO BUSCADOR
	function escreveDados(campoValor, labelValor){
		var dadosCampo = document.getElementById(campoValor).value;
		document.getElementById(labelValor).innerHTML = dadosCampo;
	}


	//Abre form buscador submit
	function submitFormBuscador(){
		parent.abrirBuscador(jQuery('#txtPesquisar').val(),jQuery("#paginaCentral").contents().find(".txt-codigoTela").html());
		jQuery('#txtPesquisar').val('');
		jQuery(".btnBuscador").attr("title", "OK");
	}


	//Submit form com enter
	function submitEnter(e)
	{
		var keycode;
		if (window.event) keycode = window.event.keyCode;
		else if (e) keycode = e.which;
		else return true;

		if (keycode == 13)
		   {
			submitFormBuscador();
            $(".ac_results").hide();
            return false;
		   }
		else
		   return true;
	}

	function renderBuscaDetalhada(){

		if (jQuery("#detalhada").val() == false || jQuery("#detalhada").val() == 'false'  ) {
			jQuery("#btnBuscaDetalhada").attr('title',"Pressione ENTER para fazer Busca Detalhada");
		}else{
			jQuery("#btnBuscaDetalhada").attr('title',"Pressione ENTER para fechar Busca Detalhada");
		}


		// BUSCA DETALHADA
		jQuery("#btnBuscaDetalhada, #btnFecharBusca").click(function(evt) {
			var buscaDetalhada = jQuery("#busca_detalhada");
			var filtro = jQuery("#filtro");

			if (buscaDetalhada.is(":visible")  ) {
				buscaDetalhada.slideUp(400,function() {
					filtro.removeClass("filtro_detalhado");
					jQuery("#txtPesquisar2").removeAttr('readonly');
					jQuery("#txtPesquisar2").focus();
					setTimeout(function() {
						if (window.parent.autoIframe) {
							window.parent.autoIframe();
						}
					}, 400);
				});
				jQuery("#btnBuscaDetalhada").attr('title',"Pressione ENTER para fazer Busca Detalhada");
			} else {
				buscaDetalhada.slideToggle(400);
				filtro.addClass("filtro_detalhado");
				jQuery("#txtPesquisar2").val('');
				jQuery("#txtPesquisar2").attr('readonly',true);
				jQuery("#btnBuscaDetalhada").attr('title',"Pressione ENTER para fechar Busca Detalhada");
				jQuery("#todasPalavra").focus();
				setTimeout(function() {
					if (window.parent.autoIframe) {
						window.parent.autoIframe();
					}
				}, 400);
			}
			evt.preventDefault();
		});
	}

	function renderLista(){
	//	jQuery(".listaCaminhoBusc").each(function() {
	//      jQuery(this).removeAttr("style");
	//      });
		if (window.parent.autoIframe) {
			window.parent.autoIframe();
		}
		top.scrollTo(0,0);
	}



	function setaBotao(isDetlhada){
		jQuery("#isBotao").val(true);
		jQuery("#detalhada").val(isDetlhada);
	}


	function validaSemPalavra(){

		var todasPalavra = jQuery("#todasPalavra").val();
		var qualquerPalavra = jQuery("#qualquerPalavra").val();
		var expressaoPalavra = jQuery("#expressaoPalavra").val();

		try {
			if((todasPalavra.replace(/^\s+|\s+$/g, "")).length != 0 ||
					(qualquerPalavra.replace(/^\s+|\s+$/g, "")).length != 0 ||
					(expressaoPalavra.replace(/^\s+|\s+$/g, "")).length != 0 ){
				jQuery("#semPalavra").removeAttr('disabled');
				jQuery("#semPalavra").css("background-color","#ffffff");
			}else{
				jQuery("#semPalavra").val('');
				jQuery("#semPalavra").attr('disabled', 'disabled');
				jQuery("#semPalavra").css("background-color","#CCCCCC");

			}
		}
		catch(err) {
		}
	}


	function valida(){
		var texto = jQuery("#txtPesquisar2").val();
		var isBotao = jQuery("#isBotao").val();

		if (isBotao == 'true') {

			var isDetalhada = jQuery("#detalhada").val();
			if (isDetalhada == 'true') {
				var todasPalavra = jQuery("#todasPalavra").val();
				var qualquerPalavra = jQuery("#qualquerPalavra").val();
				var expressaoPalavra = jQuery("#expressaoPalavra").val();
				var semPalavra = jQuery("#semPalavra").val();

				if ((todasPalavra.replace(/^\s+|\s+$/g, "").length > 0)
						|| (qualquerPalavra.replace(/^\s+|\s+$/g, "").length > 0)
						|| (expressaoPalavra.replace(/^\s+|\s+$/g, "").length > 0)) {
					jQuery("#paginaSel").val('1');
					return true;
				} else {
					return false;
				}
			} else {
				if (texto.replace(/^\s+|\s+$/g, "").length == 0) {
					 jQuery("#txtPesquisar2").focus();
					 return false;
				}
				jQuery("#todasPalavra").val('');
				jQuery("#qualquerPalavra").val('');
				jQuery("#expressaoPalavra").val('');
				jQuery("#semPalavra").val('');
				jQuery("#paginaSel").val('1');
			}
		}
		return true;
	}

	function setaTitulo(obj){
		var texto = jQuery("#txtPesquisar2").val();
		if (texto.replace(/^\s+|\s+$/g, "").length == 0) {
			obj.title = "OK";
		}
		else {
			obj.title = "OK. Pesquisar por: " + texto;
		}
	}

	function setaDizer(dizer){

		setaBotao(false);
		jQuery("#txtPesquisar2").val(dizer);
		jQuery("#palavraAnt").val(dizer);
	}


	function mudaItemPorPagina(){

		var qtdeItemTotal = jQuery("#qtdeItemTotal").val();
		if(qtdeItemTotal < 1){
			return;
		}

		var qtdeItemPagina = jQuery("#qtdeItemPagina").val();
		var paginaSel = jQuery("#paginaSel").val();
		var novoQtdeItemPagina = jQuery("#filtroLista").val();

		var indexRegistro = (qtdeItemPagina * paginaSel) - qtdeItemPagina + 1 ;
		var qtdePaginasNova = 0;
		if(qtdeItemTotal % novoQtdeItemPagina == 0){
			qtdePaginasNova = qtdeItemTotal / novoQtdeItemPagina;
		}else{
			qtdePaginasNova = parseInt( qtdeItemTotal / novoQtdeItemPagina) + 1;
		}

		var novaPaginaSel = 1;
		for(var i=1;i<qtdePaginasNova;i++){
			if( indexRegistro <= (i*novoQtdeItemPagina) ){
				novaPaginaSel = i;
				break;
			}
		}

		setaPagina(novaPaginaSel);
		jQuery("#qtdeItemPagina").val(novoQtdeItemPagina);
		if (window.parent.autoIframe) {
			window.parent.autoIframe();
		}
	}

	function setaPagina(paginaSel){

		jQuery("#paginaSel").val(paginaSel);
		var detalhada = jQuery("#detalhada").val();
		var numItemPagina = jQuery("#filtroLista").val();
		var palavraAnt = jQuery("#palavraAnt").val();
		var todasPalavra = jQuery("#todasPalavra").val();
		var qualquerPalavra = jQuery("#qualquerPalavra").val();
		var semPalavra = jQuery("#semPalavra").val();
		var expressaoPalavra = jQuery("#expressaoPalavra").val();
		var areaOcorrencia = jQuery("#areaOcorrencia").val();
		pesquisaAjax(paginaSel,detalhada,numItemPagina,palavraAnt,todasPalavra,qualquerPalavra,semPalavra,expressaoPalavra,areaOcorrencia);

		if (window.parent.autoIframe) {
			window.parent.autoIframe();
		}
	}


